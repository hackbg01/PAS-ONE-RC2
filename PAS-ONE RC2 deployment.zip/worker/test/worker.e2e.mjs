// Run: wrangler dev --local (port 8787) + supabase-stub.mjs + PostgREST on the migrated DB. See tests/e2e/README.md
import crypto from 'node:crypto';
const W = 'http://localhost:8787', SECRET = 'test-secret-test-secret-test-secret-123', SIGN = 'test-signing-secret-0123456789abcdef';
const b64 = o => Buffer.from(JSON.stringify(o)).toString('base64url');
const jwt = (sub, extra = {}) => { const h = b64({ alg: 'HS256', typ: 'JWT' }), p = b64({ sub, role: 'authenticated', aud: 'authenticated', exp: Math.floor(Date.now() / 1000) + 3600, ...extra }); return h + '.' + p + '.' + crypto.createHmac('sha256', SECRET).update(h + '.' + p).digest('base64url'); };
const A = '00000000-0000-0000-0000-0000000000a1', B = '00000000-0000-0000-0000-0000000000b2', MG = '00000000-0000-0000-0000-0000000000e5';
let pass = 0, fail = 0; const t = (n, c, x = '') => { c ? pass++ : fail++; console.log((c ? 'PASS' : 'FAIL') + ' : ' + n + (c ? '' : '  -> ' + JSON.stringify(x))); };
const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), crypto.randomBytes(2000)]);
const jpg = Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), crypto.randomBytes(500)]);
const pdf = Buffer.concat([Buffer.from('%PDF-1.4\n'), crypto.randomBytes(300)]);
const up = (tok, body, qs = '', headers = {}) => fetch(W + '/upload' + qs, { method: 'POST', headers: { ...(tok ? { Authorization: 'Bearer ' + tok } : {}), ...headers }, body });
const sign = async (k, tok) => { const r = await fetch(W + '/sign?key=' + encodeURIComponent(k), { headers: tok ? { Authorization: 'Bearer ' + tok } : {} }); return { status: r.status, j: await r.json().catch(() => ({})) }; };
(async () => {
  const ta = jwt(A), tb = jwt(B), tm = jwt(MG);
  let r = await up(ta, png, '?kind=payment_proof', { 'Content-Type': 'image/png' }); let j = await r.json();
  t('W1 valid PNG upload by customer -> 201, key under own uid', r.status === 201 && j.key.startsWith('payment_proof/' + A + '/') && j.key.endsWith('.png'), j);
  const keyA = j.key;
  r = await up(ta, jpg, '', {}); j = await r.json(); t('W1b JPEG accepted (default kind)', r.status === 201 && j.mime === 'image/jpeg', j);
  r = await up(ta, pdf); j = await r.json(); t('W1c PDF accepted', r.status === 201 && j.mime === 'application/pdf', j);
  r = await up(null, png); t('W2 no token -> 401', r.status === 401);
  r = await up('abc.def.ghi', png); t('W2b garbage token -> 401', r.status === 401);
  r = await up(jwt(A, { exp: 1 }), png); t('W2c expired token -> 401', r.status === 401);
  r = await up(ta, Buffer.from('<html><script>alert(1)</script></html>'), '', { 'Content-Type': 'image/png' }); t('W3 HTML disguised as image/png -> 415 (magic bytes win)', r.status === 415);
  r = await up(ta, Buffer.from('MZ\x90\x00 fake exe'), '', { 'Content-Type': 'application/pdf' }); t('W3b executable disguised as PDF -> 415', r.status === 415);
  r = await up(ta, Buffer.concat([png, Buffer.alloc(3 * 1024 * 1024)])); t('W4 3 MB file -> 413', r.status === 413);
  r = await up(ta, png, '?kind=../../etc'); t('W5 invalid kind -> 400', r.status === 400);
  r = await up(ta, png, '?kind=catalog_image'); j = await r.json(); t('W6 customer cannot upload catalog_image (RPC forbids) -> 403', r.status === 403, [r.status, j]);
  r = await up(tm, png, '?kind=catalog_image'); t('W6b manager can upload catalog_image', r.status === 201);
  // signed URLs
  let s = await sign(keyA, ta); t('W7 owner gets signed URL', s.status === 200 && s.j.url.includes('/f/' + keyA), s);
  let f = await fetch(s.j.url); const buf = Buffer.from(await f.arrayBuffer());
  t('W7b signed URL serves the exact bytes, image/png, nosniff, private cache', f.status === 200 && buf.equals(png) && f.headers.get('content-type') === 'image/png' && f.headers.get('x-content-type-options') === 'nosniff' && /private/.test(f.headers.get('cache-control')), [f.status, f.headers.get('content-type')]);
  s = await sign(keyA, tb); t('W8 other customer cannot sign (403)', s.status === 403, s);
  s = await sign(keyA, tm); t('W8b manager can sign', s.status === 200, s);
  s = await sign(keyA, null); t('W8c unauthenticated cannot sign (401)', s.status === 401, s);
  s = await sign('payment_proof/../../secret', ta); t('W9 path traversal key rejected (400)', s.status === 400, s);
  const exp = Math.floor(Date.now() / 1000) + 300, goodSig = crypto.createHmac('sha256', SIGN).update(`${keyA}|${exp}`).digest('hex');
  f = await fetch(`${W}/f/${keyA}?exp=${exp}&sig=${goodSig}`); t('W10 (control) hand-made valid signature works -> 200', f.status === 200);
  f = await fetch(`${W}/f/${keyA}?exp=${exp}&sig=${goodSig.replace(/.$/, c => c === 'a' ? 'b' : 'a')}`); t('W10b tampered signature -> 403', f.status === 403);
  const old = Math.floor(Date.now() / 1000) - 10, oldSig = crypto.createHmac('sha256', SIGN).update(`${keyA}|${old}`).digest('hex');
  f = await fetch(`${W}/f/${keyA}?exp=${old}&sig=${oldSig}`); t('W10c expired link (valid sig) -> 403', f.status === 403);
  const other = keyA.replace(A, B); const sig2 = crypto.createHmac('sha256', SIGN).update(`${keyA}|${exp}`).digest('hex');
  f = await fetch(`${W}/f/${other}?exp=${exp}&sig=${sig2}`); t('W10d signature not transferable to another key -> 403', f.status === 403);
  // CORS
  r = await fetch(W + '/sign?key=x', { method: 'OPTIONS', headers: { Origin: 'http://localhost:8080' } }); t('W11 CORS allows configured origin only', r.headers.get('access-control-allow-origin') === 'http://localhost:8080');
  r = await fetch(W + '/sign?key=x', { method: 'OPTIONS', headers: { Origin: 'https://evil.example' } }); t('W11b CORS denies other origins', !r.headers.get('access-control-allow-origin'));
  r = await fetch(W + '/nope'); t('W12 unknown route -> 404 JSON, no internals', r.status === 404);
  console.log(`WORKER TOTAL PASS=${pass} FAIL=${fail}`); process.exit(fail ? 1 : 0);
})();
