// Test harness only: emulates Supabase Auth's /auth/v1/user (HS256 verification) and forwards /rest/v1/* to a local PostgREST.
import http from 'node:http'; import crypto from 'node:crypto';
const SECRET = process.env.JWT_SECRET || 'test-secret-test-secret-test-secret-123', PGRST = +(process.env.PGRST_PORT || 3000);
function verify(tok) { const [h, p, s] = tok.split('.'); if (!s) return null; const e = crypto.createHmac('sha256', SECRET).update(h + '.' + p).digest('base64url'); if (e !== s) return null; const c = JSON.parse(Buffer.from(p, 'base64url')); return (c.exp && c.exp < Date.now() / 1000) ? null : c; }
http.createServer((req, res) => {
  if (req.url.startsWith('/auth/v1/user')) {
    const c = verify((req.headers.authorization || '').replace(/^Bearer /, ''));
    if (!c || !c.sub) { res.writeHead(401, { 'content-type': 'application/json' }); return res.end('{"msg":"invalid"}'); }
    res.writeHead(200, { 'content-type': 'application/json' }); return res.end(JSON.stringify({ id: c.sub, aud: 'authenticated', is_anonymous: !!c.is_anonymous }));
  }
  const u = req.url.replace(/^\/rest\/v1/, '');
  const p = http.request({ host: 'localhost', port: PGRST, path: u, method: req.method, headers: req.headers }, r => { res.writeHead(r.statusCode, r.headers); r.pipe(res); });
  p.on('error', e => { res.statusCode = 502; res.end(String(e)); }); req.pipe(p);
}).listen(3002, () => console.log('stub on 3002'));
