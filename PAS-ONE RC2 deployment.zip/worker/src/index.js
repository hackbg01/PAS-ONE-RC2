// PAS-One media Worker: secure upload / signed download for Cloudflare R2.
// Auth = the caller's Supabase JWT (validated by Supabase itself). Permissions = Postgres RPC (can_read_media / register_media).
// No R2 credentials or service_role key exist anywhere: R2 is accessed through the Worker binding `MEDIA`.
const MAX_BYTES = 2 * 1024 * 1024;                       // 2 MB (client should compress photos); DB allows up to 5 MB
const KINDS = ['payment_proof', 'catalog_image', 'document'];
const KEY_RE = /^(payment_proof|catalog_image|document)\/[0-9a-f-]{36}\/[0-9a-f-]{36}\.(jpg|png|webp|pdf)$/;
const SIGN_TTL_S = 300;

function sniff(b) {                                       // trust magic bytes, never the client's Content-Type
  const u = new Uint8Array(b.slice(0, 12));
  const eq = (a) => a.every((v, i) => u[i] === v);
  if (eq([0xff, 0xd8, 0xff])) return { ext: 'jpg', mime: 'image/jpeg' };
  if (eq([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) return { ext: 'png', mime: 'image/png' };
  if (eq([0x52, 0x49, 0x46, 0x46]) && u[8] === 0x57 && u[9] === 0x45 && u[10] === 0x42 && u[11] === 0x50) return { ext: 'webp', mime: 'image/webp' };
  if (eq([0x25, 0x50, 0x44, 0x46, 0x2d])) return { ext: 'pdf', mime: 'application/pdf' };
  return null;
}
const hex = (buf) => [...new Uint8Array(buf)].map((x) => x.toString(16).padStart(2, '0')).join('');
async function hmac(secret, msg) {
  const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return hex(await crypto.subtle.sign('HMAC', k, new TextEncoder().encode(msg)));
}
function safeEqual(a, b) { if (a.length !== b.length) return false; let d = 0; for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i); return d === 0; }

function cors(env, req) {
  const o = req.headers.get('Origin');
  const h = { 'Vary': 'Origin' };
  if (o && o === env.ALLOWED_ORIGIN) Object.assign(h, { 'Access-Control-Allow-Origin': o, 'Access-Control-Allow-Headers': 'Authorization, Content-Type', 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS', 'Access-Control-Max-Age': '600' });
  return h;
}
const json = (env, req, status, body, extra = {}) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', ...cors(env, req), ...extra } });

async function authUser(env, req) {                       // returns {id, token} or null
  const auth = req.headers.get('Authorization') || '';
  if (!/^Bearer [\w-]+\.[\w-]+\.[\w-]+$/.test(auth)) return null;
  const r = await fetch(`${env.SUPABASE_URL}/auth/v1/user`, { headers: { apikey: env.SUPABASE_ANON_KEY, Authorization: auth } });
  if (!r.ok) return null;
  const u = await r.json();
  return u && u.id ? { id: u.id, token: auth.slice(7) } : null;
}
async function rpc(env, token, name, args) {
  const r = await fetch(`${env.SUPABASE_URL}/rest/v1/rpc/${name}`, { method: 'POST', headers: { apikey: env.SUPABASE_ANON_KEY, Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, body: JSON.stringify(args) });
  const text = await r.text(); let data = null; try { data = JSON.parse(text); } catch (e) { /* non-json */ }
  return { ok: r.ok, data, status: r.status };
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors(env, req) });
    try {
      // ---- upload -------------------------------------------------------
      if (req.method === 'POST' && url.pathname === '/upload') {
        const kind = url.searchParams.get('kind') || 'payment_proof';
        if (!KINDS.includes(kind)) return json(env, req, 400, { success: false, error: 'invalid kind' });
        const user = await authUser(env, req); if (!user) return json(env, req, 401, { success: false, error: 'unauthorized' });
        const len = parseInt(req.headers.get('Content-Length') || '0', 10);
        if (!len || len > MAX_BYTES) return json(env, req, 413, { success: false, error: 'file must be 1 byte..2 MB' });
        const body = await req.arrayBuffer();
        if (body.byteLength === 0 || body.byteLength > MAX_BYTES) return json(env, req, 413, { success: false, error: 'file must be 1 byte..2 MB' });
        const t = sniff(body); if (!t) return json(env, req, 415, { success: false, error: 'only JPEG, PNG, WEBP or PDF allowed' });
        const key = `${kind}/${user.id}/${crypto.randomUUID()}.${t.ext}`;
        await env.MEDIA.put(key, body, { httpMetadata: { contentType: t.mime }, customMetadata: { owner: user.id, kind } });
        const reg = await rpc(env, user.token, 'register_media', { p_key: key, p_kind: kind, p_mime: t.mime, p_size: body.byteLength });
        if (!reg.ok) { await env.MEDIA.delete(key); return json(env, req, reg.status === 401 || reg.status === 403 ? 403 : 400, { success: false, error: (reg.data && reg.data.message) || 'rejected' }); }
        return json(env, req, 201, { success: true, key, mime: t.mime, size: body.byteLength });
      }
      // ---- signed URL ---------------------------------------------------
      if (req.method === 'GET' && url.pathname === '/sign') {
        const key = url.searchParams.get('key') || '';
        if (!KEY_RE.test(key)) return json(env, req, 400, { success: false, error: 'invalid key' });
        const user = await authUser(env, req); if (!user) return json(env, req, 401, { success: false, error: 'unauthorized' });
        const ok = await rpc(env, user.token, 'can_read_media', { p_key: key });
        if (!ok.ok || ok.data !== true) return json(env, req, 403, { success: false, error: 'forbidden' });
        const exp = Math.floor(Date.now() / 1000) + SIGN_TTL_S;
        const sig = await hmac(env.SIGNING_SECRET, `${key}|${exp}`);
        return json(env, req, 200, { success: true, url: `${url.origin}/f/${key}?exp=${exp}&sig=${sig}`, expiresIn: SIGN_TTL_S });
      }
      // ---- download (signed) -------------------------------------------
      if (req.method === 'GET' && url.pathname.startsWith('/f/')) {
        const key = decodeURIComponent(url.pathname.slice(3));
        const exp = parseInt(url.searchParams.get('exp') || '0', 10), sig = url.searchParams.get('sig') || '';
        if (!KEY_RE.test(key) || !exp || exp < Date.now() / 1000) return new Response('Link expired or invalid', { status: 403 });
        if (!safeEqual(sig, await hmac(env.SIGNING_SECRET, `${key}|${exp}`))) return new Response('Link expired or invalid', { status: 403 });
        const obj = await env.MEDIA.get(key); if (!obj) return new Response('Not found', { status: 404 });
        return new Response(obj.body, { headers: { 'Content-Type': obj.httpMetadata.contentType, 'Content-Disposition': 'inline', 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'private, max-age=60', 'Content-Security-Policy': "default-src 'none'; img-src 'self' data:; style-src 'unsafe-inline'; sandbox", 'Cross-Origin-Resource-Policy': 'cross-origin' } });
      }
      return json(env, req, 404, { success: false, error: 'not found' });
    } catch (e) {
      return json(env, req, 500, { success: false, error: 'internal error' });     // never leak internals
    }
  }
};
export { sniff, KEY_RE };
