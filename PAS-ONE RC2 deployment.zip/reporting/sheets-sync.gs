/**
 * PAS-One -> Google Sheets reporting sync (REPORT COPY ONLY; PostgreSQL stays the source of truth).
 * Auth: a dedicated Supabase account with role 'manager' (least privilege available) + the PUBLIC anon key. No service_role key.
 * Script Properties (Project Settings > Script properties): SUPABASE_URL, SUPABASE_ANON_KEY, REPORT_EMAIL, REPORT_PASSWORD
 * Optional: REPORT_SPREADSHEET_ID (defaults to the spreadsheet this script is bound to).
 * Setup: run installDailyTrigger() once. Quota: ~3 UrlFetch calls/run, well inside Apps Script free limits.
 */
function prop_(k, required) {
  var v = PropertiesService.getScriptProperties().getProperty(k);
  if (required && !v) throw new Error('Missing script property: ' + k);
  return v;
}

function login_() {
  var res = UrlFetchApp.fetch(prop_('SUPABASE_URL', true) + '/auth/v1/token?grant_type=password', {
    method: 'post', contentType: 'application/json', muteHttpExceptions: true,
    headers: { apikey: prop_('SUPABASE_ANON_KEY', true) },
    payload: JSON.stringify({ email: prop_('REPORT_EMAIL', true), password: prop_('REPORT_PASSWORD', true) })
  });
  if (res.getResponseCode() !== 200) throw new Error('Supabase login failed (' + res.getResponseCode() + ')');   // never log the response (may echo credentials)
  return JSON.parse(res.getContentText()).access_token;
}

function fetchReport_(token, from, to) {
  var res = UrlFetchApp.fetch(prop_('SUPABASE_URL', true) + '/rest/v1/rpc/report_export', {
    method: 'post', contentType: 'application/json', muteHttpExceptions: true,
    headers: { apikey: prop_('SUPABASE_ANON_KEY', true), Authorization: 'Bearer ' + token },
    payload: JSON.stringify({ p_from: from, p_to: to })
  });
  if (res.getResponseCode() !== 200) throw new Error('report_export failed (' + res.getResponseCode() + '): ' + res.getContentText().slice(0, 200));
  return JSON.parse(res.getContentText());
}

function writeSheet_(ss, name, header, rows) {
  var sh = ss.getSheetByName(name) || ss.insertSheet(name);
  sh.clearContents();
  var data = [header].concat(rows);
  sh.getRange(1, 1, data.length, header.length).setValues(data);
  sh.setFrozenRows(1);
  return rows.length;
}

function ymd_(d) { return Utilities.formatDate(d, 'Asia/Jakarta', 'yyyy-MM-dd'); }

/** Sync month-to-date (or an explicit range). Safe to re-run: sheets are rewritten, not appended (idempotent). */
function syncReports(fromStr, toStr) {
  var now = new Date();
  var to = toStr || ymd_(now);
  var from = fromStr || ymd_(new Date(now.getFullYear(), now.getMonth(), 1));
  var rep = fetchReport_(login_(), from, to);
  var ss = prop_('REPORT_SPREADSHEET_ID') ? SpreadsheetApp.openById(prop_('REPORT_SPREADSHEET_ID')) : SpreadsheetApp.getActiveSpreadsheet();
  var n = {};
  n.orders = writeSheet_(ss, 'Orders', ['Order', 'Dibuat (UTC)', 'Pelanggan', 'Subtotal', 'Diskon', 'Pajak', 'Total', 'Status order', 'Status bayar'],
    rep.orders.map(function (o) { return [o.order_no, o.created_at, o.customer, o.subtotal, o.discount, o.tax, o.total, o.order_status, o.payment_status]; }));
  n.payments = writeSheet_(ss, 'Payments', ['Order', 'Metode', 'Jumlah', 'Status', 'Diverifikasi'],
    rep.payments.map(function (p) { return [p.order_no, p.method, p.amount, p.status, p.verified_at || '']; }));
  n.inventory = writeSheet_(ss, 'Inventory', ['Part', 'Kategori', 'Satuan', 'Stok', 'Min', 'Stok rendah'],
    rep.inventory.map(function (i) { return [i.name, i.category, i.unit, i.quantity, i.min_stock, i.low ? 'YA' : '']; }));
  n.summary = writeSheet_(ss, 'Summary', ['Periode', 'Jumlah order', 'Pendapatan terverifikasi', 'Disinkron'],
    [[from + ' s/d ' + to, rep.summary.orders, rep.summary.revenue_verified, rep.generated_at]]);
  return n;
}

function installDailyTrigger() {
  ScriptApp.getProjectTriggers().forEach(function (t) { if (t.getHandlerFunction() === 'syncReports') ScriptApp.deleteTrigger(t); });
  ScriptApp.newTrigger('syncReports').timeBased().atHour(23).nearMinute(30).everyDays(1).inTimezone('Asia/Jakarta').create();
}
