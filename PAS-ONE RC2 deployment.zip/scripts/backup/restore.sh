#!/usr/bin/env bash
# Restore a PAS-One backup into a database that ALREADY has the schema (apply supabase/migrations first) and is EMPTY.
# Usage: restore.sh <pas-*.tar.enc>    Env: TARGET_DATABASE_URL, BACKUP_PASSPHRASE
# Restore into a scratch/dev database first (restore drill). Never run against production without owner approval.
set -euo pipefail
F="${1:?usage: restore.sh file.tar.enc}"; : "${TARGET_DATABASE_URL:?}"; : "${BACKUP_PASSPHRASE:?}"
M="${F%.tar.enc}.manifest.json"; [ -f "$M" ] || { echo "manifest missing"; exit 2; }
EXP=$(python3 -c "import json;print(json.load(open('$M'))['sha256_enc'])"); GOT=$(sha256sum "$F" | cut -d' ' -f1)
[ "$EXP" = "$GOT" ] || { echo "CHECKSUM MISMATCH - backup corrupted or tampered"; exit 3; }
P="psql $TARGET_DATABASE_URL -v ON_ERROR_STOP=1 -At"
[ "$($P -c "select count(*) from public.profiles")" = 0 ] || { echo "target not empty (public.profiles has rows) - refusing"; exit 5; }
W=$(mktemp -d); trap 'rm -rf "$W"' EXIT
openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 -in "$F" -out "$W/b.tar" -pass env:BACKUP_PASSPHRASE; tar -C "$W" -xf "$W/b.tar"
if [ -f "$W/auth.dump" ]; then
  $P -c "alter table auth.users disable trigger on_auth_user_created" >/dev/null     # else the trigger would pre-create blank profiles
  pg_restore --data-only --no-owner --exit-on-error -d "$TARGET_DATABASE_URL" "$W/auth.dump"
  $P -c "alter table auth.users enable trigger on_auth_user_created" >/dev/null
fi
$P -c "truncate public.settings" >/dev/null      # migrations seed defaults; the backed-up (owner-edited) values must replace them
pg_restore --data-only --no-owner --exit-on-error -d "$TARGET_DATABASE_URL" "$W/public.dump"
FAILS=0
while IFS='|' read -r t c; do
  [ -z "$t" ] && continue; N=$($P -c "select count(*) from public.\"$t\"")
  if [ "$N" = "$c" ]; then echo "ok   $t $N"; else echo "DIFF $t expected=$c got=$N"; FAILS=$((FAILS+1)); fi
done < <(python3 -c "import json;[print(f'{k}|{v}') for k,v in json.load(open('$M'))['row_counts'].items()]")
[ "$FAILS" = 0 ] && echo "RESTORE VERIFIED" || { echo "RESTORE VERIFICATION FAILED ($FAILS tables)"; exit 4; }
