#!/usr/bin/env bash
# PAS-One encrypted DATA backup (Supabase Free has no automatic daily backups).
# Schema is NOT in the backup: it comes from supabase/migrations (Git is the source of truth). Manifest records the migration set.
# Env: DATABASE_URL (direct or session-pooler URL, NOT the transaction pooler), BACKUP_PASSPHRASE,
#      BACKUP_DIR (default ./backups), KEEP_DAILY (14), KEEP_WEEKLY (8), GIT_SHA (optional)
# Needs pg_dump >= server major version. Output: pas-<UTC>.tar.enc + pas-<UTC>.manifest.json
set -euo pipefail
: "${DATABASE_URL:?}"; : "${BACKUP_PASSPHRASE:?}"
DIR="${BACKUP_DIR:-./backups}"; mkdir -p "$DIR"; chmod 700 "$DIR" || echo "warning: could not chmod 700 $DIR" >&2
TS=$(date -u +%Y%m%dT%H%M%SZ); BASE="$DIR/pas-$TS"; W=$(mktemp -d); trap 'rm -rf "$W"' EXIT
pg_dump "$DATABASE_URL" -Fc --data-only --no-owner --no-privileges -n public -f "$W/public.dump"
AUTH_T=(); for t in users identities; do [ "$(psql "$DATABASE_URL" -At -c "select to_regclass('auth.$t') is not null")" = t ] && AUTH_T+=(-t "auth.$t"); done
[ ${#AUTH_T[@]} -gt 0 ] && pg_dump "$DATABASE_URL" -Fc --data-only --no-owner --no-privileges "${AUTH_T[@]}" -f "$W/auth.dump"
psql "$DATABASE_URL" -At -F'|' -c "select table_name, (xpath('/row/c/text()', query_to_xml(format('select count(*) c from public.%I', table_name), false, true, '')))[1]::text::bigint from information_schema.tables where table_schema='public' and table_type='BASE TABLE' order by 1" > "$W/counts"
tar -C "$W" -cf "$W/bundle.tar" public.dump $( [ -f "$W/auth.dump" ] && echo auth.dump )
openssl enc -aes-256-cbc -pbkdf2 -iter 200000 -salt -in "$W/bundle.tar" -out "$BASE.tar.enc" -pass env:BACKUP_PASSPHRASE
SHA=$(sha256sum "$BASE.tar.enc" | cut -d' ' -f1)
MIG=$(ls "$(dirname "$0")/../../supabase/migrations" 2>/dev/null | tr '\n' ' ')
python3 - "$BASE" "$TS" "$SHA" "$W/counts" "${GIT_SHA:-unknown}" "$MIG" <<'PY'
import json,sys; b,ts,sha,cf,git,mig=sys.argv[1:7]
counts={l.split('|')[0]:int(l.split('|')[1]) for l in open(cf).read().split('\n') if l}
json.dump({'created_utc':ts,'sha256_enc':sha,'cipher':'aes-256-cbc pbkdf2 200000','git_sha':git,'migrations':mig.split(),'row_counts':counts},open(b+'.manifest.json','w'),indent=1)
PY
chmod 600 "$BASE".*
# retention: newest KEEP_DAILY backups + newest of each ISO week for KEEP_WEEKLY weeks
KD=${KEEP_DAILY:-14}; KW=${KEEP_WEEKLY:-8}
ls -1 "$DIR"/pas-*.tar.enc 2>/dev/null | sort -r | python3 -c "
import sys,re,datetime
kd,kw=$KD,$KW; files=[l.strip() for l in sys.stdin]; seen=set(); w=0
for i,f in enumerate(files):
    if i<kd: continue
    d=datetime.datetime.strptime(re.search(r'pas-(\d{8})',f).group(1),'%Y%m%d'); wk=d.isocalendar()[:2]
    if wk not in seen and w<kw: seen.add(wk); w+=1; continue
    print(f)" | while read -r old; do rm -f "$old" "${old%.tar.enc}.manifest.json"; done
echo "backup ok: $BASE.tar.enc ($(du -h "$BASE.tar.enc" | cut -f1)) sha256=$SHA"
