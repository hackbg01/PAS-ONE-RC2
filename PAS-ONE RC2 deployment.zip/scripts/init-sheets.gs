// PAS-One Google Sheets Initialization Script
// Run this in Google Apps Script Editor to setup database

function initializeDatabase() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  // Step 1: Create all sheets
  const sheetNames = [
    'Users', 'Catalog', 'Orders', 'Payments', 'Emergency',
    'Inventory', 'InventoryMutations', 'DiscountRequests',
    'AuditLog', 'Settings'
  ];

  Logger.log('Creating sheets...');
  sheetNames.forEach(name => {
    if (!ss.getSheetByName(name)) {
      ss.insertSheet(name);
      Logger.log(`✓ Created ${name}`);
    }
  });

  // Step 2: Add headers
  addHeaders(ss);

  // Step 3: Seed test data
  seedTestData(ss);

  Logger.log('✓ Database initialization complete!');
}

function addHeaders(ss) {
  Logger.log('Adding headers...');

  // Users
  ss.getSheetByName('Users').getRange(1, 1, 1, 7)
    .setValues([['userId', 'email', 'passwordHash', 'name', 'role', 'createdAt', 'active']]);

  // Catalog
  ss.getSheetByName('Catalog').getRange(1, 1, 1, 8)
    .setValues([['itemId', 'name', 'category', 'description', 'price', 'stock', 'active', 'createdAt']]);

  // Orders
  ss.getSheetByName('Orders').getRange(1, 1, 1, 11)
    .setValues([['orderId', 'customerId', 'customerData', 'items', 'subtotal', 'tax', 'total', 'orderStatus', 'paymentStatus', 'createdAt', 'createdBy']]);

  // Payments
  ss.getSheetByName('Payments').getRange(1, 1, 1, 9)
    .setValues([['paymentId', 'orderId', 'amount', 'status', 'method', 'proofUrl', 'verifiedBy', 'verifiedAt', 'createdAt']]);

  // Emergency
  ss.getSheetByName('Emergency').getRange(1, 1, 1, 13)
    .setValues([['ticketId', 'customerId', 'customerName', 'customerPhone', 'lat', 'lng', 'complaint', 'status', 'assignedTo', 'estimatedCost', 'actualCost', 'createdAt', 'completedAt']]);

  // Inventory
  ss.getSheetByName('Inventory').getRange(1, 1, 1, 9)
    .setValues([['partId', 'name', 'category', 'unit', 'quantity', 'minStock', 'price', 'supplier', 'createdAt']]);

  // InventoryMutations
  ss.getSheetByName('InventoryMutations').getRange(1, 1, 1, 8)
    .setValues([['mutationId', 'partId', 'type', 'quantity', 'reason', 'referenceId', 'createdBy', 'createdAt']]);

  // DiscountRequests
  ss.getSheetByName('DiscountRequests').getRange(1, 1, 1, 11)
    .setValues([['requestId', 'orderId', 'originalAmount', 'discountAmount', 'finalAmount', 'reason', 'requestedBy', 'approvedBy', 'status', 'createdAt', 'decidedAt']]);

  // AuditLog
  ss.getSheetByName('AuditLog').getRange(1, 1, 1, 6)
    .setValues([['logId', 'timestamp', 'action', 'resource', 'details', 'user']]);

  // Settings
  ss.getSheetByName('Settings').getRange(1, 1, 1, 4)
    .setValues([['key', 'value', 'type', 'description']]);

  Logger.log('✓ Headers added');
}

function seedTestData(ss) {
  Logger.log('Seeding test data...');

  // Admin user
  const adminPassword = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, 'admin123');
  const usersSheet = ss.getSheetByName('Users');
  usersSheet.appendRow([
    Utilities.getUuid(),
    'admin@pasone.local',
    Utilities.base64Encode(adminPassword),
    'Administrator',
    'admin',
    new Date(),
    true
  ]);

  // Sample catalog items
  const catalogSheet = ss.getSheetByName('Catalog');
  const sampleItems = [
    [Utilities.getUuid(), 'Ganti Oli 10W-40', 'oli', 'Ganti oli mesin standar', 150000, 50, true, new Date()],
    [Utilities.getUuid(), 'Service Rutin A', 'jasa', 'Kuras oli, ganti filter, cek komponen', 200000, 999, true, new Date()],
    [Utilities.getUuid(), 'Ban Michelin 195/65/R15', 'spare-part', 'Ban berkualitas tinggi', 800000, 10, true, new Date()],
    [Utilities.getUuid(), 'Air Filter', 'spare-part', 'Filter udara replacement', 75000, 25, true, new Date()],
    [Utilities.getUuid(), 'Busi NGK', 'spare-part', 'Busi standar kendaraan', 45000, 40, true, new Date()]
  ];
  sampleItems.forEach(item => catalogSheet.appendRow(item));

  // Default settings
  const settingsSheet = ss.getSheetByName('Settings');
  const settings = [
    ['NORMAL_HOURS_START', '06:00', 'string', 'Jam kerja mulai (Palembang)'],
    ['NORMAL_HOURS_END', '18:00', 'string', 'Jam kerja selesai'],
    ['FREE_RADIUS_KM', '30', 'number', 'Radius layanan gratis'],
    ['DISTANCE_FEE_PER_KM', '10000', 'number', 'Biaya per km kelebihan'],
    ['GUEST_VISIT_FEE', '250000', 'number', 'Biaya visit untuk guest'],
    ['OFF_HOURS_VISIT_FEE', '250000', 'number', 'Biaya visit di luar jam normal'],
    ['TAX_PERCENTAGE', '10', 'number', 'Pajak dalam persen']
  ];
  settings.forEach(setting => settingsSheet.appendRow(setting));

  Logger.log('✓ Test data seeded');
  Logger.log('');
  Logger.log('TEST ACCOUNTS:');
  Logger.log('Email: admin@pasone.local');
  Logger.log('Password: admin123');
  Logger.log('Role: admin');
}

function seedMechanicsAndManagers() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const usersSheet = ss.getSheetByName('Users');

  // Mechanic user
  const mechanicPassword = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, 'mechanic123');
  usersSheet.appendRow([
    Utilities.getUuid(),
    'mechanic@pasone.local',
    Utilities.base64Encode(mechanicPassword),
    'Mekanik Prima',
    'mechanic',
    new Date(),
    true
  ]);

  // Manager user
  const managerPassword = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, 'manager123');
  usersSheet.appendRow([
    Utilities.getUuid(),
    'manager@pasone.local',
    Utilities.base64Encode(managerPassword),
    'Manager',
    'manager',
    new Date(),
    true
  ]);

  Logger.log('✓ Mechanic and Manager accounts created');
  Logger.log('Mechanic: mechanic@pasone.local / mechanic123');
  Logger.log('Manager: manager@pasone.local / manager123');
}

function clearTestData() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheets = ['Users', 'Catalog', 'Orders', 'Payments', 'Emergency',
                  'Inventory', 'DiscountRequests', 'AuditLog'];

  Logger.log('Clearing all data (keeping headers)...');
  sheets.forEach(sheetName => {
    const sheet = ss.getSheetByName(sheetName);
    if (sheet && sheet.getLastRow() > 1) {
      sheet.deleteRows(2, sheet.getLastRow() - 1);
      Logger.log(`✓ Cleared ${sheetName}`);
    }
  });
}

function testConnection() {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName('Users');
    const data = sheet.getDataRange().getValues();

    Logger.log('✓ Connection successful');
    Logger.log(`✓ Users sheet has ${data.length} rows (including header)`);

    if (data.length > 1) {
      Logger.log(`✓ Sample user: ${data[1][1]} (${data[1][4]})`);
    }
  } catch (error) {
    Logger.log('✗ Connection failed: ' + error.message);
  }
}
