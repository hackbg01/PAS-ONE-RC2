#!/bin/bash
# Build pase2e DB (migrations + fixtures) and start PostgREST on :3111 (local E2E for the frontend adapter)
D=$(cd "$(dirname "$0")" && pwd)
pkill postgrest 2>/dev/null; sleep 1
pg_ctlcluster 16 main start 2>/dev/null; sleep 2
su postgres -c "psql -q -c 'drop database if exists pase2e' -c 'create database pase2e'" || { echo 'cannot recreate DB'; exit 1; }
for f in 00_supabase_stub.sql ../migrations/0001_foundation.sql ../migrations/0002_security.sql ../migrations/0003_rpc.sql e2e_fixtures.sql; do su postgres -c "psql -q -v ON_ERROR_STOP=1 -d pase2e -f $D/$f" || { echo FAIL $f; exit 1; }; done
pkill postgrest 2>/dev/null
cat > /tmp/pgrst.conf <<CONF
db-uri = "postgres://authenticator:authpw@localhost:5432/pase2e"
db-schemas = "public"
db-anon-role = "anon"
jwt-secret = "e2e-test-secret-e2e-test-secret-1234"
server-port = 3111
CONF
nohup ${POSTGREST_BIN:-/home/claude/tools/postgrest} /tmp/pgrst.conf > /tmp/pgrst.log 2>&1 &
sleep 3; curl -s "http://localhost:3111/catalog_items?select=name&limit=1"; echo
