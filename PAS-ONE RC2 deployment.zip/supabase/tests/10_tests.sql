\set ON_ERROR_STOP 0
\set QUIET 1
set client_min_messages = notice;
create schema if not exists t;
create or replace function t.check(n text, c boolean) returns void language plpgsql as $$ begin raise notice '% : %', case when c then 'PASS' else 'FAIL' end, n; end $$;
create or replace function t.as_user(u uuid, anon boolean default false) returns void language plpgsql as $$ begin
  execute 'reset role';
  perform set_config('request.jwt.claims', json_build_object('sub',u,'is_anonymous',anon,'role','authenticated')::text, false);
  execute 'set role authenticated'; end $$;
create or replace function t.as_anon() returns void language plpgsql as $$ begin
  execute 'reset role'; perform set_config('request.jwt.claims','{}',false); execute 'set role anon'; end $$;
create or replace function t.su() returns void language plpgsql as $$ begin execute 'reset role'; end $$;
create or replace function t.err(q text) returns text language plpgsql as $$ begin execute q; return 'OK'; exception when others then return sqlerrm; end $$;
grant usage on schema t to anon, authenticated; grant execute on all functions in schema t to anon, authenticated;

-- fixtures (as superuser)
insert into auth.users(id,email,raw_user_meta_data) values
 ('00000000-0000-0000-0000-0000000000a1','alice@t','{"name":"Alice"}'),
 ('00000000-0000-0000-0000-0000000000b2','bob@t','{"name":"Bob"}'),
 ('00000000-0000-0000-0000-0000000000c3','carl@t','{"name":"Carl","role":"admin"}'),   -- tries to self-assign admin via metadata
 ('00000000-0000-0000-0000-0000000000d4','admin@t','{}'),
 ('00000000-0000-0000-0000-0000000000e5','mgr@t','{}'),
 ('00000000-0000-0000-0000-0000000000f6','mech@t','{}'),
 ('00000000-0000-0000-0000-0000000000a7','guest@t','{}');
update public.profiles set role='admin' where id='00000000-0000-0000-0000-0000000000d4';
update public.profiles set role='manager' where id='00000000-0000-0000-0000-0000000000e5';
update public.profiles set role='mechanic' where id='00000000-0000-0000-0000-0000000000f6';
insert into public.catalog_items(id,name,category,price,stock,track_stock) values
 ('10000000-0000-0000-0000-000000000001','Oli',  'oli',150000,5,true),
 ('10000000-0000-0000-0000-000000000002','Servis','jasa',200000,999,false),
 ('10000000-0000-0000-0000-000000000003','Busi', 'part',45000,100,true);
insert into public.parts(id,name,quantity,min_stock) values ('20000000-0000-0000-0000-000000000001','Kampas',5,2);

do $$ declare A uuid:='00000000-0000-0000-0000-0000000000a1'; B uuid:='00000000-0000-0000-0000-0000000000b2';
 C uuid:='00000000-0000-0000-0000-0000000000c3'; ADM uuid:='00000000-0000-0000-0000-0000000000d4';
 MG uuid:='00000000-0000-0000-0000-0000000000e5'; ME uuid:='00000000-0000-0000-0000-0000000000f6'; G uuid:='00000000-0000-0000-0000-0000000000a7';
 r jsonb; r2 jsonb; oa uuid; ob uuid; n int; st int; tot numeric; s text;
begin
 -- IDENTITY
 perform t.check('T1 metadata role=admin ignored (stays customer)', (select role from public.profiles where id=C)='customer');

 -- PRICING / VALIDATION
 perform t.as_user(A);
 r := public.create_order('[{"id":"10000000-0000-0000-0000-000000000001","quantity":2,"price":1}]','{"name":"Alice W"}','key-A-1');
 oa := (r->>'orderId')::uuid;
 perform t.check('T2 server price used (client price=1 ignored): total=(2*150000)*1.11=333000', (r->>'total')::numeric = 333000);
 perform t.check('T3 qty 0 rejected', t.err($q$select public.create_order('[{"id":"10000000-0000-0000-0000-000000000001","quantity":0}]')$q$) like 'invalid items%');
 perform t.check('T3b negative qty rejected', t.err($q$select public.create_order('[{"id":"10000000-0000-0000-0000-000000000001","quantity":-3}]')$q$) like 'invalid items%');
 perform t.check('T3c huge qty rejected', t.err($q$select public.create_order('[{"id":"10000000-0000-0000-0000-000000000001","quantity":100000}]')$q$) like 'invalid items%');
 perform t.check('T3d unknown item rejected', t.err($q$select public.create_order('[{"id":"99999999-0000-0000-0000-000000000001","quantity":1}]')$q$) like 'item not found%');
 perform t.check('T4 oversell blocked (stock 3 left, want 5)', t.err($q$select public.create_order('[{"id":"10000000-0000-0000-0000-000000000001","quantity":5}]')$q$) like 'insufficient stock%');
 perform t.su(); perform t.check('T4b stock unchanged by failed order (=3)', (select stock from public.catalog_items where id='10000000-0000-0000-0000-000000000001')=3);
 perform t.as_user(A);
 r2 := public.create_order('[{"id":"10000000-0000-0000-0000-000000000001","quantity":2}]','{}','key-A-1');
 perform t.check('T5 idempotency: same key returns same order, duplicate=true', (r2->>'orderId')=(r->>'orderId') and (r2->>'duplicate')::boolean);
 perform t.su(); perform t.check('T5b stock decremented once (=3)', (select stock from public.catalog_items where id='10000000-0000-0000-0000-000000000001')=3);

 -- ISOLATION (RLS)
 perform t.as_user(B);
 r := public.create_order('[{"id":"10000000-0000-0000-0000-000000000003","quantity":1}]'); ob := (r->>'orderId')::uuid;
 select count(*) into n from public.orders; perform t.check('T6 customer B sees only own orders (1)', n=1);
 select count(*) into n from public.orders where id=oa; perform t.check('T6b B cannot read A''s order', n=0);
 select count(*) into n from public.order_items where order_id=oa; perform t.check('T6c B cannot read A''s order_items', n=0);
 perform t.check('T7 customer cannot escalate role', t.err($q$update public.profiles set role='admin' where id='00000000-0000-0000-0000-0000000000b2'$q$) like 'permission denied%');
 perform t.check('T7b customer cannot INSERT order directly', t.err($q$insert into public.orders(order_no,subtotal,tax,total) values('X',0,0,0)$q$) like 'permission denied%');
 perform t.check('T7c customer cannot UPDATE order total directly', t.err($q$update public.orders set total=1$q$) like 'permission denied%');
 perform t.check('T7d customer cannot verify_payment', t.err(format('select public.verify_payment(%L)', oa)) like 'forbidden%');
 perform t.err($q$update public.catalog_items set price=1$q$); perform t.su(); perform t.check('T7e customer cannot edit catalog (RLS: price unchanged)', (select min(price) from public.catalog_items)=45000); perform t.as_user(B);
 select count(*) into n from public.audit_logs; perform t.check('T7f customer sees 0 audit rows', n=0);
 perform t.check('T7g customer cannot call dashboard', t.err($q$select public.dashboard_summary('admin')$q$) like 'forbidden%');
 perform t.check('T7h customer cannot read parts', (select count(*) from public.parts)=0);
 perform t.check('T7i customer cannot call admin_set_role', t.err($q$select public.admin_set_role('00000000-0000-0000-0000-0000000000b2','admin')$q$) like 'forbidden%');
 perform t.check('T7j B cannot cancel A''s order', t.err(format($q$select public.update_order_status(%L,'cancelled')$q$, oa)) like 'forbidden%');
 perform t.check('T7k B cannot pay A''s order', t.err(format($q$select public.submit_payment(%L,'qris')$q$, oa)) like 'forbidden%');

 -- ANON / forged identity
 perform t.as_anon();
 perform t.check('T8 anon can read active catalog', (select count(*) from public.catalog_items)=3);
 perform t.check('T8b anon cannot read orders', t.err('select * from public.orders') like 'permission denied%');
 perform t.check('T8c anon cannot create order', t.err($q$select public.create_order('[{"id":"10000000-0000-0000-0000-000000000001","quantity":1}]')$q$) like 'permission denied%');
 perform t.as_user('00000000-0000-0000-0000-00000000dead');
 perform t.check('T8d forged uid with no profile rejected', t.err($q$select public.create_order('[{"id":"10000000-0000-0000-0000-000000000001","quantity":1}]')$q$) like 'unauthorized%');

 -- PAYMENT FLOW
 perform t.as_user(A); r := public.submit_payment(oa,'qris','https://example.com/p.jpg','pay-1');
 r2 := public.submit_payment(oa,'qris','https://example.com/p.jpg','pay-1');
 perform t.check('T9 submit_payment idempotent', (r2->>'duplicate')::boolean and r->>'paymentId'=r2->>'paymentId');
 perform t.check('T9b proof url must be https', t.err(format($q$select public.submit_payment(%L,'qris','javascript:alert(1)')$q$, oa)) like '%payments_proof_url_check%');
 perform t.as_user(MG); r := public.verify_payment(oa); r2 := public.verify_payment(oa);
 perform t.check('T10 verify ok then duplicate is no-op', not (r->>'alreadyVerified')::boolean and (r2->>'alreadyVerified')::boolean);
 perform t.su();
 perform t.check('T10b exactly one verified payment', (select count(*) from public.payments where order_id=oa and status='verified')=1);
 perform t.check('T10c order status payment_verified', (select order_status::text||'/'||payment_status::text from public.orders where id=oa)='payment_verified/verified');
 perform t.check('T10d verifier recorded server-side', (select verified_by from public.payments where order_id=oa and status='verified')=MG);
 perform t.as_user(A);
 perform t.check('T11 customer cannot cancel after payment verified', t.err(format($q$select public.update_order_status(%L,'cancelled')$q$, oa)) like 'forbidden%');
 perform t.check('T11b customer cannot set completed', t.err(format($q$select public.update_order_status(%L,'completed')$q$, oa)) like 'invalid transition%');
 perform t.as_user(MG);
 perform t.check('T11c invalid transition payment_verified->completed rejected', t.err(format($q$select public.update_order_status(%L,'completed')$q$, oa)) like 'invalid transition%');
 perform t.check('T11d status payment_verified not settable via update_order_status', t.err(format($q$select public.update_order_status(%L,'payment_verified')$q$, ob)) like 'use verify_payment%');
 perform public.assign_order_mechanic(oa, ME); perform public.update_order_status(oa,'in_progress');
 perform t.as_user(ME); perform public.update_order_status(oa,'completed');
 perform t.su(); perform t.check('T12 assigned mechanic completes order', (select order_status from public.orders where id=oa)='completed');
 perform t.as_user(ME); perform t.check('T12b unassigned mechanic cannot move order', t.err(format($q$select public.update_order_status(%L,'cancelled')$q$, ob)) like 'forbidden%' or t.err(format($q$select public.update_order_status(%L,'cancelled')$q$, ob)) like 'invalid transition%');

 -- CANCEL RESTORES STOCK
 perform t.as_user(B); perform public.update_order_status(ob,'cancelled');
 perform t.su(); perform t.check('T13 cancel returns stock (busi 100)', (select stock from public.catalog_items where id='10000000-0000-0000-0000-000000000003')=100);

 -- DISCOUNT
 perform t.as_user(B); r := public.create_order('[{"id":"10000000-0000-0000-0000-000000000002","quantity":1}]'); ob := (r->>'orderId')::uuid;
 perform t.as_user(ME); perform t.check('T14a mechanic cannot request discount on unassigned order', t.err(format($q$select public.request_discount(%L,20000,'loyal')$q$, ob)) like '%assigned orders%');
 perform t.as_user(MG); perform public.assign_order_mechanic(ob, ME); perform t.as_user(ME);
 perform t.check('T14 mechanic can request discount on assigned order', (public.request_discount(ob,20000,'loyal')->>'success')::boolean);
 perform t.check('T14b duplicate open request blocked', t.err(format($q$select public.request_discount(%L,1000,'xx x')$q$, ob)) like '%already open%');
 perform t.as_user(ME); perform t.check('T14c mechanic cannot approve', t.err(format($q$select public.decide_discount(%L,true)$q$, (select id from public.discount_requests limit 1))) is not null);
 perform t.su(); perform t.as_user(MG);
 perform public.decide_discount((select id from public.discount_requests where order_id=ob),true);
 perform t.su(); select total into tot from public.orders where id=ob;
 perform t.check('T15 approved discount recalculated server-side: (200000-20000)*1.11=199800', tot=199800);
 perform t.as_user(MG); perform t.check('T15b excessive discount rejected', t.err(format($q$select public.request_discount(%L,999999999,'too much')$q$, ob)) like '%invalid discount%');

 -- INVENTORY
 perform t.as_user(ME);
 perform t.check('T16 stock-out beyond quantity rejected', t.err($q$select public.inventory_mutation('20000000-0000-0000-0000-000000000001','out',9)$q$) like 'insufficient stock%');
 perform t.check('T16b valid stock-out', (public.inventory_mutation('20000000-0000-0000-0000-000000000001','out',4)->>'quantity')::int=1);
 perform t.check('T16c mechanic cannot upsert_parts', t.err($q$select public.upsert_parts('[{"name":"x"}]')$q$) like 'forbidden%');
 perform t.as_user(MG); perform t.check('T16d manager CSV-style upsert', (public.upsert_parts('[{"name":"Filter","quantity":3,"price":50000},{"name":"Kampas","price":99000}]')->>'created')::int=1);

 -- EMERGENCY (server-side fees)
 perform t.as_user(G,true); r := public.create_emergency(-2.915,104.758,'mogok','Tamu','081234567890','em-1');
 perform t.su(); perform t.check('T17 guest (retail) at base: 250000 by day / 300000 at night, no distance fee', (r->>'estimatedCost')::numeric = public._visit_fee(false, extract(hour from now() at time zone 'Asia/Jakarta')::int) and (r->>'distanceFee')::numeric=0);
 perform t.check('T17g _visit_fee not callable by clients', (select count(*) from (select 1) x where has_function_privilege('authenticated','public._visit_fee(boolean,int)','execute'))=0);
 perform t.check('T17f visit fee rules: fleet 250k all hours; retail 250k day, 300k 22-06', public._visit_fee(true,3)=250000 and public._visit_fee(true,12)=250000 and public._visit_fee(false,12)=250000 and public._visit_fee(false,21)=250000 and public._visit_fee(false,22)=300000 and public._visit_fee(false,23)=300000 and public._visit_fee(false,0)=300000 and public._visit_fee(false,5)=300000 and public._visit_fee(false,6)=250000);
 perform t.as_user(G,true); r2 := public.create_emergency(-2.915,104.758,'mogok','Tamu','081234567890','em-1');
 perform t.check('T17b emergency idempotent', (r2->>'duplicate')::boolean);
 r := public.create_emergency(-2.415,104.758,'jauh');   -- ~55.6 km north
 perform t.check('T17c distance fee: ~(55.6-30)*10000 + guest 250000 ≈ 506k', (r->>'estimatedCost')::numeric between 500000 and 512000);
 perform t.check('T17d bad coordinates rejected', t.err($q$select public.create_emergency(95,0)$q$) like 'invalid coordinates%');
 perform t.as_user(A); perform t.check('T17e customer cannot see others'' tickets', (select count(*) from public.emergency_tickets)=0);
 perform t.as_user(MG); perform public.assign_mechanic((select id from public.emergency_tickets limit 1), ME);
 perform t.as_user(ME); perform public.update_emergency_status((select id from public.emergency_tickets where assigned_to=ME), 'in_progress');
 perform t.check('T18 mechanic shares location on own ticket', (public.share_location((select id from public.emergency_tickets where assigned_to=ME),-2.9,104.7)->>'success')::boolean);

 -- DASHBOARD / AUDIT
 perform t.as_user(MG); r := public.dashboard_summary('management');
 perform t.check('T19 dashboard real aggregates (bookingToday>=2, not mock 5)', (r->>'bookingToday')::int >= 2 and (r->>'revenue')::numeric <> 5000000);
 perform t.check('T19b manager reads audit', (select count(*) from public.audit_logs) > 5);
 perform t.su();
 perform t.check('T20 audit logs contain no password/token keys', (select count(*) from public.audit_logs where details ? 'password' or details ? 'token')=0);
 perform t.as_user(A); perform t.check('T21c customer cannot set own customer_type', t.err($q$select public.admin_set_customer_type('00000000-0000-0000-0000-0000000000a1','fleet')$q$) like 'forbidden%' and t.err($q$update public.profiles set customer_type='fleet' where id='00000000-0000-0000-0000-0000000000a1'$q$) like 'permission denied%');
 perform t.as_user(ADM); perform t.check('T21d admin sets fleet', (public.admin_set_customer_type(A,'fleet')->>'success')::boolean);
 perform t.as_user(ADM); perform t.check('T21 admin changes role', (public.admin_set_role(B,'mechanic')->>'success')::boolean);
 perform t.check('T21b admin cannot change own role', t.err(format($q$select public.admin_set_role(%L,'customer')$q$, ADM)) like 'cannot change own role%');
end $$;
