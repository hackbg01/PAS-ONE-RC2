\set QUIET 1
set client_min_messages = notice;
do $$ declare A uuid:='00000000-0000-0000-0000-0000000000a1'; B uuid:='00000000-0000-0000-0000-0000000000b2'; MG uuid:='00000000-0000-0000-0000-0000000000e5';
 r jsonb; k text; o jsonb; pid uuid; n int;
begin
 perform t.as_user(A); k := 'payment_proof/'||A||'/'||gen_random_uuid()||'.jpg';
 perform t.check('M1 register own media', (public.register_media(k,'payment_proof','image/jpeg',120000)->>'success')::boolean);
 perform t.check('M2 cannot register key under another user''s folder', t.err(format($q$select public.register_media(%L,'payment_proof','image/jpeg',1000)$q$, 'payment_proof/'||B||'/'||gen_random_uuid()||'.jpg')) like 'invalid media key%');
 perform t.check('M3 bad mime rejected', t.err(format($q$select public.register_media(%L,'payment_proof','text/html',1000)$q$, 'payment_proof/'||A||'/'||gen_random_uuid()||'.pdf')) like 'unsupported type%');
 perform t.check('M4 oversize rejected (>5MB)', t.err(format($q$select public.register_media(%L,'payment_proof','image/png',9999999)$q$, 'payment_proof/'||A||'/'||gen_random_uuid()||'.png')) like 'invalid size%');
 perform t.check('M5 path traversal key rejected', t.err($q$select public.register_media('payment_proof/../../x.jpg','payment_proof','image/jpeg',10)$q$) like 'invalid media key%');
 perform t.check('M6 customer cannot register catalog_image', t.err(format($q$select public.register_media(%L,'catalog_image','image/png',1000)$q$, 'catalog_image/'||A||'/'||gen_random_uuid()||'.png')) like 'forbidden%');
 perform t.check('M7 owner can read', public.can_read_media(k));
 perform t.as_user(B); perform t.check('M8 other customer cannot read', not public.can_read_media(k));
 perform t.as_user(MG); perform t.check('M9 manager can read payment proof', public.can_read_media(k));
 -- attach proof to a payment
 perform t.as_user(A); o := public.create_order('[{"id":"10000000-0000-0000-0000-000000000002","quantity":1}]');
 r := public.submit_payment((o->>'orderId')::uuid,'qris',null); pid := (r->>'paymentId')::uuid;
 perform t.check('M10 attach proof to own pending payment', (public.attach_payment_proof(pid,k)->>'success')::boolean);
 perform t.as_user(B); perform t.check('M11 other user cannot attach media', t.err(format($q$select public.attach_payment_proof(%L,%L)$q$, pid, k)) like 'media not found%');
 -- reports
 perform t.as_user(A); perform t.check('M12 customer cannot export reports', t.err($q$select public.report_export(current_date-1,current_date)$q$) like 'forbidden%');
 perform t.as_user(MG); r := public.report_export(current_date-1,current_date+1);
 perform t.check('M13 manager export has orders/payments/inventory/summary', jsonb_array_length(r->'orders')>=1 and r?'payments' and r?'inventory' and (r->'summary'->>'orders')::int>=1);
 perform t.check('M14 export range capped at 92 days', t.err($q$select public.report_export(current_date-200,current_date)$q$) like 'invalid range%');
 perform t.check('M15 export contains no phone/email columns', not (r::text like '%customer_phone%' or r::text like '%"email"%'));
end $$;
