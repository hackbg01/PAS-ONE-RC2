do $$ begin create role authenticator noinherit login password 'authpw'; exception when duplicate_object then null; end $$;
grant anon, authenticated to authenticator;
insert into auth.users(id,email,raw_user_meta_data) values
 ('00000000-0000-0000-0000-0000000000a1','alice@t','{"name":"Alice"}'),
 ('00000000-0000-0000-0000-0000000000b2','bob@t','{"name":"Bob"}'),
 ('00000000-0000-0000-0000-0000000000d4','admin@t','{"name":"Admin"}'),
 ('00000000-0000-0000-0000-0000000000e5','mgr@t','{"name":"Manager"}'),
 ('00000000-0000-0000-0000-0000000000f6','mech@t','{"name":"Mekanik"}'),
 ('00000000-0000-0000-0000-0000000000a7','guest@t','{}');
update public.profiles set role='admin' where email='admin@t';
update public.profiles set role='manager' where email='mgr@t';
update public.profiles set role='mechanic' where email='mech@t';
insert into public.catalog_items(id,name,category,description,price,stock,track_stock) values
 ('10000000-0000-0000-0000-000000000001','Ganti Oli 10W-40','oli','Ganti oli mesin',150000,5,true),
 ('10000000-0000-0000-0000-000000000002','Service Rutin A','jasa','Kuras oli',200000,999,false),
 ('10000000-0000-0000-0000-000000000003','<img src=x onerror=alert(1)>','spare-part','xss probe',45000,100,true);
