#!/bin/bash
# Needs the DB from run_all.sh. Real parallel sessions against Postgres (not a load test of Supabase itself).
P="su postgres -c"
$P "psql -q -d pastest" <<'SQL'
truncate public.discount_requests, public.mechanic_locations, public.emergency_tickets, public.payments, public.order_items, public.orders cascade; delete from public.catalog_items where name='RACE';
insert into public.catalog_items(id,name,price,stock) values ('30000000-0000-0000-0000-000000000001','RACE',10000,10);
insert into auth.users(id,email) select ('40000000-0000-0000-0000-'||lpad(g::text,12,'0'))::uuid,'u'||g||'@t' from generate_series(1,30) g on conflict do nothing;
SQL
echo "--- 30 concurrent buyers, stock 10, qty 1 each"
start=$(date +%s.%N)
for g in $(seq 1 30); do
  ( uid="40000000-0000-0000-0000-$(printf %012d $g)"
    su postgres -c "psql -q -At -d pastest -c \"set role authenticated; select set_config('request.jwt.claims','{\\\"sub\\\":\\\"$uid\\\"}',false); select public.create_order('[{\\\"id\\\":\\\"30000000-0000-0000-0000-000000000001\\\",\\\"quantity\\\":1}]')\"" >/tmp/c_$g.out 2>&1 ) &
done; wait
end=$(date +%s.%N)
ok=$(grep -l '"success"' /tmp/c_*.out 2>/dev/null | wc -l); bad=$(grep -l 'insufficient stock' /tmp/c_*.out | wc -l)
$P "psql -At -d pastest -c \"select 'stock_left='||stock from public.catalog_items where name='RACE'; select 'orders='||count(*) from public.orders; select 'items_qty='||coalesce(sum(quantity),0) from public.order_items\""
echo "succeeded=$ok rejected_insufficient_stock=$bad wall=$(echo "$end - $start" | bc)s (includes 30 psql process startups)"
echo "--- 10 concurrent verify_payment on the same order"
$P "psql -q -d pastest" <<'SQL'
set role authenticated; select set_config('request.jwt.claims','{"sub":"40000000-0000-0000-0000-000000000001"}',false);
SQL
oid=$($P "psql -At -d pastest -c \"select id from public.orders where order_status='pending_payment' limit 1\"")
echo "target order status before: $($P "psql -At -d pastest -c \"select order_status||'/'||payment_status from public.orders where id='$oid'\"")" 
$P "psql -q -d pastest -c \"update public.profiles set role='manager' where id='00000000-0000-0000-0000-0000000000e5'\"" 2>/dev/null
for i in $(seq 1 10); do ( su postgres -c "psql -q -At -d pastest -c \"set role authenticated; select set_config('request.jwt.claims','{\\\"sub\\\":\\\"00000000-0000-0000-0000-0000000000e5\\\"}',false); select public.verify_payment('$oid')\"" > /tmp/v_$i.out 2>&1 ) & done; wait
echo "verify results: $(grep -l '"success": true' /tmp/v_*.out | wc -l) success calls; alreadyVerified:true=$(grep -l '"alreadyVerified": true' /tmp/v_*.out | wc -l); errors=$(grep -il 'error\|deadlock' /tmp/v_*.out | wc -l)"
$P "psql -At -d pastest -c \"select 'verified_payments='||count(*) from public.payments where order_id='$oid' and status='verified'\""
echo "--- deadlock guard: 40 concurrent multi-item orders, items requested in opposite orders"
$P "psql -q -d pastest" <<'SQL'
truncate public.discount_requests, public.mechanic_locations, public.emergency_tickets, public.payments, public.order_items, public.orders cascade;
delete from public.catalog_items where name in ('DLX','DLY');
insert into public.catalog_items(id,name,price,stock) values ('30000000-0000-0000-0000-0000000000d1','DLX',1000,100),('30000000-0000-0000-0000-0000000000d2','DLY',1000,100);
insert into auth.users(id,email) select ('40000000-0000-0000-0000-'||lpad(g::text,12,'0'))::uuid,'u'||g||'@t' from generate_series(1,40) g on conflict do nothing;
SQL
rm -f /tmp/d_*.out
for g in $(seq 1 40); do
  uid="40000000-0000-0000-0000-$(printf %012d $g)"; if [ $((g%2)) = 0 ]; then items='[{\"id\":\"30000000-0000-0000-0000-0000000000d1\",\"quantity\":1},{\"id\":\"30000000-0000-0000-0000-0000000000d2\",\"quantity\":1}]'; else items='[{\"id\":\"30000000-0000-0000-0000-0000000000d2\",\"quantity\":1},{\"id\":\"30000000-0000-0000-0000-0000000000d1\",\"quantity\":1}]'; fi
  ( su postgres -c "psql -q -At -d pastest -c \"set role authenticated; select set_config('request.jwt.claims','{\\\"sub\\\":\\\"$uid\\\"}',false); select public.create_order('$items')\"" >/tmp/d_$g.out 2>&1 ) &
done; wait
echo "ok=$(grep -l '"success"' /tmp/d_*.out | wc -l) deadlocks=$(grep -il deadlock /tmp/d_*.out | wc -l) other_errors=$(grep -l ERROR /tmp/d_*.out | wc -l)"
$P "psql -At -d pastest -c \"select 'DLX stock='||stock from public.catalog_items where name='DLX'; select 'DLY stock='||stock from public.catalog_items where name='DLY'\""
if grep -qi deadlock /tmp/c_*.out /tmp/d_*.out 2>/dev/null; then echo "CONCURRENCY FAIL: deadlock detected"; exit 1; fi; echo "CONCURRENCY OK: no deadlocks"
