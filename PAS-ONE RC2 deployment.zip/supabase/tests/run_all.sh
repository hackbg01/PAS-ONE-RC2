#!/bin/bash
# Rebuild a throwaway local DB, apply migrations, run tests. Usage: sudo bash run_all.sh
set -e; D=$(cd "$(dirname "$0")" && pwd)
su postgres -c "psql -q -c 'drop database if exists pastest' -c 'create database pastest'" 2>/dev/null
for f in 00_supabase_stub.sql ../migrations/0001_foundation.sql ../migrations/0002_security.sql ../migrations/0003_rpc.sql ../migrations/0004_media_reports.sql ../migrations/0005_create_order_lock_late.sql ../migrations/0006_rls_perf.sql ../migrations/0007_owner_rules.sql; do su postgres -c "psql -q -v ON_ERROR_STOP=1 -d pastest -f $D/$f"; done
su postgres -c "psql -q -d pastest -f $D/10_tests.sql -f $D/11_media_reports.sql" 2>&1 | sed -n 's/.*NOTICE:  //p' | grep -E "PASS|FAIL" | tee /tmp/pas_results.txt
echo "TOTAL PASS=$(grep -c PASS /tmp/pas_results.txt) FAIL=$(grep -c FAIL /tmp/pas_results.txt)"
