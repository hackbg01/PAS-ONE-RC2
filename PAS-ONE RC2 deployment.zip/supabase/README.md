# Supabase setup (dev)
1. Create project (Free) → Settings → API: copy **Project URL** and **anon key** (never the service_role key into frontend).
2. SQL Editor → run `dist/pas-one-0001-0003.sql` once. (All migrations 0001..0006 in one file; use this, not the older pas-one-0001-0003.sql.)
3. Authentication → Providers: Email ON; **Anonymous sign-ins ON** (guest checkout/emergency); Settings: configure email confirmation per owner choice.
4. Register yourself in the app, then in SQL Editor: `update public.profiles set role='admin' where email='<owner email>';`
5. Settings table holds business rules (tax, fees). Confirm values before go-live.
Local verification: `sudo bash tests/run_all.sh && bash tests/20_concurrency.sh` (uses local Postgres 16 + auth stub).
Rollback (dev only): `rollback/0001_down.sql`.
