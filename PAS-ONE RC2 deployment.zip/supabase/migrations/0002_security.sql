-- PAS-One 0002 security: helpers, new-user trigger, RLS, grants, audit helper

-- Helpers (security definer so policies can read profiles without recursion)
create or replace function public.current_role_name() returns public.user_role
language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid() and active
$$;
create or replace function public.is_staff() returns boolean language sql stable security definer set search_path = public as
$$ select coalesce(public.current_role_name() in ('mechanic','manager','admin'), false) $$;
create or replace function public.is_manager_up() returns boolean language sql stable security definer set search_path = public as
$$ select coalesce(public.current_role_name() in ('manager','admin'), false) $$;
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path = public as
$$ select coalesce(public.current_role_name() = 'admin', false) $$;

create or replace function public.get_setting_num(p_key text) returns numeric
language sql stable security definer set search_path = public as
$$ select value::numeric from public.settings where key = p_key $$;

-- Audit (internal only; never stores secrets: sensitive keys are stripped)
create or replace function public._audit(p_action text, p_resource text, p_details jsonb default '{}')
returns void language plpgsql security definer set search_path = public as $$
begin
  insert into public.audit_logs(actor, action, resource, details)
  values (auth.uid(), p_action, p_resource,
          coalesce(p_details,'{}'::jsonb) - 'password' - 'token' - 'access_token' - 'refresh_token' - 'secret');
end $$;

-- New auth user -> profile. Role is ALWAYS 'customer' (never read from user metadata).
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, email, name)
  values (new.id, new.email, left(coalesce(new.raw_user_meta_data->>'name',''),120))
  on conflict (id) do nothing;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Lock everything down, then open exactly what is needed -----------------
revoke all on all tables in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;
revoke execute on all functions in schema public from public, anon, authenticated;
alter default privileges in schema public revoke all on tables from anon, authenticated;
alter default privileges revoke execute on functions from public;                       -- global: new functions are not PUBLIC-executable
alter default privileges in schema public revoke execute on functions from anon, authenticated;

grant usage on schema public to anon, authenticated;
grant execute on function public.current_role_name(), public.is_staff(), public.is_manager_up(), public.is_admin() to anon, authenticated;

alter table public.profiles enable row level security;
alter table public.vehicles enable row level security;
alter table public.catalog_items enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.payments enable row level security;
alter table public.emergency_tickets enable row level security;
alter table public.mechanic_locations enable row level security;
alter table public.parts enable row level security;
alter table public.inventory_mutations enable row level security;
alter table public.discount_requests enable row level security;
alter table public.settings enable row level security;
alter table public.audit_logs enable row level security;
alter table public.media_assets enable row level security;

-- profiles: own row or staff; users may edit ONLY name/phone (column grant) -> no role escalation
grant select on public.profiles to authenticated;
grant update (name, phone) on public.profiles to authenticated;
create policy profiles_select on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_staff());
create policy profiles_update_own on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

-- vehicles: owner full control, staff read
grant select, insert, update, delete on public.vehicles to authenticated;
create policy vehicles_select on public.vehicles for select to authenticated using (owner_id = auth.uid() or public.is_staff());
create policy vehicles_insert on public.vehicles for insert to authenticated with check (owner_id = auth.uid());
create policy vehicles_update on public.vehicles for update to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy vehicles_delete on public.vehicles for delete to authenticated using (owner_id = auth.uid());

-- catalog: public read of active items; admin/manager manage (soft delete = active=false; no DELETE grant)
grant select on public.catalog_items to anon, authenticated;
grant insert, update on public.catalog_items to authenticated;
create policy catalog_read_active on public.catalog_items for select to anon, authenticated using (active or public.is_manager_up());
create policy catalog_insert on public.catalog_items for insert to authenticated with check (public.is_manager_up());
create policy catalog_update on public.catalog_items for update to authenticated using (public.is_manager_up()) with check (public.is_manager_up());

-- orders / items / payments: read-only from client; ALL writes go through RPC (0003)
grant select on public.orders, public.order_items, public.payments to authenticated;
create policy orders_select on public.orders for select to authenticated
  using (customer_id = auth.uid() or created_by = auth.uid() or public.is_manager_up() or mechanic_id = auth.uid());
create policy order_items_select on public.order_items for select to authenticated
  using (exists (select 1 from public.orders o where o.id = order_id));       -- inherits orders RLS
create policy payments_select on public.payments for select to authenticated
  using (public.is_manager_up() or exists (select 1 from public.orders o where o.id = order_id and (o.customer_id = auth.uid() or o.created_by = auth.uid())));

-- emergency
grant select on public.emergency_tickets, public.mechanic_locations to authenticated;
create policy emergency_select on public.emergency_tickets for select to authenticated
  using (customer_id = auth.uid() or assigned_to = auth.uid() or public.is_manager_up());
create policy mech_loc_select on public.mechanic_locations for select to authenticated
  using (exists (select 1 from public.emergency_tickets t where t.id = ticket_id));

-- inventory (staff read; writes via RPC)
grant select on public.parts, public.inventory_mutations to authenticated;
create policy parts_select on public.parts for select to authenticated using (public.is_staff());
create policy inv_mut_select on public.inventory_mutations for select to authenticated using (public.is_staff());

-- discounts
grant select on public.discount_requests to authenticated;
create policy discount_select on public.discount_requests for select to authenticated
  using (public.is_manager_up() or requested_by = auth.uid());

-- settings: readable by all (non-secret business parameters), admin writes
grant select on public.settings to anon, authenticated;
grant update (value) on public.settings to authenticated;
create policy settings_read on public.settings for select to anon, authenticated using (true);
create policy settings_update on public.settings for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- audit logs: admin/manager read only; nobody writes directly
grant select on public.audit_logs to authenticated;
create policy audit_select on public.audit_logs for select to authenticated using (public.is_manager_up());

-- media metadata: owner or manager read
grant select on public.media_assets to authenticated;
create policy media_select on public.media_assets for select to authenticated using (owner_id = auth.uid() or public.is_manager_up());
