-- PAS-One 0003 business RPCs. All writes to orders/payments/emergency/inventory/discounts happen here,
-- inside transactions, with server-side pricing, stock locks, role checks and idempotency.

create or replace function public._uid() returns uuid language plpgsql stable security definer set search_path = public as $$
declare u uuid := auth.uid();
begin
  if u is null or not exists (select 1 from public.profiles where id = u and active) then
    raise exception 'unauthorized' using errcode = '42501';
  end if;
  return u;
end $$;

create or replace function public._require(p_ok boolean, p_msg text default 'forbidden') returns void language plpgsql as $$
begin if not coalesce(p_ok,false) then raise exception '%', p_msg using errcode = '42501'; end if; end $$;

create or replace function public._order_transition_ok(f public.order_status, t public.order_status) returns boolean
language sql immutable as $$
  select (f, t) in (
    ('pending_payment','cancelled'), ('payment_rejected','cancelled'), ('payment_rejected','pending_payment'),
    ('payment_verified','in_progress'), ('payment_verified','cancelled'),
    ('in_progress','completed'), ('in_progress','cancelled'))
$$;

-- ORDERS ---------------------------------------------------------------
create or replace function public.create_order(p_items jsonb, p_customer jsonb default '{}'::jsonb, p_idempotency_key text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  uid uuid := public._uid(); o public.orders; ids uuid[]; n int; agg jsonb;
  sub numeric(12,2) := 0; pct numeric := public.get_setting_num('TAX_PERCENTAGE'); tx numeric(12,2);
  cname text; cphone text;
begin
  if p_idempotency_key is not null then
    select * into o from public.orders where created_by = uid and idempotency_key = p_idempotency_key;
    if found then return jsonb_build_object('success',true,'orderId',o.id,'orderNo',o.order_no,'total',o.total,'duplicate',true); end if;
  end if;
  if p_items is null or jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) not between 1 and 50 then
    raise exception 'items must be an array of 1..50 entries'; end if;

  if exists (select 1 from jsonb_array_elements(p_items) x
             where jsonb_typeof(x) <> 'object'
                or case when (x->>'quantity') ~ '^[0-9]{1,4}$' then (x->>'quantity')::int not between 1 and 999 else true end
                or coalesce(x->>'id','') !~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$') then
    raise exception 'invalid items (id uuid, quantity 1..999)'; end if;
  select jsonb_agg(jsonb_build_object('id', id, 'qty', qty)) into agg
  from (select (x->>'id')::uuid as id, sum((x->>'quantity')::int)::int as qty from jsonb_array_elements(p_items) x group by 1) s;
  n := jsonb_array_length(agg);
  if exists (select 1 from jsonb_to_recordset(agg) as l(id uuid, qty int) where qty > 999) then raise exception 'invalid quantity (1..999)'; end if;
  select array_agg(id) into ids from jsonb_to_recordset(agg) as l(id uuid, qty int);

  -- lock rows in id order (prevents deadlocks and overselling)
  perform 1 from public.catalog_items c where c.id = any(ids) order by c.id for update;
  if (select count(*) from public.catalog_items where id = any(ids) and active) <> n then
    raise exception 'item not found or inactive'; end if;
  if exists (select 1 from public.catalog_items c join jsonb_to_recordset(agg) as l(id uuid, qty int) on l.id = c.id where c.track_stock and c.stock < l.qty) then
    raise exception 'insufficient stock' using errcode = 'P0002'; end if;

  select sum(c.price * l.qty) into sub from public.catalog_items c join jsonb_to_recordset(agg) as l(id uuid, qty int) on l.id = c.id;
  tx := round(sub * pct / 100, 2);
  select coalesce(nullif(left(p_customer->>'name',120),''), p.name), coalesce(left(p_customer->>'phone',20), p.phone)
    into cname, cphone from public.profiles p where p.id = uid;

  begin
    insert into public.orders(order_no, customer_id, customer_name, customer_phone, subtotal, tax, total, idempotency_key, created_by)
    values ('ORD-' || to_char(now() at time zone 'Asia/Jakarta','YYMMDD') || '-' || lpad(nextval('public.order_no_seq')::text,5,'0'),
            uid, coalesce(cname,''), cphone, sub, tx, sub + tx, p_idempotency_key, uid)
    returning * into o;
  exception when unique_violation then
    select * into o from public.orders where created_by = uid and idempotency_key = p_idempotency_key;
    return jsonb_build_object('success',true,'orderId',o.id,'orderNo',o.order_no,'total',o.total,'duplicate',true);
  end;

  insert into public.order_items(order_id, catalog_item_id, name_snapshot, unit_price, quantity, line_total)
  select o.id, c.id, c.name, c.price, l.qty, c.price * l.qty from public.catalog_items c join jsonb_to_recordset(agg) as l(id uuid, qty int) on l.id = c.id;
  update public.catalog_items c set stock = c.stock - l.qty from jsonb_to_recordset(agg) as l(id uuid, qty int) where c.id = l.id and c.track_stock;

  perform public._audit('ORDER_CREATED', o.order_no, jsonb_build_object('total', o.total, 'items', n));
  return jsonb_build_object('success',true,'orderId',o.id,'orderNo',o.order_no,'subtotal',o.subtotal,'tax',o.tax,'total',o.total,'duplicate',false);
end $$;

create or replace function public.update_order_status(p_order_id uuid, p_status public.order_status)
returns jsonb language plpgsql security definer set search_path = public as $$
declare uid uuid := public._uid(); o public.orders; role_ public.user_role := public.current_role_name();
begin
  select * into o from public.orders where id = p_order_id for update;
  if not found then raise exception 'order not found'; end if;
  if p_status in ('payment_verified','payment_rejected') then
    raise exception 'use verify_payment for payment decisions'; end if;
  if not public._order_transition_ok(o.order_status, p_status) then
    raise exception 'invalid transition % -> %', o.order_status, p_status; end if;
  if role_ in ('manager','admin') then null;
  elsif role_ = 'mechanic' then
    perform public._require(o.mechanic_id = uid and p_status in ('in_progress','completed'));
  else
    perform public._require(o.customer_id = uid and p_status = 'cancelled' and o.order_status in ('pending_payment','payment_rejected'));
  end if;
  if p_status = 'cancelled' then   -- give reserved stock back
    update public.catalog_items c set stock = c.stock + i.quantity
    from public.order_items i where i.order_id = o.id and i.catalog_item_id = c.id and c.track_stock;
  end if;
  update public.orders set order_status = p_status,
    payment_status = case when p_status = 'pending_payment' then 'pending' else payment_status end
  where id = o.id;
  perform public._audit('ORDER_STATUS_UPDATED', o.order_no, jsonb_build_object('from', o.order_status, 'to', p_status));
  return jsonb_build_object('success', true);
end $$;

create or replace function public.assign_order_mechanic(p_order_id uuid, p_mechanic_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  perform public._uid(); perform public._require(public.is_manager_up());
  perform public._require(exists (select 1 from public.profiles where id = p_mechanic_id and role = 'mechanic' and active), 'invalid mechanic');
  update public.orders set mechanic_id = p_mechanic_id where id = p_order_id;
  if not found then raise exception 'order not found'; end if;
  perform public._audit('ORDER_MECHANIC_ASSIGNED', p_order_id::text, jsonb_build_object('mechanic', p_mechanic_id));
  return jsonb_build_object('success', true);
end $$;

-- PAYMENTS -------------------------------------------------------------
create or replace function public.submit_payment(p_order_id uuid, p_method text, p_proof_url text default null, p_idempotency_key text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare uid uuid := public._uid(); o public.orders; pid uuid;
begin
  select * into o from public.orders where id = p_order_id for update;
  if not found then raise exception 'order not found'; end if;
  perform public._require(o.customer_id = uid or o.created_by = uid);
  if p_idempotency_key is not null then
    select id into pid from public.payments where order_id = o.id and idempotency_key = p_idempotency_key;
    if found then return jsonb_build_object('success',true,'paymentId',pid,'duplicate',true); end if;
  end if;
  if o.order_status not in ('pending_payment','payment_rejected') then raise exception 'order not awaiting payment'; end if;
  insert into public.payments(order_id, amount, status, method, proof_url, idempotency_key, submitted_by)
  values (o.id, o.total, 'pending', p_method, p_proof_url, p_idempotency_key, uid) returning id into pid;
  update public.orders set order_status = 'pending_payment', payment_status = 'pending' where id = o.id;
  perform public._audit('PAYMENT_SUBMITTED', o.order_no, jsonb_build_object('method', p_method));
  return jsonb_build_object('success',true,'paymentId',pid,'amount',o.total,'duplicate',false);
end $$;

create or replace function public.verify_payment(p_order_id uuid, p_approve boolean default true, p_method text default 'qris', p_proof_url text default null, p_note text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare uid uuid := public._uid(); o public.orders; p public.payments;
begin
  perform public._require(public.is_manager_up());
  select * into o from public.orders where id = p_order_id for update;
  if not found then raise exception 'order not found'; end if;
  if o.payment_status = 'verified' then   -- idempotent: duplicate verification/callback is a no-op
    return jsonb_build_object('success', true, 'alreadyVerified', true); end if;
  if o.order_status not in ('pending_payment','payment_rejected') then raise exception 'order not awaiting payment'; end if;
  select * into p from public.payments where order_id = o.id and status = 'pending' order by created_at desc limit 1 for update;
  if not found then
    insert into public.payments(order_id, amount, method, proof_url, submitted_by) values (o.id, o.total, p_method, p_proof_url, uid) returning * into p;
  end if;
  if p_approve then
    update public.payments set status='verified', verified_by=uid, verified_at=now(), note=p_note where id = p.id;
    update public.orders set payment_status='verified', order_status='payment_verified' where id = o.id;
  else
    update public.payments set status='failed', verified_by=uid, verified_at=now(), note=p_note where id = p.id;
    update public.orders set payment_status='failed', order_status='payment_rejected' where id = o.id;
  end if;
  perform public._audit(case when p_approve then 'PAYMENT_VERIFIED' else 'PAYMENT_REJECTED' end, o.order_no, jsonb_build_object('amount', p.amount));
  return jsonb_build_object('success', true, 'alreadyVerified', false);
end $$;

-- EMERGENCY ------------------------------------------------------------
create or replace function public.create_emergency(p_lat double precision, p_lng double precision, p_complaint text default '',
                                                    p_name text default null, p_phone text default null, p_idempotency_key text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  uid uuid := public._uid(); t public.emergency_tickets; reg boolean; d numeric; hr int; visit numeric := 0; dist numeric := 0;
  blat numeric := public.get_setting_num('BASE_LOCATION_LAT'); blng numeric := public.get_setting_num('BASE_LOCATION_LNG');
  a double precision; free_km numeric := public.get_setting_num('FREE_RADIUS_KM');
begin
  if p_lat is null or p_lng is null or p_lat not between -90 and 90 or p_lng not between -180 and 180 then raise exception 'invalid coordinates'; end if;
  if p_idempotency_key is not null then
    select * into t from public.emergency_tickets where customer_id = uid and idempotency_key = p_idempotency_key;
    if found then return jsonb_build_object('success',true,'ticketId',t.ticket_no,'id',t.id,'estimatedCost',t.estimated_cost,'duplicate',true); end if;
  end if;
  reg := not coalesce((auth.jwt()->>'is_anonymous')::boolean, false);
  -- haversine (same formula as legacy emergency-calculator.js, R = 6371 km)
  a := sin(radians(p_lat - blat)/2)^2 + cos(radians(blat)) * cos(radians(p_lat)) * sin(radians(p_lng - blng)/2)^2;
  d := round((6371 * 2 * atan2(sqrt(a), sqrt(1 - a)))::numeric, 2);
  hr := extract(hour from now() at time zone 'Asia/Jakarta');
  if not reg then visit := public.get_setting_num('GUEST_VISIT_FEE');
  elsif not (hr >= public.get_setting_num('NORMAL_HOURS_START') and hr < public.get_setting_num('NORMAL_HOURS_END')) then
    visit := public.get_setting_num('OFF_HOURS_VISIT_FEE'); end if;
  if d > free_km then dist := (d - free_km) * public.get_setting_num('DISTANCE_FEE_PER_KM'); end if;
  insert into public.emergency_tickets(ticket_no, customer_id, customer_name, customer_phone, lat, lng, complaint, distance_km,
                                       visit_fee, distance_fee, estimated_cost, is_registered, idempotency_key)
  values ('EMG-' || to_char(now() at time zone 'Asia/Jakarta','YYMMDD') || '-' || lpad(nextval('public.order_no_seq')::text,5,'0'),
          uid, coalesce(nullif(left(p_name,120),''), (select nullif(name,'') from public.profiles where id = uid), 'Guest'),
          left(p_phone,20), p_lat, p_lng, left(coalesce(p_complaint,''),1000), d, visit, dist, visit + dist, reg, p_idempotency_key)
  returning * into t;
  perform public._audit('EMERGENCY_CREATED', t.ticket_no, jsonb_build_object('estimated', t.estimated_cost));
  return jsonb_build_object('success',true,'ticketId',t.ticket_no,'id',t.id,'distanceKm',d,'visitFee',visit,'distanceFee',dist,'estimatedCost',t.estimated_cost,'duplicate',false);
end $$;

create or replace function public.assign_mechanic(p_ticket_id uuid, p_mechanic_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  perform public._uid(); perform public._require(public.is_manager_up());
  perform public._require(exists (select 1 from public.profiles where id = p_mechanic_id and role = 'mechanic' and active), 'invalid mechanic');
  update public.emergency_tickets set assigned_to = p_mechanic_id, status = 'assigned' where id = p_ticket_id and status in ('created','assigned');
  if not found then raise exception 'ticket not found or not assignable'; end if;
  perform public._audit('EMERGENCY_ASSIGNED', p_ticket_id::text, jsonb_build_object('mechanic', p_mechanic_id));
  return jsonb_build_object('success', true);
end $$;

create or replace function public.update_emergency_status(p_ticket_id uuid, p_status public.emergency_status, p_actual_cost numeric default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare uid uuid := public._uid(); t public.emergency_tickets;
begin
  select * into t from public.emergency_tickets where id = p_ticket_id for update;
  if not found then raise exception 'ticket not found'; end if;
  if not ((t.status, p_status) in (('assigned','in_progress'),('in_progress','completed'),('created','cancelled'),('assigned','cancelled'),('in_progress','cancelled'))) then
    raise exception 'invalid transition % -> %', t.status, p_status; end if;
  if public.is_manager_up() then null;
  elsif t.assigned_to = uid then perform public._require(p_status in ('in_progress','completed'));
  else perform public._require(t.customer_id = uid and p_status = 'cancelled' and t.status in ('created','assigned')); end if;
  if p_actual_cost is not null then perform public._require(public.is_manager_up()); end if;
  update public.emergency_tickets set status = p_status, actual_cost = coalesce(p_actual_cost, actual_cost),
    completed_at = case when p_status = 'completed' then now() else completed_at end where id = t.id;
  perform public._audit('EMERGENCY_STATUS_UPDATED', t.ticket_no, jsonb_build_object('from', t.status, 'to', p_status));
  return jsonb_build_object('success', true);
end $$;

create or replace function public.share_location(p_ticket_id uuid, p_lat double precision, p_lng double precision)
returns jsonb language plpgsql security definer set search_path = public as $$
declare uid uuid := public._uid();
begin
  perform public._require(exists (select 1 from public.emergency_tickets where id = p_ticket_id and assigned_to = uid and status in ('assigned','in_progress')));
  insert into public.mechanic_locations(ticket_id, mechanic_id, lat, lng) values (p_ticket_id, uid, p_lat, p_lng)
  on conflict (ticket_id) do update set lat = excluded.lat, lng = excluded.lng, updated_at = now(), mechanic_id = excluded.mechanic_id;
  return jsonb_build_object('success', true);
end $$;

-- INVENTORY ------------------------------------------------------------
create or replace function public.inventory_mutation(p_part_id uuid, p_type public.mutation_type, p_quantity integer, p_reason text default null, p_reference text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare uid uuid := public._uid(); pt public.parts; newq int; q int;
begin
  perform public._require(public.is_staff());
  if p_quantity is null or p_quantity < 0 then raise exception 'invalid quantity'; end if;
  select * into pt from public.parts where id = p_part_id and active for update;
  if not found then raise exception 'part not found'; end if;
  if p_type = 'in' then newq := pt.quantity + p_quantity; q := p_quantity;
  elsif p_type = 'out' then newq := pt.quantity - p_quantity; q := p_quantity;
  else newq := p_quantity; q := abs(p_quantity - pt.quantity); end if;   -- adjust = set absolute count
  if q = 0 then raise exception 'no change'; end if;
  if newq < 0 then raise exception 'insufficient stock' using errcode = 'P0002'; end if;
  update public.parts set quantity = newq where id = pt.id;
  insert into public.inventory_mutations(part_id, type, quantity, quantity_after, reason, reference_id, created_by)
  values (pt.id, p_type, q, newq, left(p_reason,300), left(p_reference,100), uid);
  perform public._audit('INVENTORY_MUTATION', pt.id::text, jsonb_build_object('type', p_type, 'qty', q, 'after', newq));
  return jsonb_build_object('success', true, 'quantity', newq, 'lowStock', newq <= pt.min_stock);
end $$;

-- add part / CSV import (rows: [{id?,name,category,unit,quantity,min_stock,price,supplier}])
create or replace function public.upsert_parts(p_rows jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare uid uuid := public._uid(); x jsonb; pid uuid; created int := 0; updated int := 0;
begin
  perform public._require(public.is_manager_up());
  if p_rows is null or jsonb_typeof(p_rows) <> 'array' or jsonb_array_length(p_rows) not between 1 and 2000 then raise exception 'rows must be array of 1..2000'; end if;
  for x in select * from jsonb_array_elements(p_rows) loop
    pid := nullif(x->>'id','')::uuid;
    if pid is null then select id into pid from public.parts where lower(name) = lower(x->>'name') and active limit 1; end if;
    if pid is null then
      insert into public.parts(name, category, unit, quantity, min_stock, price, supplier)
      values (x->>'name', coalesce(x->>'category','lainnya'), coalesce(x->>'unit','pcs'), coalesce((x->>'quantity')::int,0),
              coalesce((x->>'min_stock')::int,0), coalesce((x->>'price')::numeric,0), x->>'supplier');
      created := created + 1;
    else   -- metadata only; quantity changes must go through inventory_mutation
      update public.parts set name = coalesce(x->>'name', name), category = coalesce(x->>'category', category), unit = coalesce(x->>'unit', unit),
        min_stock = coalesce((x->>'min_stock')::int, min_stock), price = coalesce((x->>'price')::numeric, price), supplier = coalesce(x->>'supplier', supplier)
      where id = pid;
      updated := updated + 1;
    end if;
  end loop;
  perform public._audit('PARTS_UPSERT', 'parts', jsonb_build_object('created', created, 'updated', updated));
  return jsonb_build_object('success', true, 'created', created, 'updated', updated);
end $$;

-- DISCOUNTS ------------------------------------------------------------
create or replace function public._order_total_after(p_subtotal numeric, p_discount numeric) returns numeric
language sql stable security definer set search_path = public as $$
  select (p_subtotal - p_discount) + round((p_subtotal - p_discount) * public.get_setting_num('TAX_PERCENTAGE') / 100, 2) $$;

create or replace function public.request_discount(p_order_id uuid, p_amount numeric, p_reason text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare uid uuid := public._uid(); o public.orders; id_ uuid;
begin
  perform public._require(public.is_staff());
  select * into o from public.orders where id = p_order_id for update;
  if not found then raise exception 'order not found'; end if;
  perform public._require(public.current_role_name() <> 'mechanic' or o.mechanic_id = uid, 'mechanics may only request discounts on their assigned orders');
  if o.order_status <> 'pending_payment' then raise exception 'discount only for orders awaiting payment'; end if;
  if p_amount is null or p_amount <= 0 or p_amount > o.subtotal - o.discount_total then raise exception 'invalid discount amount'; end if;
  insert into public.discount_requests(order_id, original_amount, discount_amount, final_amount, reason, requested_by)
  values (o.id, o.total, p_amount, public._order_total_after(o.subtotal, o.discount_total + p_amount), p_reason, uid) returning id into id_;
  perform public._audit('DISCOUNT_REQUESTED', o.order_no, jsonb_build_object('amount', p_amount));
  return jsonb_build_object('success', true, 'requestId', id_);
exception when unique_violation then raise exception 'a discount request is already open for this order';
end $$;

create or replace function public.decide_discount(p_request_id uuid, p_approve boolean, p_note text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare uid uuid := public._uid(); d public.discount_requests; o public.orders;
begin
  perform public._require(public.is_manager_up());
  select * into d from public.discount_requests where id = p_request_id for update;
  if not found or d.status <> 'requested' then raise exception 'request not found or already decided'; end if;
  perform public._require(d.requested_by <> uid or public.is_admin(), 'cannot approve own request');
  select * into o from public.orders where id = d.order_id for update;
  if p_approve then
    if o.order_status <> 'pending_payment' then raise exception 'order no longer awaiting payment'; end if;
    if d.discount_amount > o.subtotal - o.discount_total then raise exception 'discount exceeds remaining subtotal'; end if;
    update public.orders set discount_total = o.discount_total + d.discount_amount,
      tax = round((o.subtotal - o.discount_total - d.discount_amount) * public.get_setting_num('TAX_PERCENTAGE') / 100, 2),
      total = public._order_total_after(o.subtotal, o.discount_total + d.discount_amount) where id = o.id;
  end if;
  update public.discount_requests set status = case when p_approve then 'approved' else 'rejected' end::public.discount_status,
    approved_by = uid, decided_at = now() where id = d.id;
  perform public._audit('DISCOUNT_DECIDED', o.order_no, jsonb_build_object('approved', p_approve));
  return jsonb_build_object('success', true);
end $$;

-- DASHBOARD (real aggregates; replaces hard-coded stub numbers) -----------
create or replace function public.dashboard_summary(p_portal text default 'admin')
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare today_start timestamptz := date_trunc('day', now() at time zone 'Asia/Jakarta') at time zone 'Asia/Jakarta'; uid uuid := public._uid();
begin
  perform public._require(public.is_staff());
  if p_portal = 'mechanic' then
    return jsonb_build_object('success', true,
      'assignedOrders', (select count(*) from public.orders where mechanic_id = uid and order_status in ('payment_verified','in_progress')),
      'assignedEmergency', (select count(*) from public.emergency_tickets where assigned_to = uid and status in ('assigned','in_progress')));
  end if;
  perform public._require(public.is_manager_up());
  return jsonb_build_object('success', true,
    'bookingToday', (select count(*) from public.orders where created_at >= today_start),
    'paymentPending', (select count(*) from public.orders where order_status = 'pending_payment'),
    'workActive', (select count(*) from public.orders where order_status = 'in_progress'),
    'emergency', (select count(*) from public.emergency_tickets where status in ('created','assigned','in_progress')),
    'revenue', coalesce((select sum(total) from public.orders where payment_status = 'verified' and order_status <> 'cancelled' and created_at >= today_start),0),
    'revenueMonth', coalesce((select sum(total) from public.orders where payment_status = 'verified' and order_status <> 'cancelled'
                              and created_at >= date_trunc('month', now() at time zone 'Asia/Jakarta') at time zone 'Asia/Jakarta'),0),
    'discountPending', (select count(*) from public.discount_requests where status = 'requested'),
    'lowStockParts', (select count(*) from public.parts where active and quantity <= min_stock));
end $$;

-- ADMIN ----------------------------------------------------------------
create or replace function public.admin_set_role(p_user uuid, p_role public.user_role, p_active boolean default true)
returns jsonb language plpgsql security definer set search_path = public as $$
declare uid uuid := public._uid();
begin
  perform public._require(public.is_admin());
  if p_user = uid then raise exception 'cannot change own role'; end if;
  update public.profiles set role = p_role, active = p_active where id = p_user;
  if not found then raise exception 'user not found'; end if;
  perform public._audit('ROLE_CHANGED', p_user::text, jsonb_build_object('role', p_role, 'active', p_active));
  return jsonb_build_object('success', true);
end $$;

-- Final lock-down: nothing executable by default, then grant exactly the RPC surface (idempotent safety net)
revoke execute on all functions in schema public from public, anon, authenticated;
grant execute on function public.current_role_name(), public.is_staff(), public.is_manager_up(), public.is_admin() to anon, authenticated;
-- Expose only the public RPC surface to signed-in users (anonymous sign-ins are also 'authenticated')
grant execute on function
  public.create_order(jsonb,jsonb,text), public.update_order_status(uuid,public.order_status), public.assign_order_mechanic(uuid,uuid),
  public.submit_payment(uuid,text,text,text), public.verify_payment(uuid,boolean,text,text,text),
  public.create_emergency(double precision,double precision,text,text,text,text), public.assign_mechanic(uuid,uuid),
  public.update_emergency_status(uuid,public.emergency_status,numeric), public.share_location(uuid,double precision,double precision),
  public.inventory_mutation(uuid,public.mutation_type,integer,text,text), public.upsert_parts(jsonb),
  public.request_discount(uuid,numeric,text), public.decide_discount(uuid,boolean,text),
  public.dashboard_summary(text), public.admin_set_role(uuid,public.user_role,boolean)
to authenticated;
