-- PAS-One 0004: media metadata RPCs (R2 via Worker) + reporting export RPC

alter table public.payments add column if not exists proof_media_id uuid references public.media_assets(id);

-- Worker calls these with the END USER's JWT, so auth.uid() is the real caller (no service_role needed)
create or replace function public.register_media(p_key text, p_kind text, p_mime text, p_size integer, p_ref_table text default null, p_ref_id uuid default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare uid uuid := public._uid(); id_ uuid;
begin
  if p_key is null or p_key !~ ('^' || p_kind || '/' || uid::text || '/[0-9a-f-]{36}\.(jpg|png|webp|pdf)$') then
    raise exception 'invalid media key'; end if;
  if p_mime not in ('image/jpeg','image/png','image/webp','application/pdf') then raise exception 'unsupported type'; end if;
  if p_size is null or p_size <= 0 or p_size > 5242880 then raise exception 'invalid size'; end if;
  if p_kind not in ('payment_proof','catalog_image','document') then raise exception 'invalid kind'; end if;
  if p_kind = 'catalog_image' then perform public._require(public.is_manager_up()); end if;
  insert into public.media_assets(r2_key, owner_id, kind, mime_type, size_bytes, ref_table, ref_id)
  values (p_key, uid, p_kind, p_mime, p_size, p_ref_table, p_ref_id) returning id into id_;
  perform public._audit('MEDIA_REGISTERED', p_key, jsonb_build_object('kind', p_kind, 'size', p_size));
  return jsonb_build_object('success', true, 'id', id_);
end $$;

create or replace function public.can_read_media(p_key text) returns boolean
language plpgsql stable security definer set search_path = public as $$
declare uid uuid := public._uid();
begin
  return exists (select 1 from public.media_assets m where m.r2_key = p_key
                 and (m.owner_id = uid or public.is_manager_up() or (m.kind = 'catalog_image')));
end $$;

create or replace function public.attach_payment_proof(p_payment_id uuid, p_media_key text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare uid uuid := public._uid(); m public.media_assets;
begin
  select * into m from public.media_assets where r2_key = p_media_key and owner_id = uid and kind = 'payment_proof';
  if not found then raise exception 'media not found'; end if;
  update public.payments set proof_media_id = m.id where id = p_payment_id and submitted_by = uid and status = 'pending';
  if not found then raise exception 'payment not found or not pending'; end if;
  return jsonb_build_object('success', true);
end $$;

-- Reporting export for Google Sheets (manager/admin; capped; no personal data beyond what orders already hold)
create or replace function public.report_export(p_from date, p_to date)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare f timestamptz; t timestamptz;
begin
  perform public._uid(); perform public._require(public.is_manager_up());
  if p_from is null or p_to is null or p_to < p_from or p_to - p_from > 92 then raise exception 'invalid range (max 92 days)'; end if;
  f := (p_from::timestamp) at time zone 'Asia/Jakarta'; t := ((p_to + 1)::timestamp) at time zone 'Asia/Jakarta';
  return jsonb_build_object(
    'generated_at', now(), 'from', p_from, 'to', p_to,
    'orders', coalesce((select jsonb_agg(jsonb_build_object('order_no',o.order_no,'created_at',o.created_at,'customer',o.customer_name,'subtotal',o.subtotal,'discount',o.discount_total,'tax',o.tax,'total',o.total,'order_status',o.order_status,'payment_status',o.payment_status) order by o.created_at)
               from (select * from public.orders where created_at >= f and created_at < t order by created_at limit 20000) o), '[]'),
    'payments', coalesce((select jsonb_agg(jsonb_build_object('order_no',o.order_no,'method',p.method,'amount',p.amount,'status',p.status,'verified_at',p.verified_at) order by p.created_at)
               from public.payments p join public.orders o on o.id = p.order_id where p.created_at >= f and p.created_at < t), '[]'),
    'inventory', coalesce((select jsonb_agg(jsonb_build_object('name',name,'category',category,'unit',unit,'quantity',quantity,'min_stock',min_stock,'low',quantity <= min_stock) order by name) from public.parts where active), '[]'),
    'summary', (select jsonb_build_object('orders',count(*),'revenue_verified',coalesce(sum(total) filter (where payment_status='verified' and order_status<>'cancelled'),0))
                from public.orders where created_at >= f and created_at < t));
end $$;

revoke execute on all functions in schema public from public, anon, authenticated;
grant execute on function public.current_role_name(), public.is_staff(), public.is_manager_up(), public.is_admin() to anon, authenticated;
grant execute on function
  public.create_order(jsonb,jsonb,text), public.update_order_status(uuid,public.order_status), public.assign_order_mechanic(uuid,uuid),
  public.submit_payment(uuid,text,text,text), public.verify_payment(uuid,boolean,text,text,text),
  public.create_emergency(double precision,double precision,text,text,text,text), public.assign_mechanic(uuid,uuid),
  public.update_emergency_status(uuid,public.emergency_status,numeric), public.share_location(uuid,double precision,double precision),
  public.inventory_mutation(uuid,public.mutation_type,integer,text,text), public.upsert_parts(jsonb),
  public.request_discount(uuid,numeric,text), public.decide_discount(uuid,boolean,text),
  public.dashboard_summary(text), public.admin_set_role(uuid,public.user_role,boolean),
  public.register_media(text,text,text,integer,text,uuid), public.can_read_media(text), public.attach_payment_proof(uuid,text), public.report_export(date,date)
to authenticated;
