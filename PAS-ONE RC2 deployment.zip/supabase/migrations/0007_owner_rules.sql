-- 0007: owner-confirmed business rules (2026-11-09). Forward-only; 0001-0006 untouched.
-- Tax 11%. Emergency visit fee: Fleet 250k at all hours; Retail 250k by day, 300k at night (22:00-06:00 WIB).
-- Distance fee unchanged (Rp10.000/km beyond 30 km). Guests are Retail.
update public.settings set value='11', description='Pajak % (dikonfirmasi owner 2026-11-09)' where key='TAX_PERCENTAGE';
insert into public.settings(key,value,type,description) values
 ('FLEET_VISIT_FEE','250000','number','Biaya visit Fleet, berlaku 24 jam'),
 ('RETAIL_VISIT_FEE','250000','number','Biaya visit Retail (di luar jam malam)'),
 ('RETAIL_NIGHT_VISIT_FEE','300000','number','Biaya visit Retail jam malam'),
 ('NIGHT_HOURS_START','22','number','Jam malam mulai (WIB)'),
 ('NIGHT_HOURS_END','6','number','Jam malam selesai (WIB)')
on conflict (key) do update set value=excluded.value, description=excluded.description;
update public.settings set description = description || ' [tidak dipakai sejak 0007]'
 where key in ('GUEST_VISIT_FEE','OFF_HOURS_VISIT_FEE','NORMAL_HOURS_START','NORMAL_HOURS_END') and description not like '%0007%';

do $$ begin create type public.customer_type as enum ('retail','fleet'); exception when duplicate_object then null; end $$;
alter table public.profiles add column if not exists customer_type public.customer_type not null default 'retail';
-- (clients keep column-level UPDATE on name, phone only, so customer_type cannot be self-assigned)

create or replace function public._visit_fee(p_fleet boolean, p_hour int) returns numeric
language sql stable set search_path = public as $$
  select case when p_fleet then public.get_setting_num('FLEET_VISIT_FEE')
              when p_hour >= public.get_setting_num('NIGHT_HOURS_START') or p_hour < public.get_setting_num('NIGHT_HOURS_END')
                   then public.get_setting_num('RETAIL_NIGHT_VISIT_FEE')
              else public.get_setting_num('RETAIL_VISIT_FEE') end $$;

create or replace function public.create_emergency(p_lat double precision, p_lng double precision, p_complaint text default '',
                                                    p_name text default null, p_phone text default null, p_idempotency_key text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  uid uuid := public._uid(); t public.emergency_tickets; reg boolean; d numeric; hr int; visit numeric := 0; dist numeric := 0; fleet boolean;
  blat numeric := public.get_setting_num('BASE_LOCATION_LAT'); blng numeric := public.get_setting_num('BASE_LOCATION_LNG');
  a double precision; free_km numeric := public.get_setting_num('FREE_RADIUS_KM');
begin
  if p_lat is null or p_lng is null or p_lat not between -90 and 90 or p_lng not between -180 and 180 then raise exception 'invalid coordinates'; end if;
  if p_idempotency_key is not null then
    select * into t from public.emergency_tickets where customer_id = uid and idempotency_key = p_idempotency_key;
    if found then return jsonb_build_object('success',true,'ticketId',t.ticket_no,'id',t.id,'estimatedCost',t.estimated_cost,'duplicate',true); end if;
  end if;
  reg := not coalesce((auth.jwt()->>'is_anonymous')::boolean, false);
  fleet := reg and coalesce((select customer_type = 'fleet' from public.profiles where id = uid), false);
  a := sin(radians(p_lat - blat)/2)^2 + cos(radians(blat)) * cos(radians(p_lat)) * sin(radians(p_lng - blng)/2)^2;
  d := round((6371 * 2 * atan2(sqrt(a), sqrt(1 - a)))::numeric, 2);
  hr := extract(hour from now() at time zone 'Asia/Jakarta');
  visit := public._visit_fee(fleet, hr);
  if d > free_km then dist := (d - free_km) * public.get_setting_num('DISTANCE_FEE_PER_KM'); end if;
  insert into public.emergency_tickets(ticket_no, customer_id, customer_name, customer_phone, lat, lng, complaint, distance_km,
                                       visit_fee, distance_fee, estimated_cost, is_registered, idempotency_key)
  values ('EMG-' || to_char(now() at time zone 'Asia/Jakarta','YYMMDD') || '-' || lpad(nextval('public.order_no_seq')::text,5,'0'),
          uid, coalesce(nullif(left(p_name,120),''), (select nullif(name,'') from public.profiles where id = uid), 'Guest'),
          left(p_phone,20), p_lat, p_lng, left(coalesce(p_complaint,''),1000), d, visit, dist, visit + dist, reg, p_idempotency_key)
  returning * into t;
  perform public._audit('EMERGENCY_CREATED', t.ticket_no, jsonb_build_object('estimated', t.estimated_cost, 'fleet', fleet));
  return jsonb_build_object('success',true,'ticketId',t.ticket_no,'id',t.id,'distanceKm',d,'visitFee',visit,'distanceFee',dist,'estimatedCost',t.estimated_cost,'duplicate',false);
end $$;

create or replace function public.admin_set_customer_type(p_user uuid, p_type public.customer_type)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  perform public._uid(); perform public._require(public.is_admin());
  update public.profiles set customer_type = p_type where id = p_user;
  if not found then raise exception 'user not found'; end if;
  perform public._audit('CUSTOMER_TYPE_CHANGED', p_user::text, jsonb_build_object('type', p_type));
  return jsonb_build_object('success', true);
end $$;

revoke execute on all functions in schema public from public, anon, authenticated;
grant execute on function public.current_role_name(), public.is_staff(), public.is_manager_up(), public.is_admin() to anon, authenticated;
grant execute on function
  public.create_order(jsonb,jsonb,text), public.update_order_status(uuid,public.order_status), public.assign_order_mechanic(uuid,uuid),
  public.submit_payment(uuid,text,text,text), public.verify_payment(uuid,boolean,text,text,text),
  public.create_emergency(double precision,double precision,text,text,text,text), public.assign_mechanic(uuid,uuid),
  public.update_emergency_status(uuid,public.emergency_status,numeric), public.share_location(uuid,double precision,double precision),
  public.inventory_mutation(uuid,public.mutation_type,integer,text,text), public.upsert_parts(jsonb),
  public.request_discount(uuid,numeric,text), public.decide_discount(uuid,boolean,text),
  public.dashboard_summary(text), public.admin_set_role(uuid,public.user_role,boolean),
  public.register_media(text,text,text,integer,text,uuid), public.can_read_media(text), public.attach_payment_proof(uuid,text), public.report_export(date,date),
  public.admin_set_customer_type(uuid,public.customer_type)
to authenticated;
