-- PAS-One 0001 foundation: enums, tables, constraints, indexes, seed settings
-- Rollback: see supabase/rollback/0001_down.sql

create type public.user_role as enum ('customer','mechanic','manager','admin');
create type public.order_status as enum ('draft','pending_payment','payment_rejected','payment_verified','in_progress','completed','cancelled');
create type public.payment_status as enum ('pending','verified','failed');
create type public.emergency_status as enum ('created','assigned','in_progress','completed','cancelled');
create type public.discount_status as enum ('requested','approved','rejected');
create type public.mutation_type as enum ('in','out','adjust');

create or replace function public.set_updated_at() returns trigger language plpgsql as $$
begin new.updated_at := now(); return new; end $$;

-- identity ------------------------------------------------------------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  name text not null default '' check (char_length(name) <= 120),
  phone text check (phone is null or phone ~ '^\+?[0-9]{8,16}$'),
  role public.user_role not null default 'customer',
  active boolean not null default true,
  legacy_ref text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index profiles_role_idx on public.profiles(role) where role <> 'customer';
create trigger profiles_updated before update on public.profiles for each row execute function public.set_updated_at();

create table public.vehicles (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  plate text not null check (plate = upper(plate) and char_length(plate) between 3 and 12),
  make text check (char_length(make) <= 60),
  model text check (char_length(model) <= 60),
  year smallint check (year between 1950 and 2100),
  notes text check (char_length(notes) <= 500),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (owner_id, plate)
);
create trigger vehicles_updated before update on public.vehicles for each row execute function public.set_updated_at();

-- catalog --------------------------------------------------------------
create table public.catalog_items (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 200),
  category text not null default 'lainnya' check (char_length(category) <= 60),
  description text not null default '' check (char_length(description) <= 2000),
  price numeric(12,2) not null check (price >= 0),
  stock integer not null default 0 check (stock >= 0),
  track_stock boolean not null default true,   -- false for services (legacy used stock=999)
  active boolean not null default true,
  legacy_ref text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index catalog_active_cat_idx on public.catalog_items(category) where active;
create trigger catalog_updated before update on public.catalog_items for each row execute function public.set_updated_at();

-- orders ---------------------------------------------------------------
create sequence public.order_no_seq;
create table public.orders (
  id uuid primary key default gen_random_uuid(),
  order_no text not null unique,
  customer_id uuid references public.profiles(id),          -- anonymous sign-in user for guests
  customer_name text not null default '' check (char_length(customer_name) <= 120),
  customer_phone text check (customer_phone is null or char_length(customer_phone) <= 20),
  vehicle_id uuid references public.vehicles(id),
  mechanic_id uuid references public.profiles(id),
  subtotal numeric(12,2) not null check (subtotal >= 0),
  discount_total numeric(12,2) not null default 0 check (discount_total >= 0),
  tax numeric(12,2) not null check (tax >= 0),
  total numeric(12,2) not null check (total >= 0),
  order_status public.order_status not null default 'pending_payment',
  payment_status public.payment_status not null default 'pending',
  idempotency_key text,
  legacy_ref text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (discount_total <= subtotal)
);
create unique index orders_idem_uq on public.orders(created_by, idempotency_key) where idempotency_key is not null;
create index orders_customer_idx on public.orders(customer_id, created_at desc);
create index orders_status_idx on public.orders(order_status, created_at desc);
create index orders_mechanic_idx on public.orders(mechanic_id) where mechanic_id is not null;
create trigger orders_updated before update on public.orders for each row execute function public.set_updated_at();

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  catalog_item_id uuid not null references public.catalog_items(id),
  name_snapshot text not null,
  unit_price numeric(12,2) not null check (unit_price >= 0),
  quantity integer not null check (quantity between 1 and 999),
  line_total numeric(12,2) not null check (line_total >= 0)
);
create index order_items_order_idx on public.order_items(order_id);
create index order_items_item_idx on public.order_items(catalog_item_id);

-- payments -------------------------------------------------------------
create table public.payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id),
  amount numeric(12,2) not null check (amount >= 0),
  status public.payment_status not null default 'pending',
  method text not null check (method in ('qris','transfer','cash','other')),
  proof_url text check (proof_url is null or proof_url ~ '^https://'),
  provider_ref text,
  idempotency_key text,
  note text check (char_length(note) <= 500),
  submitted_by uuid references public.profiles(id),
  verified_by uuid references public.profiles(id),
  verified_at timestamptz,
  created_at timestamptz not null default now()
);
create index payments_order_idx on public.payments(order_id);
create unique index payments_provider_ref_uq on public.payments(provider_ref) where provider_ref is not null;
create unique index payments_idem_uq on public.payments(order_id, idempotency_key) where idempotency_key is not null;
create unique index payments_one_verified_uq on public.payments(order_id) where status = 'verified';

-- emergency ------------------------------------------------------------
create table public.emergency_tickets (
  id uuid primary key default gen_random_uuid(),
  ticket_no text not null unique,
  customer_id uuid references public.profiles(id),
  customer_name text not null default 'Guest',
  customer_phone text,
  lat double precision not null check (lat between -90 and 90),
  lng double precision not null check (lng between -180 and 180),
  complaint text not null default '' check (char_length(complaint) <= 1000),
  status public.emergency_status not null default 'created',
  assigned_to uuid references public.profiles(id),
  distance_km numeric(8,2),
  visit_fee numeric(12,2) not null default 0,
  distance_fee numeric(12,2) not null default 0,
  estimated_cost numeric(12,2) not null default 0,
  actual_cost numeric(12,2),
  is_registered boolean not null default false,
  idempotency_key text,
  created_at timestamptz not null default now(),
  completed_at timestamptz,
  updated_at timestamptz not null default now()
);
create unique index emergency_idem_uq on public.emergency_tickets(customer_id, idempotency_key) where idempotency_key is not null;
create index emergency_status_idx on public.emergency_tickets(status, created_at desc);
create index emergency_assigned_idx on public.emergency_tickets(assigned_to) where assigned_to is not null;
create trigger emergency_updated before update on public.emergency_tickets for each row execute function public.set_updated_at();

create table public.mechanic_locations (        -- latest position only (keeps table tiny)
  ticket_id uuid primary key references public.emergency_tickets(id) on delete cascade,
  mechanic_id uuid not null references public.profiles(id),
  lat double precision not null check (lat between -90 and 90),
  lng double precision not null check (lng between -180 and 180),
  updated_at timestamptz not null default now()
);

-- inventory ------------------------------------------------------------
create table public.parts (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 200),
  category text not null default 'lainnya',
  unit text not null default 'pcs',
  quantity integer not null default 0 check (quantity >= 0),
  min_stock integer not null default 0 check (min_stock >= 0),
  price numeric(12,2) not null default 0 check (price >= 0),
  supplier text,
  catalog_item_id uuid references public.catalog_items(id),
  active boolean not null default true,
  legacy_ref text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index parts_low_idx on public.parts(quantity, min_stock) where active;
create trigger parts_updated before update on public.parts for each row execute function public.set_updated_at();

create table public.inventory_mutations (       -- append-only
  id uuid primary key default gen_random_uuid(),
  part_id uuid not null references public.parts(id),
  type public.mutation_type not null,
  quantity integer not null check (quantity > 0),
  quantity_after integer not null check (quantity_after >= 0),
  reason text check (char_length(reason) <= 300),
  reference_id text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);
create index inv_mut_part_idx on public.inventory_mutations(part_id, created_at desc);

-- discounts ------------------------------------------------------------
create table public.discount_requests (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id),
  original_amount numeric(12,2) not null check (original_amount >= 0),
  discount_amount numeric(12,2) not null check (discount_amount > 0),
  final_amount numeric(12,2) not null check (final_amount >= 0),
  reason text not null check (char_length(reason) between 3 and 500),
  requested_by uuid not null references public.profiles(id),
  approved_by uuid references public.profiles(id),
  status public.discount_status not null default 'requested',
  created_at timestamptz not null default now(),
  decided_at timestamptz,
  check (discount_amount <= original_amount)
);
create unique index discount_one_open_uq on public.discount_requests(order_id) where status = 'requested';
create index discount_status_idx on public.discount_requests(status, created_at desc);

-- system ---------------------------------------------------------------
create table public.settings (
  key text primary key,
  value text not null,
  type text not null default 'string',
  description text
);
create table public.audit_logs (
  id bigint generated always as identity primary key,
  at timestamptz not null default now(),
  actor uuid,
  action text not null,
  resource text,
  details jsonb not null default '{}'::jsonb
);
create index audit_at_idx on public.audit_logs(at desc);
create index audit_action_idx on public.audit_logs(action, at desc);

create table public.media_assets (               -- metadata only; files live in Cloudflare R2 (Phase 6)
  id uuid primary key default gen_random_uuid(),
  r2_key text not null unique,
  owner_id uuid references public.profiles(id),
  kind text not null check (kind in ('payment_proof','catalog_image','document','other')),
  mime_type text not null,
  size_bytes integer not null check (size_bytes > 0),
  ref_table text, ref_id uuid,
  created_at timestamptz not null default now()
);

-- Seed: values copied from existing config.js / init-sheets.gs (TO BE CONFIRMED by owner)
insert into public.settings(key,value,type,description) values
 ('TAX_PERCENTAGE','10','number','Pajak % (legacy default; owner to confirm)'),
 ('NORMAL_HOURS_START','6','number','Jam normal mulai (WIB)'),
 ('NORMAL_HOURS_END','18','number','Jam normal selesai (WIB)'),
 ('FREE_RADIUS_KM','30','number','Radius gratis emergency'),
 ('DISTANCE_FEE_PER_KM','10000','number','Biaya per km di atas radius'),
 ('GUEST_VISIT_FEE','250000','number','Biaya visit guest'),
 ('OFF_HOURS_VISIT_FEE','250000','number','Biaya visit di luar jam normal (member)'),
 ('BASE_LOCATION_LAT','-2.915','number','Lokasi bengkel lat'),
 ('BASE_LOCATION_LNG','104.758','number','Lokasi bengkel lng');
