-- PAS-One 0006: RLS performance. Wrapping auth.uid()/helpers in (select ...) makes Postgres evaluate them ONCE per statement (InitPlan)
-- instead of once per row. Policy semantics are unchanged (verified by the same RLS test-suite). Also adds supporting indexes.
drop policy profiles_select on public.profiles;           create policy profiles_select on public.profiles for select to authenticated using (id = (select auth.uid()) or (select public.is_staff()));
drop policy profiles_update_own on public.profiles;       create policy profiles_update_own on public.profiles for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()));
drop policy vehicles_select on public.vehicles;           create policy vehicles_select on public.vehicles for select to authenticated using (owner_id = (select auth.uid()) or (select public.is_staff()));
drop policy vehicles_insert on public.vehicles;           create policy vehicles_insert on public.vehicles for insert to authenticated with check (owner_id = (select auth.uid()));
drop policy vehicles_update on public.vehicles;           create policy vehicles_update on public.vehicles for update to authenticated using (owner_id = (select auth.uid())) with check (owner_id = (select auth.uid()));
drop policy vehicles_delete on public.vehicles;           create policy vehicles_delete on public.vehicles for delete to authenticated using (owner_id = (select auth.uid()));
drop policy catalog_read_active on public.catalog_items;  create policy catalog_read_active on public.catalog_items for select to anon, authenticated using (active or (select public.is_manager_up()));
drop policy catalog_insert on public.catalog_items;       create policy catalog_insert on public.catalog_items for insert to authenticated with check ((select public.is_manager_up()));
drop policy catalog_update on public.catalog_items;       create policy catalog_update on public.catalog_items for update to authenticated using ((select public.is_manager_up())) with check ((select public.is_manager_up()));
drop policy orders_select on public.orders;              create policy orders_select on public.orders for select to authenticated
  using (customer_id = (select auth.uid()) or created_by = (select auth.uid()) or mechanic_id = (select auth.uid()) or (select public.is_manager_up()));
drop policy order_items_select on public.order_items;    create policy order_items_select on public.order_items for select to authenticated
  using (exists (select 1 from public.orders o where o.id = order_id));
drop policy payments_select on public.payments;          create policy payments_select on public.payments for select to authenticated
  using ((select public.is_manager_up()) or exists (select 1 from public.orders o where o.id = order_id and (o.customer_id = (select auth.uid()) or o.created_by = (select auth.uid()))));
drop policy emergency_select on public.emergency_tickets; create policy emergency_select on public.emergency_tickets for select to authenticated
  using (customer_id = (select auth.uid()) or assigned_to = (select auth.uid()) or (select public.is_manager_up()));
drop policy parts_select on public.parts;                create policy parts_select on public.parts for select to authenticated using ((select public.is_staff()));
drop policy inv_mut_select on public.inventory_mutations; create policy inv_mut_select on public.inventory_mutations for select to authenticated using ((select public.is_staff()));
drop policy discount_select on public.discount_requests; create policy discount_select on public.discount_requests for select to authenticated using ((select public.is_manager_up()) or requested_by = (select auth.uid()));
drop policy settings_update on public.settings;         create policy settings_update on public.settings for update to authenticated using ((select public.is_admin())) with check ((select public.is_admin()));
drop policy audit_select on public.audit_logs;           create policy audit_select on public.audit_logs for select to authenticated using ((select public.is_manager_up()));
drop policy media_select on public.media_assets;         create policy media_select on public.media_assets for select to authenticated using (owner_id = (select auth.uid()) or (select public.is_manager_up()));
-- supporting indexes for policy predicates / FK lookups
create index if not exists orders_created_by_idx on public.orders(created_by, created_at desc);
create index if not exists payments_proof_media_idx on public.payments(proof_media_id) where proof_media_id is not null;
create index if not exists media_owner_idx on public.media_assets(owner_id);
create index if not exists discount_order_idx on public.discount_requests(order_id);
create index if not exists emergency_customer_idx on public.emergency_tickets(customer_id, created_at desc);
create index if not exists vehicles_owner_idx on public.vehicles(owner_id);
-- dashboard / reporting scans by date
create index if not exists orders_created_idx on public.orders(created_at desc);
create index if not exists orders_verified_idx on public.orders(created_at) where payment_status = 'verified' and order_status <> 'cancelled';
create index if not exists payments_created_idx on public.payments(created_at);
