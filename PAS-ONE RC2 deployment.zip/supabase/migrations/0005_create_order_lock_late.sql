-- PAS-One 0005: create_order v2 — take stock row locks LAST and only for tracked items.
-- Why: v1 locked every catalog row FOR UPDATE at the start of the transaction (even services with no stock) and held it until commit,
-- so a popular item serialized all buyers and exhausted the small connection pool (load test: 100 VUs -> pool timeouts).
-- Semantics unchanged: server pricing, idempotency, all-or-nothing, no overselling (re-checked under lock), same return shape.
create or replace function public.create_order(p_items jsonb, p_customer jsonb default '{}'::jsonb, p_idempotency_key text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  uid uuid := public._uid(); o public.orders; ids uuid[]; n int; agg jsonb;
  sub numeric(12,2) := 0; pct numeric := public.get_setting_num('TAX_PERCENTAGE'); tx numeric(12,2);
  cname text; cphone text;
begin
  if p_idempotency_key is not null then
    select * into o from public.orders where created_by = uid and idempotency_key = p_idempotency_key;
    if found then return jsonb_build_object('success',true,'orderId',o.id,'orderNo',o.order_no,'total',o.total,'duplicate',true); end if;
  end if;
  if p_items is null or jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) not between 1 and 50 then
    raise exception 'items must be an array of 1..50 entries'; end if;
  if exists (select 1 from jsonb_array_elements(p_items) x
             where jsonb_typeof(x) <> 'object'
                or case when (x->>'quantity') ~ '^[0-9]{1,4}$' then (x->>'quantity')::int not between 1 and 999 else true end
                or coalesce(x->>'id','') !~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$') then
    raise exception 'invalid items (id uuid, quantity 1..999)'; end if;
  select jsonb_agg(jsonb_build_object('id', id, 'qty', qty)) into agg
  from (select (x->>'id')::uuid as id, sum((x->>'quantity')::int)::int as qty from jsonb_array_elements(p_items) x group by 1) s;
  n := jsonb_array_length(agg);
  if exists (select 1 from jsonb_to_recordset(agg) as l(id uuid, qty int) where qty > 999) then raise exception 'invalid quantity (1..999)'; end if;
  select array_agg(id) into ids from jsonb_to_recordset(agg) as l(id uuid, qty int);

  -- no locks yet: validate + price from a consistent read
  if (select count(*) from public.catalog_items where id = any(ids) and active) <> n then raise exception 'item not found or inactive'; end if;
  if exists (select 1 from public.catalog_items c join jsonb_to_recordset(agg) as l(id uuid, qty int) on l.id = c.id where c.track_stock and c.stock < l.qty) then
    raise exception 'insufficient stock' using errcode = 'P0002'; end if;
  select sum(c.price * l.qty) into sub from public.catalog_items c join jsonb_to_recordset(agg) as l(id uuid, qty int) on l.id = c.id;
  tx := round(sub * pct / 100, 2);
  select coalesce(nullif(left(p_customer->>'name',120),''), p.name), coalesce(left(p_customer->>'phone',20), p.phone)
    into cname, cphone from public.profiles p where p.id = uid;

  begin
    insert into public.orders(order_no, customer_id, customer_name, customer_phone, subtotal, tax, total, idempotency_key, created_by)
    values ('ORD-' || to_char(now() at time zone 'Asia/Jakarta','YYMMDD') || '-' || lpad(nextval('public.order_no_seq')::text,5,'0'),
            uid, coalesce(cname,''), cphone, sub, tx, sub + tx, p_idempotency_key, uid)
    returning * into o;
  exception when unique_violation then
    select * into o from public.orders where created_by = uid and idempotency_key = p_idempotency_key;
    return jsonb_build_object('success',true,'orderId',o.id,'orderNo',o.order_no,'total',o.total,'duplicate',true);
  end;

  insert into public.order_items(order_id, catalog_item_id, name_snapshot, unit_price, quantity, line_total)
  select o.id, c.id, c.name, c.price, l.qty, c.price * l.qty from public.catalog_items c join jsonb_to_recordset(agg) as l(id uuid, qty int) on l.id = c.id;
  perform public._audit('ORDER_CREATED', o.order_no, jsonb_build_object('total', o.total, 'items', n));

  -- LAST step: lock only tracked stock rows (id order => no deadlocks), re-verify under lock, decrement. Lock is held only until commit.
  perform 1 from public.catalog_items c join jsonb_to_recordset(agg) as l(id uuid, qty int) on l.id = c.id where c.track_stock order by c.id for no key update of c;   -- NOT "for update": FK inserts above hold KEY SHARE on these rows; two FOR UPDATEs would deadlock
  if exists (select 1 from public.catalog_items c join jsonb_to_recordset(agg) as l(id uuid, qty int) on l.id = c.id where c.track_stock and c.stock < l.qty) then
    raise exception 'insufficient stock' using errcode = 'P0002'; end if;
  if exists (select 1 from public.catalog_items c join public.order_items i on i.catalog_item_id = c.id and i.order_id = o.id where c.price <> i.unit_price or not c.active) then
    raise exception 'price or availability changed, please retry'; end if;
  update public.catalog_items c set stock = c.stock - l.qty from jsonb_to_recordset(agg) as l(id uuid, qty int) where c.id = l.id and c.track_stock;

  return jsonb_build_object('success',true,'orderId',o.id,'orderNo',o.order_no,'subtotal',o.subtotal,'tax',o.tax,'total',o.total,'duplicate',false);
end $$;
grant execute on function public.create_order(jsonb,jsonb,text) to authenticated;
