-- Rollback for 0001..0003 (destroys data in these tables; dev only)
drop table if exists public.media_assets, public.audit_logs, public.settings, public.discount_requests,
  public.inventory_mutations, public.parts, public.mechanic_locations, public.emergency_tickets,
  public.payments, public.order_items, public.orders, public.catalog_items, public.vehicles, public.profiles cascade;
drop sequence if exists public.order_no_seq;
drop type if exists public.mutation_type, public.discount_status, public.emergency_status, public.payment_status, public.order_status, public.user_role cascade;
drop function if exists public.set_updated_at() cascade;
