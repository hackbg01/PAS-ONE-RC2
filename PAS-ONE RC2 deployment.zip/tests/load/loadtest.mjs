// Load test: N concurrent virtual users, each repeating: catalog read -> create order -> submit payment -> list own orders.
// Usage: node loadtest.mjs <vus> <seconds> [baseUrl=http://localhost:3001] ; needs JWT secret of the target (local test stack only).
import crypto from 'node:crypto'; import os from 'node:os';
const VUS = +process.argv[2] || 50, SECS = +process.argv[3] || 30, BASE = process.argv[4] || 'http://localhost:3001', SECRET = process.env.JWT_SECRET || 'test-secret-test-secret-test-secret-123';
const ITEM = process.env.ITEM_ID || '10000000-0000-0000-0000-0000000000a0';
const b64 = o => Buffer.from(JSON.stringify(o)).toString('base64url');
const jwt = sub => { const h = b64({ alg: 'HS256', typ: 'JWT' }), p = b64({ sub, role: 'authenticated', exp: Math.floor(Date.now() / 1000) + 3600 }); return h + '.' + p + '.' + crypto.createHmac('sha256', SECRET).update(h + '.' + p).digest('base64url'); };
const lat = { catalog: [], create_order: [], submit_payment: [], list_orders: [] }; const errs = { catalog: 0, create_order: 0, submit_payment: 0, list_orders: 0 }; const samples = [];
const pct = (a, p) => { if (!a.length) return 0; const s = [...a].sort((x, y) => x - y); return s[Math.min(s.length - 1, Math.ceil(p / 100 * s.length) - 1)]; };
async function call(name, tok, path, method = 'GET', body) {
  const t0 = performance.now();
  try { const r = await fetch(BASE + path, { method, headers: { Authorization: 'Bearer ' + tok, apikey: tok, 'Content-Type': 'application/json' }, body: body && JSON.stringify(body) }); const j = await r.json().catch(() => null); lat[name].push(performance.now() - t0); if (!r.ok) { errs[name]++; if (samples.length < 3) samples.push([name, r.status, JSON.stringify(j).slice(0, 120)]); } return r.ok ? j : null; }
  catch (e) { lat[name].push(performance.now() - t0); errs[name]++; if (samples.length < 3) samples.push([name, 'EXC', String(e)]); return null; }
}
const stop = Date.now() + SECS * 1000; let flows = 0;
async function vu(i) {
  const uid = '50000000-0000-0000-0000-' + String(i).padStart(12, '0'), tok = jwt(uid);
  while (Date.now() < stop) {
    await call('catalog', tok, '/rest/v1/catalog_items?select=*&order=name&limit=100');
    const o = await call('create_order', tok, '/rest/v1/rpc/create_order', 'POST', { p_items: [{ id: ITEM, quantity: 1 }], p_customer: {}, p_idempotency_key: crypto.randomUUID() });
    if (o && o.orderId) await call('submit_payment', tok, '/rest/v1/rpc/submit_payment', 'POST', { p_order_id: o.orderId, p_method: 'qris', p_proof_url: null, p_idempotency_key: crypto.randomUUID() });
    await call('list_orders', tok, `/rest/v1/orders?select=*,order_items(*)&customer_id=eq.${uid}&order=created_at.desc&limit=20`);
    flows++; await new Promise(r => setTimeout(r, 200 + Math.random() * 400));       // think time 0.2-0.6 s
  }
}
const t0 = Date.now(); await Promise.all(Array.from({ length: VUS }, (_, i) => vu(i + 1))); const dur = (Date.now() - t0) / 1000;
const total = Object.values(lat).reduce((a, b) => a + b.length, 0), totalErr = Object.values(errs).reduce((a, b) => a + b, 0);
console.log(`\n== ${VUS} concurrent VUs, ${dur.toFixed(0)} s, host: ${os.cpus().length} vCPU, ${(os.totalmem() / 2 ** 30).toFixed(1)} GiB RAM (local Postgres+PostgREST, NOT Supabase Free)`);
console.log(`flows=${flows} requests=${total} (${(total / dur).toFixed(1)} req/s) errors=${totalErr} (${(100 * totalErr / total).toFixed(2)}%)`);
console.log('endpoint         n     err   p50ms  p95ms  p99ms  max');
for (const k of Object.keys(lat)) console.log(k.padEnd(15), String(lat[k].length).padStart(6), String(errs[k]).padStart(5), pct(lat[k], 50).toFixed(0).padStart(7), pct(lat[k], 95).toFixed(0).padStart(6), pct(lat[k], 99).toFixed(0).padStart(6), Math.max(0, ...lat[k]).toFixed(0).padStart(6));
if (samples.length) console.log('error samples:', JSON.stringify(samples));
