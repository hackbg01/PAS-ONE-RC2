# Local end-to-end harness (no Supabase account needed)
Stack: local Postgres 16 + migrations + PostgREST (static binary from GitHub releases) + `gw.js` (adds Supabase's `/rest/v1` prefix) + real `client.js`/`supabase-js`.
Not covered locally: GoTrue (Supabase Auth) — JWTs are minted in the tests; anonymous sign-in is stubbed in the browser test.
Order: `supabase/tests/run_all.sh` (SQL), `supabase/tests/20_concurrency.sh`, then `node e2e.js` (adapter, all roles), `node ui.js` (Chromium UI flow), `node xss.js`. Run `psql -f reset.sql` between e2e runs.
