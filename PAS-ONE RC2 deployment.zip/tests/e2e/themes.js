const { chromium } = require('playwright'); const crypto=require('crypto'); const { execSync } = require('child_process'); const fs=require('fs');
const SECRET='test-secret-test-secret-test-secret-123'; const b64=o=>Buffer.from(JSON.stringify(o)).toString('base64url');
const ANON=(()=>{const h=b64({alg:'HS256',typ:'JWT'}),p=b64({role:'anon'});return h+'.'+p+'.'+crypto.createHmac('sha256',SECRET).update(h+'.'+p).digest('base64url');})();
// baseline copy for default-theme parity

const lum=c=>{const [r,g,b]=c.map(v=>{v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)});return .2126*r+.7152*g+.0722*b;};
const ratio=(a,b)=>{const l1=lum(a),l2=lum(b);return (Math.max(l1,l2)+.05)/(Math.min(l1,l2)+.05);};
const rgb=s=>s.match(/[\d.]+/g).slice(0,3).map(Number);
(async()=>{
 const br=await chromium.launch(); let pass=0,fail=0; const t=(n,c,x='')=>{(c?pass++:fail++);console.log((c?'PASS':'FAIL')+' : '+n+(c?'':'  -> '+x));};
 async function open(dir,port,theme,vw=1280){
   const ctx=await br.newContext({viewport:{width:vw,height:800}}); const pg=await ctx.newPage();
   await pg.route('**/cdn.jsdelivr.net/**/supabase.js',r=>r.fulfill({path:'/home/claude/e2e/node_modules/@supabase/supabase-js/dist/umd/supabase.js',contentType:'application/javascript'}));
   await pg.route('**/js/config.js',async r=>{const res=await r.fetch();let b=await res.text();b=b.replace("'YOUR_SUPABASE_URL'","'http://localhost:3001'").replace("'YOUR_SUPABASE_ANON_KEY'","'"+ANON+"'");r.fulfill({body:b,contentType:'application/javascript'});});
   if(theme) await pg.addInitScript(th=>localStorage.setItem('pas_theme',th),theme);
   return pg; }
 // 1) default theme parity vs baseline on static pages (login/register), selector hidden
 for (const route of ['#/login','#/register']) {
   const a=await open(null,8080,'default'); await a.goto('http://localhost:8080/index.html'+route); await a.addStyleTag({content:'li:has(#theme-select){display:none}.notification{display:none}'}); await a.waitForTimeout(500);
   const sa=await a.screenshot({path:'/tmp/new_'+route.slice(2)+'.png'});
   const b=await open(null,8081,null); await b.goto('http://localhost:8081/index.html'+route); await b.addStyleTag({content:'.notification{display:none}'}); await b.waitForTimeout(500);
   const sb=await b.screenshot({path:'/tmp/old_'+route.slice(2)+'.png'});
   const diff=execSync(`python3 - <<'PY'\nfrom PIL import Image, ImageChops\na=Image.open('/tmp/new_${route.slice(2)}.png').convert('RGB'); b=Image.open('/tmp/old_${route.slice(2)}.png').convert('RGB')\nd=ImageChops.difference(a,b); bb=d.getbbox(); print(0 if bb is None else sum(1 for p in d.getdata() if p!=(0,0,0)))\nPY`).toString().trim();
   t('T-default parity '+route+' (differing pixels vs baseline; selector hidden)', +diff<=2000, diff+' px differ');
 }
 // 2) contrast per theme
 const pairs=[['body text on page','body','color','backgroundColor'],['primary button text','.btn-primary','color','backgroundColor']];
 for (const th of ['default','light','dark','editorial','industrial']) {
   const pg=await open(null,8080,th); await pg.goto('http://localhost:8080/index.html#/cart'); await pg.waitForSelector('body'); 
   const r=await pg.evaluate(()=>{const cs=(sel,p)=>getComputedStyle(document.querySelector(sel))[p]; const v=n=>getComputedStyle(document.documentElement).getPropertyValue(n).trim();
     const probe=(c)=>{const e=document.createElement('i');e.style.color=c;document.body.appendChild(e);const o=getComputedStyle(e).color;e.remove();return o;};
     return {text:probe(v('--color-text')),page:probe(v('--page-bg')),surface:probe(v('--surface')),navy:probe(v('--color-navy')),onAccent:probe(v('--on-accent')),gold:probe(v('--color-gold')),
       sf:probe(v('--success-fg')),sb:probe(v('--success-bg')),df:probe(v('--danger-fg')),db:probe(v('--danger-bg')),wf:probe(v('--warning-fg')),wb:probe(v('--warning-bg')),gd:probe(v('--color-gray-dark')),ba:probe(v('--brand-accent')),as:probe(v('--accent-on-surface')),gl:probe(v('--color-gray-light'))};});
   const chk=(n,a,b,min=4.5)=>{const x=ratio(rgb(a),rgb(b));t(`T-contrast ${th}: ${n} = ${x.toFixed(1)}:1`, x>=min, x.toFixed(2));};
   chk('text on page',r.text,r.page); chk('text on surface',r.text,r.surface); chk('text on gray-light',r.text,r.gl); chk('on-accent on primary',r.onAccent,r.navy);
   chk('success text',r.sf,r.sb); chk('danger text',r.df,r.db); chk('warning text',r.wf,r.wb); chk('muted text on surface',r.gd,r.surface); chk('brand accent on navbar',r.ba,r.navy); if(th!=='default'){chk('accent (price/stat) on surface',r.as,r.surface); chk('accent (stat) on gray-light',r.as,r.gl,3);} else console.log('NOTE : default accent gold on white = '+ratio(rgb(r.as),rgb(r.surface)).toFixed(1)+':1 (pre-existing in original design; left unchanged per J5)');
 }
 // 3) screenshots
 const shots=[]; for (const th of ['default','light','dark','editorial','industrial']) {
   const pg=await open(null,8080,th); await pg.goto('http://localhost:8080/index.html#/catalog'); await pg.waitForSelector('.catalog-item'); await pg.waitForTimeout(300);
   await pg.screenshot({path:`/tmp/th_${th}.png`}); shots.push(th);
   const m=await open(null,8080,th,390); await m.goto('http://localhost:8080/index.html#/catalog'); await m.waitForSelector('.catalog-item'); const ov=await m.evaluate(()=>document.documentElement.scrollWidth>window.innerWidth+1);
   t('T-responsive '+th+' @390px no horizontal overflow', !ov);
 }
 // 4) persistence + isolation
 const pg=await open(null,8080,null); await pg.goto('http://localhost:8080/index.html'); await pg.selectOption('#theme-select','dark'); await pg.reload(); await pg.waitForSelector('#theme-select');
 t('T-persist: choice survives reload', (await pg.evaluate(()=>document.documentElement.dataset.theme))==='dark' && (await pg.inputValue('#theme-select'))==='dark');
 const cnt=async()=>pg.locator('.catalog-item').count(); await pg.waitForSelector('.catalog-item'); const before=await cnt(); await pg.selectOption('#theme-select','industrial'); t('T-isolation: theme switch does not change data/routes', (await cnt())===before && pg.url().includes('index.html'));
 console.log(`THEME TOTAL PASS=${pass} FAIL=${fail}`); await br.close();
})();
