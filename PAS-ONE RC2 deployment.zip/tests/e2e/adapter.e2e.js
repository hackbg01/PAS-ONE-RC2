// E2E: frontend adapter (js/api/supabase-client.js) -> supabase-js -> PostgREST -> Postgres RLS/RPC.
// Auth endpoints (GoTrue) are NOT part of this local stack: identities are injected as signed JWTs.
// Run: bash supabase/tests/e2e_setup.sh && (cd tests/e2e && npm i) && node tests/e2e/adapter.e2e.js
const jwt = require('jsonwebtoken'); const { createClient } = require('@supabase/supabase-js'); const fs = require('fs'); const path = require('path');
// supabase-js talks to <url>/rest/v1/...; local PostgREST serves at root -> tiny prefix-stripping proxy (mimics Supabase's gateway)
const http = require('http');
const proxy = http.createServer((req, res) => {
  const p = http.request({ host: 'localhost', port: 3111, path: req.url.replace(/^\/rest\/v1/, ''), method: req.method, headers: { ...req.headers, host: 'localhost:3111' } }, r => { res.writeHead(r.statusCode, r.headers); r.pipe(res); });
  req.pipe(p);
}); proxy.listen(3112);
const URL = 'http://localhost:3112', SECRET = 'e2e-test-secret-e2e-test-secret-1234';
const ID = { alice: '00000000-0000-0000-0000-0000000000a1', bob: '00000000-0000-0000-0000-0000000000b2', admin: '00000000-0000-0000-0000-0000000000d4',
  mgr: '00000000-0000-0000-0000-0000000000e5', mech: '00000000-0000-0000-0000-0000000000f6', guest: '00000000-0000-0000-0000-0000000000a7' };
const token = (sub, anon) => jwt.sign({ sub, role: 'authenticated', is_anonymous: !!anon, aud: 'authenticated' }, SECRET, { expiresIn: '1h' });
let who = { sub: '00000000-0000-0000-0000-0000000000a1', anon: false };   // default identity for the auto-created window.api
global.window = global;
window.APP_CONFIG = { BACKEND: 'supabase', SUPABASE_URL: URL, SUPABASE_ANON_KEY: 'anon-placeholder' };
window.__supabaseFactory = (url, key) => {
  const me = who;   // capture identity at client creation
  const c = createClient(url, key, { global: { headers: { Authorization: 'Bearer ' + token(me.sub, me.anon) } }, auth: { persistSession: false, autoRefreshToken: false } });
  c.auth.getSession = async () => ({ data: { session: { user: { id: me.sub }, access_token: 'x' } } });   // GoTrue stand-in
  return c;
};
eval(fs.readFileSync(path.join(__dirname, '../../frontend/js/api/supabase-client.js'), 'utf8'));
const as = (name, anon) => { who = { sub: ID[name], anon }; return new window.SupabaseApiClient(); };
let pass = 0, fail = 0; const ck = (n, c, extra) => { console.log((c ? 'PASS' : 'FAIL') + ' : ' + n + (c ? '' : '  -> ' + JSON.stringify(extra))); c ? pass++ : fail++; };

(async () => {
  const anon = createClient(URL, jwt.sign({ role: 'anon' }, SECRET)); // public anon key (role anon)
  let r = await anon.from('catalog_items').select('id').limit(1); ck('E1 anonymous visitor can read catalog', r.data && r.data.length === 1, r.error);
  r = await anon.from('orders').select('id'); ck('E1b anonymous cannot read orders', !!r.error, r);

  const alice = as('alice'), bob = as('bob'), mgr = as('mgr'), mech = as('mech'), adm = as('admin'), guest = as('guest', true);
  let cat = await alice.getCatalog();
  ck('E2 catalog legacy shape (items[].price number)', cat.success && cat.items.length === 3 && typeof cat.items[0].price === 'number', cat);
  const oil = cat.items.find(i => i.name.startsWith('Ganti Oli')), svc = cat.items.find(i => i.name.startsWith('Service'));

  let o = await alice.createOrder([{ id: oil.id, quantity: 2, price: 1, name: 'x' }, { id: svc.id, quantity: 1 }], { name: 'Alice W' }, 'k1');
  ck('E3 createOrder: legacy orderId=ORD-..., server total (2*150000+200000)*1.11=555000', o.success && /^ORD-/.test(o.orderId) && o.total === 555000, o);
  const o2 = await alice.createOrder([{ id: oil.id, quantity: 2 }, { id: svc.id, quantity: 1 }], {}, 'k1');
  ck('E3b same idempotency key -> same order', o2.duplicate === true && o2.orderId === o.orderId, o2);
  const bad = await alice.createOrder([{ id: oil.id, quantity: 50 }], {}, 'k2');
  ck('E3c overselling gives Indonesian message', bad.success === false && bad.error === 'Stok tidak mencukupi', bad);
  const neg = await alice.createOrder([{ id: oil.id, quantity: -1 }], {}, 'k3'); ck('E3d negative qty rejected', neg.success === false, neg);

  const ob = await bob.createOrder([{ id: svc.id, quantity: 1 }], {}, 'kb');
  let la = await alice.listOrders(); ck('E4 alice lists only her orders with items', la.success && la.orders.length === 1 && la.orders[0].items.length === 2 && la.orders[0].customerData.name === 'Alice W', la);
  const peek = await alice.getOrder(ob.orderId); ck('E4b alice cannot open bob\'s order', peek.success === false, peek);
  const lm = await mgr.listOrders(); ck('E4c manager lists all orders', lm.orders.length === 2, lm);

  const pend = await mgr.listOrders({ paymentStatus: 'pending_payment' });
  ck('E5 legacy filter paymentStatus=pending_payment works', pend.orders.length === 2, pend);
  const sub = await alice.verifyPayment(o.orderId, { method: 'qris', proofUrl: 'https://example.com/bukti.jpg' });
  ck('E6 customer verifyPayment => submit_payment (pending)', sub.success && sub.paymentId, sub);
  const ps = await alice.getPaymentStatus(o.orderId); ck('E6b payment status readable by owner', ps.success && ps.status === 'pending', ps);
  const fake = await alice.updateOrderStatus(o.orderId, 'payment_verified'); ck('E6c customer cannot self-verify', fake.success === false && /akses/.test(fake.error), fake);
  const ver = await mgr.verifyPayment(o.orderId, { method: 'qris' }); ck('E7 manager verifies', ver.success && ver.alreadyVerified === false, ver);
  const ver2 = await mgr.verifyPayment(o.orderId, {}); ck('E7b duplicate verify idempotent', ver2.alreadyVerified === true, ver2);
  const rej = await mgr.updateOrderStatus(ob.orderId, 'payment_rejected'); ck('E8 legacy reject (status payment_rejected) works', rej.success, rej);
  const ob2 = await mgr.getOrder(ob.orderId); ck('E8b order now payment_rejected/failed', ob2.order.orderStatus === 'payment_rejected' && ob2.order.paymentStatus === 'failed', ob2);

  const ms = await mgr.listMechanics(); ck('E9 list mechanics', ms.success && ms.mechanics.length === 1, ms);
  const as1 = await mgr.assignOrderMechanic(o.orderId, ms.mechanics[0].id); ck('E9b assign mechanic', as1.success, as1);
  const st1 = await mgr.updateOrderStatus(o.orderId, 'in_progress'); const st2 = await mech.updateOrderStatus(o.orderId, 'completed');
  ck('E9c in_progress by manager, completed by assigned mechanic', st1.success && st2.success, [st1, st2]);
  const mo = await mech.listOrders(); ck('E9d mechanic sees only assigned orders', mo.orders.length === 1, mo);

  // emergency
  const e = await guest.createEmergency({ lat: -2.915, lng: 104.758, complaint: 'Mogok', customerName: 'Guest', customerPhone: 'N/A' });
  ck('E10 guest emergency: legacy ticketId=EMG-..., guest fee 250000', e.success && /^EMG-/.test(e.ticketId) && e.estimatedCost === 250000, e);
  const eg = await guest.getEmergency(e.ticketId); ck('E10b guest reads own ticket', eg.success && eg.ticket.status === 'created', eg);
  const ea = await alice.getEmergency(e.ticketId); ck('E10c other customer cannot read it', ea.success === false, ea);
  const as2 = await mgr.assignEmergencyMechanic(e.ticketId, ms.mechanics[0].id); ck('E11 assign emergency', as2.success, as2);
  const s1 = await mech.updateEmergencyStatus(e.ticketId, 'in_progress'); const loc = await mech.shareLocation(e.ticketId, -2.9, 104.7);
  ck('E11b mechanic progresses + shares location', s1.success && loc.success, [s1, loc]);
  const gl = await guest.getMechanicLocation(e.ticketId); ck('E11c customer sees mechanic location', gl.location && gl.location.lat === -2.9, gl);
  const done = await mech.updateEmergencyStatus(e.ticketId, 'completed'); ck('E11d complete', done.success, done);

  // inventory
  const imp = await mgr.importInventoryCSV('name,category,unit,quantity,min_stock,price,supplier\nKampas Rem,spare-part,pcs,10,3,85000,CV Maju\nOli Mesin,oil,liter,20,5,70000,\n');
  ck('E12 CSV import creates 2 parts', imp.success && imp.created === 2, imp);
  let inv = await mgr.getInventory(); ck('E12b inventory legacy shape (id/minStock)', inv.items.length === 2 && inv.items[0].minStock !== undefined && inv.items[0].id, inv);
  const part = inv.items.find(p => p.name === 'Kampas Rem');
  const mu = await mech.inventoryMutation(part.id, 'out', 4, 'order', 'ORD-1'); ck('E13 stock out by mechanic -> 6', mu.success && mu.quantity === 6, mu);
  const mu2 = await mech.inventoryMutation(part.id, 'out', 99, 'order'); ck('E13b cannot go negative', mu2.success === false && mu2.error === 'Stok tidak mencukupi', mu2);
  const sp = await mgr.savePart({ id: part.id, name: 'Kampas Rem Depan', category: 'spare-part', unit: 'pcs', minStock: 7, price: 90000 });
  inv = await mgr.getInventory(); const p2 = inv.items.find(p => p.id === part.id);
  ck('E13c edit part metadata keeps quantity', sp.success && p2.name === 'Kampas Rem Depan' && p2.quantity === 6 && p2.minStock === 7, p2);
  const ci = await alice.getInventory(); ck('E13d customer sees no inventory', ci.success && ci.items.length === 0, ci);

  // discount
  const oc = await alice.createOrder([{ id: svc.id, quantity: 1 }], {}, 'kd');
  await mgr.assignOrderMechanic(oc.orderId, ms.mechanics[0].id);   // mechanics only see (and can discount) orders assigned to them
  const dr = await mech.requestDiscount({ orderId: oc.orderId, amount: 20000, reason: 'Pelanggan loyal' }); ck('E14 staff requests discount', dr.success, dr);
  const dl = await mgr.listDiscounts('requested'); ck('E14b manager lists pending discounts', dl.requests.length === 1 && dl.requests[0].orders.order_no === oc.orderId, dl);
  const da = await mgr.approveDiscount(dl.requests[0].id, true); const og = await alice.getOrder(oc.orderId);
  ck('E14c approve => total (200000-20000)*1.11=199800', da.success && og.order.total === 199800, og);
  const dm = await alice.requestDiscount({ orderId: oc.orderId, amount: 1000, reason: 'minta diskon' }); ck('E14d customer cannot request discount', dm.success === false, dm);

  // dashboard / audit / catalog admin
  const dash = await mgr.getDashboard('management'); ck('E15 dashboard real numbers', dash.success && dash.bookingToday === 3 && dash.revenue === 550000, dash);
  const dc = await alice.getDashboard('admin'); ck('E15b customer denied dashboard', dc.success === false, dc);
  const au = await mgr.getAuditLog({ limit: 10 }); ck('E16 manager reads audit log', au.success && au.logs.length > 0, au);
  const ac = await alice.getAuditLog(); ck('E16b customer audit log empty', ac.success && ac.logs.length === 0, ac);
  const cc = await adm.createCatalogItem({ name: 'Busi NGK', category: 'spare-part', description: 'Busi', price: 45000, stock: 40 }); ck('E17 admin creates catalog item', cc.success, cc);
  const cu = await adm.updateCatalogItem(cc.itemId, { price: 50000 }); const cd = await adm.deleteCatalogItem(cc.itemId);
  const vis = await alice.getCatalog(); const adminView = await adm.getCatalog({ includeInactive: true });
  ck('E17b update + soft delete: hidden from customers, visible to admin', cu.success && cd.success && !vis.items.find(i => i.id === cc.itemId) && adminView.items.find(i => i.id === cc.itemId && !i.active), [cu, cd]);
  const cx = await alice.createCatalogItem({ name: 'Hack', category: 'x', price: 1 }); ck('E17c customer cannot create catalog item', cx.success === false, cx);
  const ru = await alice._profile(); ck('E18 profile role readable', ru.role === 'customer', ru);
  const hack = await alice.sb.from('profiles').update({ role: 'admin' }).eq('id', ID.alice); ck('E18b customer cannot self-promote', !!hack.error, hack);
  console.log(`\nTOTAL PASS=${pass} FAIL=${fail}`); proxy.close(); process.exit(fail ? 1 : 0);
})().catch(e => { console.error('CRASH', e); process.exit(2); });
