// Mimics Supabase's /rest/v1 gateway prefix in front of a bare PostgREST (test harness only)
require('http').createServer((req,res)=>{
  const u=req.url.replace(/^\/rest\/v1/,'');
  const p=require('http').request({host:'localhost',port:3000,path:u,method:req.method,headers:req.headers},r=>{res.writeHead(r.statusCode,r.headers);r.pipe(res)});
  p.on('error',e=>{res.statusCode=502;res.end(String(e))}); req.pipe(p);
}).listen(3001);
