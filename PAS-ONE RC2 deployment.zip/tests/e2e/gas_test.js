// Runs reporting/sheets-sync.gs in a vm with Apps Script globals mocked; HTTP goes to the REAL local PostgREST stack.
const vm=require('vm'),fs=require('fs'),crypto=require('crypto'); const SECRET='test-secret-test-secret-test-secret-123';
const b64=o=>Buffer.from(JSON.stringify(o)).toString('base64url'); const jwt=sub=>{const h=b64({alg:'HS256',typ:'JWT'}),p=b64({sub,role:'authenticated',exp:Math.floor(Date.now()/1000)+3600});return h+'.'+p+'.'+crypto.createHmac('sha256',SECRET).update(h+'.'+p).digest('base64url');};
const MG='00000000-0000-0000-0000-0000000000e5', ALICE='00000000-0000-0000-0000-0000000000a1';
const props={SUPABASE_URL:'http://localhost:3001',SUPABASE_ANON_KEY:'anon',REPORT_EMAIL:'mgr@t',REPORT_PASSWORD:'secret-pw'}; const sheets={}; const logs=[];
const {execFileSync}=require('child_process');
function http(url,opt){const args=['-s','-m','20','-o','/tmp/gas_body','-w','%{http_code}','-X',opt.method.toUpperCase(),url];for(const [k,v] of Object.entries(opt.headers||{}))args.push('-H',k+': '+v);args.push('-H','Content-Type: application/json','-d',opt.payload);const code=execFileSync('curl',args).toString();return {getResponseCode:()=>+code,getContentText:()=>fs.readFileSync('/tmp/gas_body','utf8')};}
const ctx={PropertiesService:{getScriptProperties:()=>({getProperty:k=>props[k]||null})},
 UrlFetchApp:{fetch:(url,opt)=>{ if(url.includes('/auth/v1/token')){const b=JSON.parse(opt.payload); logs.push('login '+b.email); return b.password==='secret-pw'?{getResponseCode:()=>200,getContentText:()=>JSON.stringify({access_token:jwt(MG)})}:{getResponseCode:()=>400,getContentText:()=>'{"error":"bad"}'}; } return http(url,opt);}},
 SpreadsheetApp:{getActiveSpreadsheet:()=>({getSheetByName:n=>sheets[n]||null,insertSheet:n=>sheets[n]={data:null,clearContents(){this.data=null},getRange(r,c,nr,nc){return{setValues:v=>{this.data=v}}},setFrozenRows(){}}})},
 Utilities:{formatDate:(d,tz,f)=>new Date(d.getTime()+7*3600e3).toISOString().slice(0,10)},ScriptApp:{},console,JSON,Date,Error};
vm.createContext(ctx); vm.runInContext(fs.readFileSync('/home/claude/pas-repo/reporting/sheets-sync.gs','utf8'),ctx);
let pass=0,fail=0;const t=(n,c,x='')=>{(c?pass++:fail++);console.log((c?'PASS':'FAIL')+' : '+n+(c?'':' -> '+JSON.stringify(x)));};
(async()=>{
 const today=new Date(Date.now()+7*3600e3).toISOString().slice(0,10); const from=new Date(Date.now()-5*864e5).toISOString().slice(0,10);
 const n=ctx.syncReports(from,today); t('G1 syncReports returns row counts',n.orders>=1,n);
 t('G2 Orders sheet has header + rows matching DB',sheets.Orders.data[0][0]==='Order'&&sheets.Orders.data.length===n.orders+1,sheets.Orders.data.slice(0,2));
 t('G3 Summary sheet present',sheets.Summary.data[1][1]===n.orders||sheets.Summary.data[1][1]>=1,sheets.Summary.data);
 const n2=ctx.syncReports(from,today); t('G4 idempotent: second run rewrites, same row counts',JSON.stringify(n2)===JSON.stringify(n),[n,n2]);
 props.REPORT_PASSWORD='wrong'; let e=null; try{ctx.syncReports(from,today)}catch(x){e=x.message}; t('G5 wrong credentials -> clear error without echoing secrets',/login failed/.test(e||'')&&!/wrong|secret/.test(e||''),e);
 props.REPORT_PASSWORD='secret-pw'; delete props.SUPABASE_URL; e=null; try{ctx.syncReports(from,today)}catch(x){e=x.message}; t('G6 missing property -> explicit error',/Missing script property/.test(e||''),e); props.SUPABASE_URL='http://localhost:3001';
 e=null; try{ctx.syncReports('2020-01-01',today)}catch(x){e=x.message}; t('G7 server rejects range > 92 days',/report_export failed/.test(e||''),e);
 console.log('GAS TOTAL PASS='+pass+' FAIL='+fail);
})();
