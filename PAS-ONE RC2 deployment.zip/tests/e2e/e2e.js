const vm = require('vm'), fs = require('fs'), crypto = require('crypto');
const { createClient } = require('@supabase/supabase-js');
const URL_ = 'http://localhost:3001', SECRET = 'test-secret-test-secret-test-secret-123';
const b64 = o => Buffer.from(JSON.stringify(o)).toString('base64url');
const jwt = c => { const h = b64({alg:'HS256',typ:'JWT'}), p = b64(c); return h+'.'+p+'.'+crypto.createHmac('sha256',SECRET).update(h+'.'+p).digest('base64url'); };
const code = fs.readFileSync('/home/claude/pas-repo/frontend/js/api/client.js','utf8');
const ctx = { window: { APP_CONFIG: { SUPABASE_URL: URL_, SUPABASE_ANON_KEY: 'x', MEDIA_WORKER_URL: 'http://localhost:8787' }, supabase: { createClient: () => ({}) }, prepareUpload: async f => f }, console: { error(){} }, fetch, Blob };
vm.createContext(ctx); const ApiClient = vm.runInContext(code + ';ApiClient', ctx);
function as(uid, anon=false) {   // adapter wired to real PostgREST with a minted JWT (GoTrue itself is Supabase's, not under test)
  const api = new ApiClient(); const token = uid ? jwt({sub:uid, role:'authenticated', is_anonymous:anon, aud:'authenticated'}) : jwt({role:'anon'});
  const sb = createClient(URL_, 'anon', { auth: { persistSession:false, autoRefreshToken:false }, global: { headers: { Authorization: 'Bearer '+token } } });
  sb.auth.getSession = async () => ({ data: { session: uid ? { access_token: token, user: { id: uid, is_anonymous: anon } } : null } });
  api.sb = sb; api.configured = true; return api;
}
const ID = { A:'00000000-0000-0000-0000-0000000000a1', MG:'00000000-0000-0000-0000-0000000000e5', ME:'00000000-0000-0000-0000-0000000000f6', G:'00000000-0000-0000-0000-0000000000a7' };
const OLI='10000000-0000-0000-0000-000000000001', SVC='10000000-0000-0000-0000-000000000002';
let pass=0, fail=0, r2; const t = (n,c,x='') => { (c?pass++:fail++); console.log((c?'PASS':'FAIL')+' : '+n+(c?'':'  -> '+JSON.stringify(x))); };
(async () => {
  if (process.env.DBG) { const a = as(ID.A); console.log(JSON.stringify(await a.sb.from('catalog_items').select('*'))); }
  const anon = as(null), alice = as(ID.A), mg = as(ID.MG), me = as(ID.ME), guest = as(ID.G, true);
  let r = await anon.getCatalog(); t('E1 anon catalog list, legacy shape', r.success && r.items.length===2 && typeof r.items[0].price==='number' && 'stock' in r.items[0], r);
  r = await alice.getCurrentUser(); t('E2 getCurrentUser returns role customer', r.success && r.user.role==='customer' && r.user.name==='Alice', r);
  r = await anon.getCurrentUser(); t('E2b anon getCurrentUser -> unauthorized', r.success===false);
  r = await alice.createOrder([{id:OLI,name:'x',price:1,quantity:2}], {name:'Alice W'}, 'k1');
  t('E3 createOrder ignores client price; total 330000; legacy orderId=ORD-…', r.success && r.total===330000 && /^ORD-/.test(r.orderId), r);
  const ordNo = r.orderId; r2 = await alice.createOrder([{id:OLI,quantity:2}], {}, 'k1'); t('E3b idempotent createOrder', r2.duplicate===true && r2.orderId===ordNo, r2);
  r = await alice.createOrder([{id:OLI,quantity:9}]); t('E4 oversell -> friendly error "Stok tidak mencukupi"', r.success===false && /Stok tidak/.test(r.error), r);
  r = await alice.listOrders(); const o = r.orders && r.orders[0];
  t('E5 listOrders legacy shape (orderId,customerData.name,items[],total,orderStatus,paymentStatus)', r.success && r.orders.length===1 && o.orderId===ordNo && o.customerData.name==='Alice W' && o.items[0].name==='Ganti Oli' && o.total===330000 && o.orderStatus==='pending_payment' && o.paymentStatus==='pending', r);
  r = await alice.getOrder(ordNo); t('E5b getOrder by ORD number', r.success && r.order.items.length===1, r);
  r = await mg.listOrders({paymentStatus:'pending_payment'}); t('E6 manager sees pending-payment orders (payment-verification module filter)', r.success && r.orders.some(x=>x.orderId===ordNo), r);
  r = await guest.listOrders(); t('E6b guest sees none', r.success && r.orders.length===0, r);
  r = await alice.verifyPayment(ordNo, {method:'qris'}); t('E7 customer cannot verify (friendly "tidak memiliki akses")', r.success===false && /akses/.test(r.error), r);
  r = await alice.submitPayment(ordNo,'qris','https://x.test/p.jpg','p1'); t('E8 customer submitPayment', r.success && r.amount===330000, r);
  r = await mg.updateOrderStatus(ordNo,'payment_rejected'); t('E9 legacy reject (updateOrderStatus payment_rejected) -> verify_payment(false)', r.success, r);
  r = await alice.getOrder(ordNo); t('E9b order now payment_rejected/failed', r.order.orderStatus==='payment_rejected' && r.order.paymentStatus==='failed', r.order);
  r = await alice.submitPayment(ordNo,'transfer','https://x.test/p2.jpg','p2'); t('E9c resubmit after rejection', r.success, r);
  r = await mg.verifyPayment(ordNo,{method:'transfer',proofUrl:'https://x.test/p2.jpg'}); r2 = await mg.verifyPayment(ordNo,{});
  t('E10 staff verifyPayment ok; second call harmless', r.success && r2.success, [r,r2]);
  r = await alice.getPaymentStatus(ordNo); t('E10b payment status verified', r.success && r.status==='verified', r);
  r = await mg.assignOrderMechanic(ordNo, ID.ME); t('E11 assign order mechanic', r.success, r);
  r = await mg.updateOrderStatus(ordNo,'in_progress'); r2 = await me.updateOrderStatus(ordNo,'completed'); t('E11b manager->in_progress, mechanic->completed', r.success && r2.success, [r,r2]);
  // proof upload -> Worker -> R2 -> signed link (new)
  const png = Buffer.concat([Buffer.from([0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a]), crypto.randomBytes(1500)]);
  r = await alice.createOrder([{id:SVC,quantity:1}]); const ordP = r.orderId;
  r = await alice.submitPayment(ordP,'qris',null,'pf1', new Blob([png],{type:'image/png'})); t('E10e submitPayment with a PNG file: uploaded to R2 + attached', r.success && r.paymentId, r);
  r = await mg.getPaymentProof(ordP); t('E10f manager gets signed link to the proof', r.success && /\/f\/payment_proof\//.test(r.url||'') && r.mime==='image/png', r);
  const got = r.url ? Buffer.from(await (await fetch(r.url)).arrayBuffer()) : null; t('E10g signed link returns the exact uploaded bytes', got && got.equals(png));
  r = await as(ID.G, true).getPaymentProof(ordP); t('E10h unrelated user gets NO proof link (order invisible under RLS)', !r.url, r);
  r = await alice.submitPayment(ordP,'qris',null,'pf2', new Blob([Buffer.from('<script>alert(1)</script>')],{type:'image/png'})); t('E10i fake image rejected by Worker (magic bytes)', r.success===false, r);
  // catalog admin
  r = await alice.createCatalogItem({name:'Hack',price:1,category:'x'}); t('E12 customer cannot create catalog item', r.success===false, r);
  r = await mg.createCatalogItem({name:'Busi NGK',category:'part',description:'Busi',price:45000,stock:40}); const cid = r.itemId; t('E12b manager creates item', r.success && !!cid, r);
  r = await mg.updateCatalogItem(cid,{description:''}); r2 = await mg.getCatalogItem(cid); t('E12c blank description allowed (legacy bug fixed)', r.success && r2.item.description==='', [r,r2]);
  r = await mg.deleteCatalogItem(cid); r2 = await anon.getCatalog(); t('E12d delete = soft delete; hidden from public', r.success && !r2.items.some(i=>i.id===cid), [r,r2]);
  r = await mg.getCatalog(); t('E12e manager still sees inactive item (history kept)', r.items.some(i=>i.id===cid && i.active===false), r.items.length);
  // inventory
  r = await mg.importInventoryCSV('name,category,unit,quantity,min_stock,price,supplier\nKampas Rem,spare-part,pcs,10,3,85000,CV Maju\nOli 10W40,oil,liter,20,5,60000,PT Oli'); t('E13 CSV import creates 2 parts', r.success && r.created===2, r);
  r = await mg.getInventory(); const part = r.items.find(p=>p.name==='Kampas Rem'); t('E13b getInventory legacy shape (quantity,minStock,unit,price number)', r.success && part && part.quantity===10 && part.minStock===3 && part.unit==='pcs' && part.price===85000, r);
  r = await me.inventoryMutation(part.id,'out',8,'order: servis'); t('E14 mechanic stock-out; lowStock flag', r.success && r.quantity===2 && r.lowStock===true, r);
  r = await me.inventoryMutation(part.id,'out',50,'x'); t('E14b over-withdraw rejected', r.success===false && /Stok/.test(r.error), r);
  r = await alice.getInventory(); t('E14c customer sees no inventory', r.success && r.items.length===0, r);
  r = await mg.saveParts([{id:part.id,name:'Kampas Rem',category:'spare-part',unit:'pcs',price:90000,minStock:3}]); r2 = await mg.getInventory(); t('E14d edit part metadata', r.success && r2.items.find(p=>p.id===part.id).price===90000 && r2.items.find(p=>p.id===part.id).quantity===2, r);
  // emergency
  r = await guest.createEmergency({lat:-2.915,lng:104.758,complaint:'mogok',customerName:'Guest',customerPhone:'N/A',idempotencyKey:'e1'}); const tk = r.ticketId;
  t('E15 guest (anonymous) emergency, fee 250000, legacy ticketId', r.success && /^EMG-/.test(tk) && r.estimatedCost===250000, r);
  r = await guest.getEmergency(tk); t('E15b getEmergency by ticket no', r.success && r.ticket.status==='created', r);
  r = await alice.getEmergency(tk); t('E15c other customer cannot see ticket', r.success===false, r);
  r = await mg.listMechanics(); t('E16 listMechanics', r.success && r.mechanics.length===1, r);
  r = await mg.assignMechanic(tk, ID.ME); t('E16b assign mechanic', r.success, r);
  r = await me.updateEmergencyStatus(tk,'in_progress'); t('E16c mechanic in_progress', r.success, r);
  r = await me.shareLocation(tk,-2.9,104.7); r2 = await guest.getMechanicLocation(tk); t('E16d share location; customer reads it', r.success && r2.location && r2.location.lat===-2.9, [r,r2]);
  // discount
  r = await alice.createOrder([{id:SVC,quantity:1}]); const o2 = r.orderId; await mg.assignOrderMechanic(o2, ID.ME);
  r = await me.requestDiscount({orderId:o2, discountAmount:20000, reason:'pelanggan lama'}); t('E17 staff requests discount', r.success, r);
  r = await mg.listDiscounts(); const d = r.requests && r.requests[0]; t('E17b manager lists requests w/ order number', r.success && d && d.orderId===o2, r);
  r = await mg.approveDiscount(d.id,true); r2 = await alice.getOrder(o2); t('E17c approve -> total 198000 (server recalculated)', r.success && r2.order.total===198000 && r2.order.discount===20000, [r,r2.order]);
  // dashboard, audit, settings
  r = await mg.getDashboard('management'); t('E18 dashboard: real numbers, legacy keys', r.success && r.bookingToday>=2 && r.revenue!==5000000 && 'discountPending' in r, r);
  r = await alice.getDashboard('admin'); t('E18b customer dashboard denied', r.success===false, r);
  r = await me.getDashboard('mechanic'); t('E18c mechanic dashboard', r.success && 'assignedOrders' in r, r);
  r = await mg.getAuditLog({limit:5}); t('E19 manager audit list', r.success && r.logs.length>0, r);
  r = await alice.getAuditLog(); t('E19b customer audit list empty', r.success && r.logs.length===0, r);
  r = await anon.getSettings(); t('E20 settings readable (TAX_PERCENTAGE=11)', r.success && r.settings.TAX_PERCENTAGE==='11', r);
  // media proof via Worker + R2
  r = await alice.createOrder([{id:SVC,quantity:1}]); const o3 = r.orderId;
  const PNG = new Blob([Buffer.concat([Buffer.from([0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a]), Buffer.alloc(500,7)])], {type:'image/png'});
  r = await alice.submitPayment(o3,'qris',null,'pp1',PNG); t('E21 submitPayment with file: upload to R2 + attach proof', r.success && !!r.paymentId, r);
  r = await mg.getPaymentProof(o3); t('E21b manager gets signed proof URL', r.success && /\/f\/payment_proof\//.test(r.url||''), r);
  if (r.url) { const f = await fetch(r.url); const b = Buffer.from(await f.arrayBuffer()); t('E21c proof bytes retrievable (508 B PNG)', f.status===200 && b.length===508, [f.status,b.length]); }
  r = await as(ID.G,true).getPaymentProof(o3); t('E21d unrelated user denied proof', r.success===false || !r.url, r);
  r = await alice.getPaymentProof(o3); t('E21e owner can view own proof', r.success && !!r.url, r);
  console.log(`\nE2E TOTAL PASS=${pass} FAIL=${fail}`); process.exit(fail?1:0);
})();
