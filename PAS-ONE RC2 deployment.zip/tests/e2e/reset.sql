truncate public.discount_requests, public.mechanic_locations, public.emergency_tickets, public.payments, public.order_items, public.orders, public.inventory_mutations, public.parts, public.audit_logs cascade;
delete from public.catalog_items where id not in ('10000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000002');
update public.catalog_items set stock=5, active=true where id='10000000-0000-0000-0000-000000000001';
