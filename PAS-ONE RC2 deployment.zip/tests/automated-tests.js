// Automated Tests for PAS-One Phase A
// Run this in browser console: copy-paste all code

const TestRunner = {
  results: [],

  log(testName, passed, message = '') {
    const status = passed ? '✅ PASS' : '❌ FAIL';
    console.log(`${status}: ${testName}${message ? ' - ' + message : ''}`);
    this.results.push({ testName, passed, message });
  },

  async runAll() {
    console.log('🧪 PAS-One Phase A Test Suite\n');

    // Test 1: Global Objects
    this.testGlobalObjects();

    // Test 2: Config
    this.testConfig();

    // Test 3: API Client
    this.testAPIClient();

    // Test 4: Emergency Calculator
    this.testEmergencyCalculator();

    // Test 5: DOM Elements
    this.testDOMElements();

    // Summary
    this.printSummary();
  },

  testGlobalObjects() {
    console.log('\n📦 Testing Global Objects...');

    this.log('API Client exists', !!window.api, typeof window.api);
    this.log('App exists', !!window.app, typeof window.app);
    this.log('Emergency Calculator exists', !!window.emergencyCalculator);
    this.log('Payment Manager exists', !!window.paymentMgr);
    this.log('Catalog Manager exists', !!window.catalogMgr);
    this.log('Order Manager exists', !!window.orderMgr);
    this.log('Inventory Manager exists', !!window.inventoryMgr);
  },

  testConfig() {
    console.log('\n⚙️ Testing Configuration...');

    const cfg = window.APP_CONFIG;
    this.log('APP_CONFIG exists', !!cfg);
    this.log('Apps Script URL configured', !!cfg?.APPS_SCRIPT_URL && !cfg.APPS_SCRIPT_URL.includes('YOUR_'));
    this.log('Base location set', !!cfg?.BASE_LOCATION_LAT && !!cfg?.BASE_LOCATION_LNG);
    this.log('Service fees configured', cfg?.GUEST_VISIT_FEE === 250000);
    this.log('Free radius configured', cfg?.FREE_RADIUS_KM === 30);
    this.log('Distance fee configured', cfg?.DISTANCE_OVERAGE_FEE === 10000);
  },

  testAPIClient() {
    console.log('\n🌐 Testing API Client...');

    const api = window.api;
    this.log('API has getCatalog method', typeof api?.getCatalog === 'function');
    this.log('API has listOrders method', typeof api?.listOrders === 'function');
    this.log('API has verifyPayment method', typeof api?.verifyPayment === 'function');
    this.log('API has createCatalogItem method', typeof api?.createCatalogItem === 'function');
    this.log('API has getInventory method', typeof api?.getInventory === 'function');
    this.log('API has setToken method', typeof api?.setToken === 'function');
  },

  testEmergencyCalculator() {
    console.log('\n🚨 Testing Emergency Calculator...');

    const calc = window.emergencyCalculator;
    this.log('Calculator exists', !!calc);
    this.log('Has calculateCost method', typeof calc?.calculateCost === 'function');
    this.log('Has calculateDistance method', typeof calc?.calculateDistance === 'function');

    // Test distance calculation (Palembang)
    const dist = calc.calculateDistance(-2.915, 104.758, -2.900, 104.750);
    this.log('Distance calculation works', typeof dist === 'number' && dist > 0, `Distance: ${dist.toFixed(2)}km`);

    // Test cost calculation
    const cost = calc.calculateCost(-2.900, 104.750, true); // Registered, nearby
    this.log('Cost calculation returns object', typeof cost === 'object');
    this.log('Cost has distance property', typeof cost?.distance === 'number');
    this.log('Cost has visitFee property', typeof cost?.visitFee === 'number');
    this.log('Cost has distanceFee property', typeof cost?.distanceFee === 'number');
    this.log('Cost has totalEstimate property', typeof cost?.totalEstimate === 'number');
    this.log('Cost calculation logic (registered+nearby)', cost?.visitFee === 0 && cost?.distanceFee === 0, `Total: Rp${cost?.totalEstimate}`);

    // Test guest scenario
    const costGuest = calc.calculateCost(-2.900, 104.750, false); // Guest
    this.log('Guest cost calculation', costGuest?.visitFee === 250000, `Guest fee: Rp${costGuest?.visitFee}`);
  },

  testDOMElements() {
    console.log('\n🎨 Testing DOM Elements...');

    this.log('Navbar exists', !!document.querySelector('.navbar'));
    this.log('Admin dashboard exists', !!document.getElementById('page-admin'));
    this.log('Payment list container exists', !!document.getElementById('payment-list'));
    this.log('Catalog table container exists', !!document.getElementById('catalog-table'));
    this.log('Order list container exists', !!document.getElementById('order-list'));
    this.log('Inventory list container exists', !!document.getElementById('inventory-list'));
    this.log('Tab buttons exist', document.querySelectorAll('.tab-btn').length > 0);
    this.log('Modal styling loaded', !!document.querySelector('style')?.textContent?.includes('modal'));
  },

  printSummary() {
    console.log('\n' + '='.repeat(50));
    const total = this.results.length;
    const passed = this.results.filter(r => r.passed).length;
    const failed = total - passed;

    console.log(`\n📊 TEST SUMMARY`);
    console.log(`Total Tests: ${total}`);
    console.log(`✅ Passed: ${passed}`);
    console.log(`❌ Failed: ${failed}`);
    console.log(`Success Rate: ${((passed/total)*100).toFixed(1)}%`);

    if (failed === 0) {
      console.log('\n✅ ALL TESTS PASSED - READY FOR LAUNCH');
    } else {
      console.log('\n⚠️ SOME TESTS FAILED - FIX BEFORE LAUNCH');
    }
    console.log('='.repeat(50));
  }
};

// Run tests
TestRunner.runAll();
