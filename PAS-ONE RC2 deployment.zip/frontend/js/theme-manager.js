// Theme engine: only toggles <html data-theme> and persists the choice. No business logic, API or routing here.
(function () {
  var THEMES = ['default', 'light', 'dark', 'editorial', 'industrial'];
  var KEY = 'pas_theme';
  function read() { try { return localStorage.getItem(KEY); } catch (e) { return null; } }
  function write(v) { try { localStorage.setItem(KEY, v); } catch (e) { /* private mode: theme just won't persist */ } }
  function apply(name) { document.documentElement.setAttribute('data-theme', name); }
  var ThemeManager = {
    list: function () { return THEMES.slice(); },
    current: function () { return document.documentElement.getAttribute('data-theme') || 'default'; },
    set: function (name) { if (THEMES.indexOf(name) < 0) name = 'default'; apply(name); write(name); var s = document.getElementById('theme-select'); if (s) s.value = name; },
    init: function () {
      var saved = read(); apply(THEMES.indexOf(saved) >= 0 ? saved : 'default');
      var s = document.getElementById('theme-select');
      if (s) { s.value = this.current(); s.addEventListener('change', function () { ThemeManager.set(s.value); }); }
    }
  };
  window.ThemeManager = ThemeManager;
  apply(THEMES.indexOf(read()) >= 0 ? read() : 'default');       // run immediately (script is in <head>) to avoid a flash of the wrong theme
  document.addEventListener('DOMContentLoaded', function () { ThemeManager.init(); });
})();
