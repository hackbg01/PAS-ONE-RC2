// Shrinks phone photos before upload (free-tier friendly: Worker limit is 2 MB). PDFs and small files pass through untouched.
window.prepareUpload = async function (file, maxBytes) {
  maxBytes = maxBytes || 2 * 1024 * 1024;
  if (!file) return null;
  if (file.type === 'application/pdf') { if (file.size > maxBytes) throw new Error('PDF maksimal 2 MB'); return file; }
  if (!/^image\/(jpeg|png|webp)$/.test(file.type)) throw new Error('Format harus JPG, PNG, WEBP atau PDF');
  if (file.size <= 1.5 * 1024 * 1024) return file;
  const bmp = await createImageBitmap(file); const scale = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
  const c = document.createElement('canvas'); c.width = Math.round(bmp.width * scale); c.height = Math.round(bmp.height * scale);
  c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
  const blob = await new Promise(res => c.toBlob(res, 'image/jpeg', 0.8));
  if (!blob || blob.size > maxBytes) throw new Error('Foto terlalu besar, coba foto lain');
  return blob;
};
