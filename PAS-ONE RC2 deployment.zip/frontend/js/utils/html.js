// Escape untrusted text before putting it into innerHTML (fixes stored-XSS findings H4/S7)
window.esc = function (v) {
  return String(v == null ? '' : v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
};
window.rupiah = function (n) { return 'Rp ' + Number(n || 0).toLocaleString('id-ID'); };
