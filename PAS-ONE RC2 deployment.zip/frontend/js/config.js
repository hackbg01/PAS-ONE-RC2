```javascript
// ======================================================
// PAS-ONE CONFIGURATION
// Prima Auto Service
// Release Candidate 2
// ======================================================

window.APP_CONFIG = {

  // APPS SCRIPT
  APPS_SCRIPT_URL: '',

  // SUPABASE
  SUPABASE_URL: 'https://ghgrltaeonbgomclxqsd.supabase.co',
  SUPABASE_ANON_KEY: 'sb_publishable_rq1GdH7p99okNZba5qNowg_u0corS-7',

  // CLOUDFLARE WORKER
  MEDIA_WORKER_URL: '',

  // GOOGLE SHEETS
  SPREADSHEET_ID: '',

  // LOCATION
  BASE_LOCATION_LAT: -2.9904268,
  BASE_LOCATION_LNG: 104.7214152,
  BASE_LOCATION_NAME: 'PRIMA AUTO SERVIS ( PAS )',
  BASE_LOCATION_ADDRESS: 'Jl. Letjen H. Alamsyah Ratu Perwiranegara, Karang Jaya, Kec. Gandus, Kota Palembang, Sumatera Selatan 30149',

  // EMERGENCY SETTINGS
  EMERGENCY_PHONE: '+628139888128',
  EMERGENCY_WHATSAPP: '+62818139888128',

  // SERVICE HOURS
  NORMAL_HOURS_START: 6,
  NORMAL_HOURS_END: 18,
  TIMEZONE: 'Asia/Jakarta',

  // SERVICE FEES (RUPIAH)
  FREE_RADIUS_KM: 30,
  DISTANCE_OVERAGE_FEE: 10000,
  GUEST_VISIT_FEE: 250000,
  OFF_HOURS_VISIT_FEE: 250000,

  // POLLING
  LOCATION_POLLING_INTERVAL: 30000,
  STATUS_POLLING_INTERVAL: 60000,

  // STORAGE
  TOKEN_EXPIRY_HOURS: 1,

  // USER ROLES
  ROLES: {
    ADMIN: 'admin',
    MECHANIC: 'mechanic',
    MANAGER: 'manager',
    CUSTOMER: 'customer',
    GUEST: 'guest'
  },

  // ORDER STATUS
  ORDER_STATUS: {
    DRAFT: 'draft',
    PENDING_PAYMENT: 'pending_payment',
    PAYMENT_VERIFIED: 'payment_verified',
    IN_PROGRESS: 'in_progress',
    COMPLETED: 'completed',
    CANCELLED: 'cancelled'
  },

  // EMERGENCY STATUS
  EMERGENCY_STATUS: {
    CREATED: 'created',
    ASSIGNED: 'assigned',
    IN_PROGRESS: 'in_progress',
    COMPLETED: 'completed',
    CANCELLED: 'cancelled'
  },

  // PAYMENT STATUS
  PAYMENT_STATUS: {
    PENDING: 'pending',
    VERIFIED: 'verified',
    FAILED: 'failed'
  },

  // DISCOUNT STATUS
  DISCOUNT_STATUS: {
    REQUESTED: 'requested',
    APPROVED: 'approved',
    REJECTED: 'rejected'
  }

};


// ======================================================
// CONFIGURATION VALIDATION
// ======================================================

window.addEventListener('DOMContentLoaded', function() {

  const config = window.APP_CONFIG;

  const missingConfig = [];

  if (!config.SUPABASE_URL) {
    missingConfig.push('SUPABASE_URL');
  }

  if (
    !config.SUPABASE_ANON_KEY ||
    config.SUPABASE_ANON_KEY.includes('MASUKKAN_')
  ) {
    missingConfig.push('SUPABASE_ANON_KEY');
  }

  if (missingConfig.length > 0) {
    console.error(
      'PAS-ONE: Konfigurasi belum lengkap:',
      missingConfig.join(', ')
    );
  } else {
    console.info('PAS-ONE: Konfigurasi dasar berhasil dimuat.');
  }

});
```