// PAS-One Main App Router
class PASOneApp {
  constructor() {
    this.currentUser = null;
    this.cart = [];
    try { this.cart = JSON.parse(localStorage.getItem('cart') || '[]'); } catch (e) { this.cart = []; }   // cart now survives reload
    this.checkoutKey = null;           // idempotency key for the current checkout attempt
    this.taxPct = 11;                  // display only; server decides (settings.TAX_PERCENTAGE)
    this.emergencyTimer = null;
    this.currentPortal = 'consumer';
    this.init();
  }

  async init() {
    this.loadAuth();
    this.setupRouter();
    this.attachEventListeners();
    this.loadTaxSetting();
    await this.loadCatalog();
  }

  async loadTaxSetting() {
    const r = await window.api.getSettings();
    if (r.success && r.settings.TAX_PERCENTAGE) { this.taxPct = Number(r.settings.TAX_PERCENTAGE); if (this.currentRoute === '/cart') this.renderCart(); }
  }

  loadAuth() {
    const token = localStorage.getItem('auth_token');
    const user = localStorage.getItem('auth_user');
    if (token && user) {
      this.currentUser = JSON.parse(user);
      window.api.setToken(token);
    }
    this.updateAuthUI();
    // Re-verify against the real Supabase session (localStorage copy is only a UI hint; RLS is the real gate)
    window.api.getCurrentUser().then(r => {
      if (r.success) { this.currentUser = r.user; localStorage.setItem('auth_user', JSON.stringify(r.user)); }
      else { this.currentUser = null; localStorage.removeItem('auth_user'); localStorage.removeItem('auth_token'); }
      this.updateAuthUI(); this.handleRoute();
    });
  }

  setupRouter() {
    window.addEventListener('hashchange', () => this.handleRoute());
    this.handleRoute();
  }

  handleRoute() {
    const hash = window.location.hash.slice(1) || '/';
    const [path, ...params] = hash.split('?');

    this.hideAllPages();
    this.currentRoute = path;
    if (this.emergencyTimer) { clearInterval(this.emergencyTimer); this.emergencyTimer = null; }

    if (path === '/catalog' || path === '/' || path === '') {
      this.showPage('page-catalog');
    } else if (path === '/cart') {
      this.showPage('page-cart');
      this.renderCart();
    } else if (path === '/payment') {
      this.showPage('page-payment');
      this.renderPayment(new URLSearchParams(params.join('?')).get('order'));
    } else if (path === '/emergency' || path.startsWith('/emergency/')) {
      this.showPage('page-emergency');
      if (path.startsWith('/emergency/')) this.loadEmergencyStatus(decodeURIComponent(path.slice('/emergency/'.length)));
    } else if (path === '/login') {
      this.showPage('page-login');
    } else if (path === '/register') {
      this.showPage('page-register');
    } else if (path === '/admin' && this.isAdmin()) {
      this.showPage('page-admin');
      this.loadAdminDashboard();
    } else if (path === '/mechanic' && this.isMechanic()) {
      this.showPage('page-mechanic');
      this.loadMechanicDashboard();
    } else if (path === '/management' && this.isManager()) {
      this.showPage('page-management');
      this.loadManagementDashboard();
    } else {
      this.showPage('page-catalog');
    }
  }

  async loadCatalog() {
    try {
      const data = await window.api.getCatalog();
      if (data.success === false) throw new Error(data.error);
      const items = data.items || [];
      this.catalogItems = items;
      const html = items.length ? items.map(item => `
        <div class="catalog-item">
          <h4>${esc(item.name)}</h4>
          <p>${esc(item.description)}</p>
          <p class="price">${rupiah(item.price)}</p>
          <button class="btn-primary btn-small" data-add="${esc(item.id)}">Tambah ke Keranjang</button>
        </div>
      `).join('') : '<p class="empty-state">Katalog kosong</p>';
      document.getElementById('catalog-list').innerHTML = html;
    } catch (error) {
      console.error('Failed to load catalog:', error);
      document.getElementById('catalog-list').innerHTML = '<p>Gagal memuat katalog</p>';
    }
  }

  addToCart(id, name, price) {
    const existing = this.cart.find(item => item.id === id);
    if (existing) {
      existing.quantity++;
    } else {
      this.cart.push({ id, name, price, quantity: 1 });
    }
    localStorage.setItem('cart', JSON.stringify(this.cart));
    this.showNotification('Produk ditambahkan ke keranjang');
  }

  renderCart() {
    if (this.cart.length === 0) {
      document.getElementById('cart-items').innerHTML = '<p>Keranjang kosong</p>';
      document.getElementById('cart-summary').innerHTML = '';
      return;
    }

    const itemsHtml = this.cart.map((item, idx) => `
      <div class="cart-item">
        <span>${esc(item.name)}</span>
        <span>${rupiah(item.price)}</span>
        <input type="number" min="1" value="${item.quantity}"
               onchange="app.updateCartQty(${idx}, this.value)">
        <button class="btn-secondary btn-small" onclick="app.removeFromCart(${idx})">Hapus</button>
      </div>
    `).join('');

    const subtotal = this.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const summaryHtml = `
      <div class="cart-summary">
        <p>Subtotal: ${rupiah(subtotal)}</p>
        <p>Pajak (${this.taxPct}%): ${rupiah(subtotal * this.taxPct / 100)}</p>
        <h3>Total (estimasi): ${rupiah(subtotal * (1 + this.taxPct / 100))}</h3>
        <p><small>Harga final dihitung server saat order dibuat.</small></p>
      </div>
    `;

    document.getElementById('cart-items').innerHTML = itemsHtml;
    document.getElementById('cart-summary').innerHTML = summaryHtml;
  }

  updateCartQty(idx, qty) {
    this.cart[idx].quantity = Math.min(999, Math.max(1, parseInt(qty) || 1));
    this.checkoutKey = null;
    localStorage.setItem('cart', JSON.stringify(this.cart));
    this.renderCart();
  }

  removeFromCart(idx) {
    this.cart.splice(idx, 1);
    localStorage.setItem('cart', JSON.stringify(this.cart));
    this.renderCart();
  }

  async handleLogin(event) {
    event.preventDefault();
    const form = event.target;
    const email = form.querySelector('input[type="email"]').value;
    const password = form.querySelector('input[type="password"]').value;

    try {
      const response = await window.api.login(email, password);
      if (response.token) {
        localStorage.setItem('auth_token', response.token);
        localStorage.setItem('auth_user', JSON.stringify(response.user));
        this.currentUser = response.user;
        window.api.setToken(response.token);
        this.updateAuthUI();
        this.showNotification('Login berhasil!');
        window.location.hash = '/';
      } else {
        this.showNotification(response.error || 'Email atau password salah', 'error');
      }
    } catch (error) {
      this.showNotification('Login gagal: ' + error.message, 'error');
    }
  }

  async handleRegister(event) {
    event.preventDefault();
    const form = event.target;
    const name = form.querySelector('input[type="text"]').value;
    const email = form.querySelector('input[type="email"]').value;
    const password = form.querySelectorAll('input[type="password"]')[0].value;
    const passwordConfirm = form.querySelectorAll('input[type="password"]')[1].value;

    if (password !== passwordConfirm) {
      this.showNotification('Password tidak cocok', 'error');
      return;
    }

    try {
      const response = await window.api.register(email, password, name);
      if (response.success) {
        this.showNotification(response.message || 'Registrasi berhasil! Silakan login.');
        window.location.hash = '/login';
      } else {
        this.showNotification(response.error || response.message || 'Registrasi gagal', 'error');
      }
    } catch (error) {
      this.showNotification('Registrasi gagal: ' + error.message, 'error');
    }
  }

  async handleLogout() {
    try {
      await window.api.logout();
      localStorage.removeItem('auth_token');
      localStorage.removeItem('auth_user');
      this.currentUser = null;
      this.updateAuthUI();
      window.location.hash = '/';
    } catch (error) {
      console.error('Logout error:', error);
    }
  }

  updateAuthUI() {
    const authMenu = document.getElementById('auth-menu');
    if (this.currentUser) {
      authMenu.innerHTML = `
        <span>${esc(this.currentUser.name || this.currentUser.email || 'Tamu')}</span>
        <button class="btn-secondary btn-small" onclick="app.handleLogout()">Logout</button>
      `;
      if (this.isAdmin()) {
        authMenu.innerHTML += '<a href="#/admin">Admin</a>';
      }
      if (this.isMechanic()) {
        authMenu.innerHTML += '<a href="#/mechanic">Mekanik</a>';
      }
      if (this.isManager()) {
        authMenu.innerHTML += '<a href="#/management">Manager</a>';
      }
    } else {
      authMenu.innerHTML = `
        <a href="#/login">Login</a>
        <a href="#/register">Daftar</a>
      `;
    }
  }

  async loadAdminDashboard() {
    try {
      const data = await window.api.getDashboard('admin');
      document.getElementById('stat-booking-today').textContent = data.bookingToday || 0;
      document.getElementById('stat-payment-pending').textContent = data.paymentPending || 0;
      document.getElementById('stat-work-active').textContent = data.workActive || 0;
      document.getElementById('stat-emergency').textContent = data.emergency || 0;
      if (data.success === false) this.showNotification(data.error || 'Gagal memuat dashboard', 'error');
    } catch (error) {
      console.error('Failed to load admin dashboard:', error);
    }
  }

  async loadMechanicDashboard() {
    try {
      const data = await window.api.getDashboard('mechanic');
      const box = document.getElementById('mechanic-assignments');
      if (data.success === false) { box.innerHTML = '<p class="error">' + esc(data.error) + '</p>'; return; }
      const orders = await window.api.listOrders();
      const mine = (orders.orders || []).filter(o => ['payment_verified', 'in_progress'].includes(o.orderStatus));
      box.innerHTML = `<p>Order ditugaskan: ${data.assignedOrders} | Emergency ditugaskan: ${data.assignedEmergency}</p>` +
        (mine.length ? '<ul>' + mine.map(o => `<li>${esc(o.orderId)} — ${esc(o.orderStatus)} — ${esc(o.customerData.name || 'Guest')}</li>`).join('') + '</ul>' : '<p class="empty-state">Tidak ada tugas</p>');
    } catch (error) {
      console.error('Failed to load mechanic dashboard:', error);
    }
  }

  async loadManagementDashboard() {
    try {
      const data = await window.api.getDashboard('management');
      document.getElementById('stat-revenue').textContent =
        'Rp ' + (data.revenue || 0).toLocaleString('id-ID');
      document.getElementById('stat-discount-pending').textContent = data.discountPending || 0;
      this.renderDiscountList();
    } catch (error) {
      console.error('Failed to load management dashboard:', error);
    }
  }

  // ---- Checkout & payment (new: previously #/payment had no page) -----------------
  async handleCheckout() {
    if (this.cart.length === 0) { this.showNotification('Keranjang kosong', 'error'); return; }
    if (!this.currentUser && !confirm('Lanjut sebagai tamu?')) { window.location.hash = '/login'; return; }
    if (!this.checkoutKey) this.checkoutKey = (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random());
    const btn = document.getElementById('btn-checkout'); if (btn) btn.disabled = true;   // prevent double submit
    try {
      const r = await window.api.createOrder(this.cart, { name: this.currentUser?.name || '' }, this.checkoutKey);
      if (!r.success) { this.showNotification(r.error || 'Gagal membuat order', 'error'); return; }
      this.cart = []; this.checkoutKey = null; localStorage.setItem('cart', '[]');
      window.location.hash = '/payment?order=' + encodeURIComponent(r.orderId);
    } finally { if (btn) btn.disabled = false; }
  }

  async renderPayment(orderNo) {
    const box = document.getElementById('payment-order-summary');
    if (!orderNo) { box.innerHTML = '<p class="empty-state">Tidak ada order yang dipilih. <a href="#/catalog">Kembali ke katalog</a></p>'; return; }
    this.paymentOrderNo = orderNo;
    box.innerHTML = '<p>Memuat order...</p>';
    const r = await window.api.getOrder(orderNo);
    if (!r.success) { box.innerHTML = '<p class="error">' + esc(r.error || 'Order tidak ditemukan') + '</p>'; return; }
    const o = r.order;
    box.innerHTML = `<p><strong>${esc(o.orderId)}</strong> — status: ${esc(o.orderStatus)} / pembayaran: ${esc(o.paymentStatus)}</p>
      <ul>${o.items.map(i => `<li>${esc(i.name)} × ${i.quantity} — ${rupiah(i.price * i.quantity)}</li>`).join('')}</ul>
      <p>Subtotal: ${rupiah(o.subtotal)}${o.discount ? ' | Diskon: ' + rupiah(o.discount) : ''} | Pajak: ${rupiah(o.tax)}</p>
      <h3>Total: ${rupiah(o.total)}</h3>`;
    this.paymentKey = (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()));
  }

  async handlePayment(event) {
    event.preventDefault();
    const f = event.target; const out = document.getElementById('payment-result');
    out.textContent = 'Mengirim...';
    const r = await window.api.submitPayment(this.paymentOrderNo, f.method.value, f.proofUrl.value.trim() || null, this.paymentKey, f.proofFile.files[0] || null);
    if (r.success) { out.textContent = 'Pembayaran terkirim. Menunggu verifikasi staf.'; this.showNotification('Pembayaran terkirim'); }
    else { out.textContent = r.error || 'Gagal mengirim pembayaran'; this.showNotification(r.error || 'Gagal', 'error'); }
  }

  // ---- Emergency status (new: route #/emergency/:id had no handler) -----------------
  async loadEmergencyStatus(id) {
    const box = document.getElementById('emergency-status');
    const draw = async () => {
      const r = await window.api.getEmergency(id);
      if (!r.success) { box.innerHTML = '<p class="error">' + esc(r.error) + '</p>'; return; }
      const t = r.ticket;
      box.innerHTML = `<p><strong>Tiket ${esc(t.ticketId)}</strong> — status: ${esc(t.status)}</p>
        <p>Jarak: ${esc(t.distanceKm)} km | Estimasi biaya: ${rupiah(t.estimatedCost)}</p>
        <p><small>Biaya final ditetapkan oleh PAS. Hubungi: ${esc(window.APP_CONFIG.EMERGENCY_PHONE)}</small></p>`;
      if (['completed', 'cancelled'].includes(t.status) && this.emergencyTimer) { clearInterval(this.emergencyTimer); this.emergencyTimer = null; }
    };
    await draw();
    this.emergencyTimer = setInterval(draw, window.APP_CONFIG.STATUS_POLLING_INTERVAL);
  }

  async renderDiscountList() {
    const box = document.getElementById('discount-list'); if (!box) return;
    const r = await window.api.listDiscounts('requested');
    if (!r.success) { box.innerHTML = '<p class="error">' + esc(r.error) + '</p>'; return; }
    box.innerHTML = r.requests.length ? r.requests.map(d => `<div class="discount-item">
        <strong>${esc(d.orderId)}</strong> diskon ${rupiah(d.discountAmount)} (${esc(d.reason)})
        <button class="btn-primary btn-small" data-disc="${esc(d.id)}" data-ok="1">Setujui</button>
        <button class="btn-secondary btn-small" data-disc="${esc(d.id)}" data-ok="0">Tolak</button></div>`).join('')
      : '<p class="empty-state">Tidak ada permintaan diskon</p>';
    if (!box.dataset.bound) {
      box.dataset.bound = '1';
      box.addEventListener('click', async e => {
        const b = e.target.closest('[data-disc]'); if (!b) return;
        const res = await window.api.approveDiscount(b.dataset.disc, b.dataset.ok === '1');
        this.showNotification(res.success ? 'Diproses' : (res.error || 'Gagal'), res.success ? 'success' : 'error');
        this.renderDiscountList(); this.loadManagementDashboard();
      });
    }
  }

  isAdmin() {
    return this.currentUser?.role === window.APP_CONFIG.ROLES.ADMIN;
  }

  isMechanic() {
    return this.currentUser?.role === window.APP_CONFIG.ROLES.MECHANIC;
  }

  isManager() {
    return this.currentUser?.role === window.APP_CONFIG.ROLES.MANAGER;
  }

  showPage(pageId) {
    document.getElementById(pageId).style.display = 'block';
  }

  hideAllPages() {
    document.querySelectorAll('.page').forEach(page => page.style.display = 'none');
  }

  showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 3000);
  }

  attachEventListeners() {
    document.getElementById('catalog-list')?.addEventListener('click', e => {
      const b = e.target.closest('[data-add]'); if (!b) return;
      const it = (this.catalogItems || []).find(i => i.id === b.dataset.add);
      if (it) this.addToCart(it.id, it.name, it.price);
    });
    document.getElementById('form-payment')?.addEventListener('submit', e => this.handlePayment(e));
    document.getElementById('form-login')?.addEventListener('submit', e => this.handleLogin(e));
    document.getElementById('form-register')?.addEventListener('submit', e => this.handleRegister(e));
    document.getElementById('btn-checkout')?.addEventListener('click', () => this.handleCheckout());
    document.getElementById('btn-panic')?.addEventListener('click', () => this.triggerEmergency());

    // Tab navigation
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const tabName = e.target.getAttribute('onclick').match(/'([^']+)'/)[1];
        window.showTab(tabName);
      });
    });
  }

  async triggerEmergency() {
    if (!navigator.geolocation) {
      this.showNotification('Geolocation tidak didukung', 'error');
      return;
    }
    const key = (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()));
    navigator.geolocation.getCurrentPosition(async (pos) => {
      try {
        const response = await window.api.createEmergency({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          complaint: 'Emergency request via panic button',
          customerName: this.currentUser?.name || 'Guest',
          customerPhone: this.currentUser?.phone || null,
          idempotencyKey: key
        });
        if (response.success && response.ticketId) {
          window.location.hash = `/emergency/${encodeURIComponent(response.ticketId)}`;
          this.showNotification('Emergency ticket dibuat: ' + response.ticketId);
        } else {
          this.showNotification('Gagal membuat emergency ticket: ' + (response.error || ''), 'error');
        }
      } catch (error) {
        this.showNotification('Gagal membuat emergency ticket: ' + error.message, 'error');
      }
    }, () => {
      this.showNotification('Lokasi tidak bisa diakses. Hubungi ' + window.APP_CONFIG.EMERGENCY_PHONE, 'error');
    }, { enableHighAccuracy: true, timeout: 15000 });
  }
}

// Global tab switching function
window.showTab = function(tabName) {
  // Hide all tabs
  document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));

  // Show selected tab
  const tabContent = document.getElementById('tab-' + tabName);
  const tabBtn = document.querySelector(`.tab-btn[onclick*="${tabName}"]`);

  if (tabContent) tabContent.classList.add('active');
  if (tabBtn) tabBtn.classList.add('active');
};

// Initialize on load
let app;
document.addEventListener('DOMContentLoaded', () => {
  app = new PASOneApp();
});
