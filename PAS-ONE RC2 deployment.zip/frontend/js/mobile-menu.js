// Mobile Hamburger Menu Handler
class MobileMenuHandler {
  constructor() {
    this.menuOpen = false;
    this.init();
  }

  init() {
    this.createMenuButton();
    this.attachEventListeners();
    this.handleResize();
  }

  createMenuButton() {
    // Create hamburger button if screen is mobile
    if (window.innerWidth <= 768) {
      const navbar = document.querySelector('.navbar .container');
      if (navbar && !document.querySelector('.hamburger-btn')) {
        const btn = document.createElement('button');
        btn.className = 'hamburger-btn';
        btn.innerHTML = '☰';
        btn.onclick = (e) => {
          e.preventDefault();
          this.toggleMenu();
        };
        navbar.appendChild(btn);
      }
    }
  }

  toggleMenu() {
    const menu = document.querySelector('.navbar-menu');
    if (!menu) return;

    this.menuOpen = !this.menuOpen;
    if (this.menuOpen) {
      menu.classList.add('mobile-open');
    } else {
      menu.classList.remove('mobile-open');
    }
  }

  closeMenu() {
    const menu = document.querySelector('.navbar-menu');
    if (menu) {
      menu.classList.remove('mobile-open');
      this.menuOpen = false;
    }
  }

  handleResize() {
    window.addEventListener('resize', () => {
      if (window.innerWidth > 768) {
        this.closeMenu();
        const btn = document.querySelector('.hamburger-btn');
        if (btn) btn.remove();
      } else {
        this.createMenuButton();
      }
    });
  }

  attachEventListeners() {
    // Close menu when clicking a link
    document.addEventListener('click', (e) => {
      const menu = document.querySelector('.navbar-menu');
      const btn = document.querySelector('.hamburger-btn');

      if (menu && e.target !== btn && !btn?.contains(e.target)) {
        if (!menu.contains(e.target)) {
          this.closeMenu();
        }
      }
    });

    // Close menu on link click
    document.querySelectorAll('.navbar-menu a').forEach(link => {
      link.addEventListener('click', () => this.closeMenu());
    });
  }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
  new MobileMenuHandler();
});
